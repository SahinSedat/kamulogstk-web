--
-- PostgreSQL database dump
--

\restrict tUD4uI96hghUfUTHqiIkGLnvReWOk0nKGylRZaClApx4TgT2KGZ98bXP1fm1seR

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: kamulog_panel
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'READ'
);


ALTER TYPE public."MessageStatus" OWNER TO kamulog_panel;

--
-- Name: MessageType; Type: TYPE; Schema: public; Owner: kamulog_panel
--

CREATE TYPE public."MessageType" AS ENUM (
    'TEXT',
    'IMAGE',
    'FILE',
    'PDF'
);


ALTER TYPE public."MessageType" OWNER TO kamulog_panel;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: kamulog_panel
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'CONSULTANT',
    'MODERATOR',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO kamulog_panel;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminLog; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."AdminLog" (
    id text NOT NULL,
    "adminId" text NOT NULL,
    action text NOT NULL,
    "targetType" text NOT NULL,
    "targetId" text,
    details text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AdminLog" OWNER TO kamulog_panel;

--
-- Name: BecayisListing; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."BecayisListing" (
    id text NOT NULL,
    "ownerId" text NOT NULL,
    title text NOT NULL,
    role text NOT NULL,
    "institutionId" text,
    branch text NOT NULL,
    "currentCity" text NOT NULL,
    "currentDistrict" text,
    "targetCity" text NOT NULL,
    "assignmentMethod" text,
    "assignmentMethodOther" text,
    description text NOT NULL,
    "isPremium" boolean DEFAULT false NOT NULL,
    "premiumUntil" timestamp(3) without time zone,
    status text DEFAULT 'draft'::text NOT NULL,
    "approvedById" text,
    "approvedAt" timestamp(3) without time zone,
    slug text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "adNumber" text,
    "pendingChanges" jsonb,
    "viewCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."BecayisListing" OWNER TO kamulog_panel;

--
-- Name: BecayisMessage; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."BecayisMessage" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    "listingId" text NOT NULL,
    content text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isFiltered" boolean DEFAULT false NOT NULL,
    status public."MessageStatus" DEFAULT 'SENT'::public."MessageStatus" NOT NULL
);


ALTER TABLE public."BecayisMessage" OWNER TO kamulog_panel;

--
-- Name: CV; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."CV" (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    data text NOT NULL,
    template text DEFAULT 'modern'::text NOT NULL,
    "pdfPath" text,
    "pdfGeneratedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CV" OWNER TO kamulog_panel;

--
-- Name: CVAnalysis; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."CVAnalysis" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "cvId" text NOT NULL,
    "jobId" text NOT NULL,
    score integer NOT NULL,
    feedback text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CVAnalysis" OWNER TO kamulog_panel;

--
-- Name: ChatSession; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."ChatSession" (
    id text NOT NULL,
    "userId" text NOT NULL,
    messages text NOT NULL,
    "cvId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatSession" OWNER TO kamulog_panel;

--
-- Name: Consultant; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Consultant" (
    id text NOT NULL,
    "userId" text,
    name text NOT NULL,
    title text NOT NULL,
    category text NOT NULL,
    bio text NOT NULL,
    specializations text[],
    "experienceYears" integer DEFAULT 0 NOT NULL,
    "avatarUrl" text,
    rating double precision DEFAULT 0 NOT NULL,
    "reviewCount" integer DEFAULT 0 NOT NULL,
    "isOnline" boolean DEFAULT false NOT NULL,
    "isFeatured" boolean DEFAULT false NOT NULL,
    "completedConsultations" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "consultantCredits" integer DEFAULT 0 NOT NULL,
    "creditPrice" double precision DEFAULT 0 NOT NULL,
    iban text,
    "sessionFeeJeton" integer DEFAULT 5 NOT NULL,
    email text,
    phone text
);


ALTER TABLE public."Consultant" OWNER TO kamulog_panel;

--
-- Name: ConsultantApplication; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."ConsultantApplication" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    category text NOT NULL,
    specialization text,
    bio text,
    "experienceYears" integer DEFAULT 0 NOT NULL,
    "cvUrl" text,
    "diplomaUrl" text,
    status text DEFAULT 'pending'::text NOT NULL,
    "rejectionReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ConsultantApplication" OWNER TO kamulog_panel;

--
-- Name: ConsultantPayout; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."ConsultantPayout" (
    id text NOT NULL,
    "consultantId" text NOT NULL,
    period text NOT NULL,
    "earnedJetons" integer DEFAULT 0 NOT NULL,
    "jetonRate" double precision DEFAULT 0 NOT NULL,
    "totalTL" double precision DEFAULT 0 NOT NULL,
    "commissionRate" double precision DEFAULT 0 NOT NULL,
    "commissionTL" double precision DEFAULT 0 NOT NULL,
    "netPayoutTL" double precision DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ConsultantPayout" OWNER TO kamulog_panel;

--
-- Name: ConsultationRequest; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."ConsultationRequest" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "consultantId" text NOT NULL,
    "packageId" text NOT NULL,
    description text NOT NULL,
    "aiBriefing" text,
    status text DEFAULT 'pending'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ConsultationRequest" OWNER TO kamulog_panel;

--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Conversation" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "consultantId" text NOT NULL,
    category text NOT NULL,
    "lastMessage" text,
    "lastMessageAt" timestamp(3) without time zone,
    "unreadCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO kamulog_panel;

--
-- Name: CookieConsent; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."CookieConsent" (
    id text NOT NULL,
    "ipAddress" text NOT NULL,
    "userAgent" text,
    "userId" text,
    "consentType" text DEFAULT 'all'::text NOT NULL,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CookieConsent" OWNER TO kamulog_panel;

--
-- Name: Coupon; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Coupon" (
    id text NOT NULL,
    code text NOT NULL,
    name text,
    "discountType" text DEFAULT 'PERCENT'::text NOT NULL,
    "discountValue" double precision NOT NULL,
    "validFrom" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "validUntil" timestamp(3) without time zone,
    "maxUsage" integer,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "planRestriction" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Coupon" OWNER TO kamulog_panel;

--
-- Name: FavoriteAd; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."FavoriteAd" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "listingId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."FavoriteAd" OWNER TO kamulog_panel;

--
-- Name: Institution; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Institution" (
    id text NOT NULL,
    name text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Institution" OWNER TO kamulog_panel;

--
-- Name: JobListing; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."JobListing" (
    id text NOT NULL,
    code text,
    title text NOT NULL,
    company text NOT NULL,
    location text,
    description text NOT NULL,
    requirements text,
    type text DEFAULT 'PRIVATE'::text NOT NULL,
    "sourceUrl" text,
    "applicationUrl" text,
    salary text,
    deadline timestamp(3) without time zone,
    "employerPhone" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."JobListing" OWNER TO kamulog_panel;

--
-- Name: KariyerChatMessage; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."KariyerChatMessage" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderType" text NOT NULL,
    content text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."KariyerChatMessage" OWNER TO kamulog_panel;

--
-- Name: KariyerChatRoom; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."KariyerChatRoom" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "consultantId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "closedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KariyerChatRoom" OWNER TO kamulog_panel;

--
-- Name: KariyerConsultant; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."KariyerConsultant" (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    title text NOT NULL,
    description text,
    "avatarUrl" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KariyerConsultant" OWNER TO kamulog_panel;

--
-- Name: KariyerConsultantRating; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."KariyerConsultantRating" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "consultantId" text NOT NULL,
    "userId" text NOT NULL,
    rating integer NOT NULL,
    comment text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."KariyerConsultantRating" OWNER TO kamulog_panel;

--
-- Name: KariyerSubscription; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."KariyerSubscription" (
    id text NOT NULL,
    "userId" text NOT NULL,
    plan text DEFAULT 'FREE'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderCode" text,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KariyerSubscription" OWNER TO kamulog_panel;

--
-- Name: Media; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Media" (
    id text NOT NULL,
    filename text NOT NULL,
    url text NOT NULL,
    "mimeType" text,
    size integer,
    "categoryId" text,
    link text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Media" OWNER TO kamulog_panel;

--
-- Name: MediaCategory; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."MediaCategory" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MediaCategory" OWNER TO kamulog_panel;

--
-- Name: Message; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "senderId" text NOT NULL,
    text text NOT NULL,
    type public."MessageType" DEFAULT 'TEXT'::public."MessageType" NOT NULL,
    "fileUrl" text,
    "fileName" text,
    status public."MessageStatus" DEFAULT 'SENT'::public."MessageStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isFiltered" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Message" OWNER TO kamulog_panel;

--
-- Name: News; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."News" (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    summary text,
    category text NOT NULL,
    "imageUrl" text,
    status text DEFAULT 'draft'::text NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."News" OWNER TO kamulog_panel;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text,
    title text NOT NULL,
    body text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    data jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "relatedAdId" text
);


ALTER TABLE public."Notification" OWNER TO kamulog_panel;

--
-- Name: Order; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    price text NOT NULL,
    plan text NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Order" OWNER TO kamulog_panel;

--
-- Name: Report; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Report" (
    id text NOT NULL,
    "reporterId" text NOT NULL,
    "reportedAdId" text NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Report" OWNER TO kamulog_panel;

--
-- Name: Review; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Review" (
    id text NOT NULL,
    "consultantId" text NOT NULL,
    "userId" text NOT NULL,
    "userName" text NOT NULL,
    rating double precision NOT NULL,
    comment text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Review" OWNER TO kamulog_panel;

--
-- Name: SalesRecord; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."SalesRecord" (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    "userId" text NOT NULL,
    "subscriptionId" text,
    plan text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'TRY'::text NOT NULL,
    "paymentMethod" text,
    status text DEFAULT 'COMPLETED'::text NOT NULL,
    notes text,
    "billingName" text,
    "billingEmail" text,
    "billingPhone" text,
    "billingAddress" text,
    "billingCity" text,
    "billingDistrict" text,
    "billingTaxNumber" text,
    "billingTaxOffice" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SalesRecord" OWNER TO kamulog_panel;

--
-- Name: ServicePackage; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."ServicePackage" (
    id text NOT NULL,
    "consultantId" text NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    description text NOT NULL,
    "durationMins" integer NOT NULL,
    includes text[],
    "iapProductId" text,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."ServicePackage" OWNER TO kamulog_panel;

--
-- Name: SiteSettings; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."SiteSettings" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "updatedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SiteSettings" OWNER TO kamulog_panel;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endsAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO kamulog_panel;

--
-- Name: SubscriptionPlan; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."SubscriptionPlan" (
    id text NOT NULL,
    name text NOT NULL,
    "interval" text DEFAULT 'monthly'::text NOT NULL,
    price double precision NOT NULL,
    description text,
    "badgeText" text,
    "yearlyDiscountRate" integer DEFAULT 20 NOT NULL,
    "includedQuota" integer DEFAULT 5 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SubscriptionPlan" OWNER TO kamulog_panel;

--
-- Name: SystemSetting; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."SystemSetting" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SystemSetting" OWNER TO kamulog_panel;

--
-- Name: TISDocument; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."TISDocument" (
    id text NOT NULL,
    institution text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "fileUrl" text NOT NULL,
    "fileName" text NOT NULL,
    "fileSize" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TISDocument" OWNER TO kamulog_panel;

--
-- Name: TISFile; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."TISFile" (
    id text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "fileUrl" text NOT NULL,
    "fileName" text NOT NULL,
    "fileSize" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TISFile" OWNER TO kamulog_panel;

--
-- Name: UsageRecord; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."UsageRecord" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    count integer DEFAULT 1 NOT NULL,
    month integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UsageRecord" OWNER TO kamulog_panel;

--
-- Name: User; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    phone text,
    password text NOT NULL,
    name text,
    "firstName" text,
    "lastName" text,
    "avatarUrl" text,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "subscriptionTier" text DEFAULT 'basic'::text,
    "employmentType" text,
    "ministryCode" integer,
    title text,
    credits integer DEFAULT 20 NOT NULL,
    "isPremium" boolean DEFAULT false NOT NULL,
    "premiumUntil" timestamp(3) without time zone,
    "aiTokens" integer DEFAULT 0 NOT NULL,
    "becayisListingLimit" integer,
    "listingQuotaOneTime" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    address text,
    city text,
    "cvApplicationsUsed" integer DEFAULT 0 NOT NULL,
    "cvChatTokens" integer DEFAULT 20 NOT NULL,
    district text,
    "emailChangeCode" text,
    "newEmail" text,
    "phoneNumber" text,
    "taxNumber" text,
    "taxOffice" text,
    "verificationCode" text,
    "verificationExpires" timestamp(3) without time zone,
    "emailVerified" timestamp(3) without time zone,
    "accountDeleted" boolean DEFAULT false NOT NULL,
    "accountDeletedAt" timestamp(3) without time zone,
    "accountFrozen" boolean DEFAULT false NOT NULL,
    "institutionName" text,
    "kvkkAccepted" boolean DEFAULT false NOT NULL,
    "lastEmailChangeDate" timestamp(3) without time zone,
    "lastLoginMethod" text,
    "lastPhoneChangeDate" timestamp(3) without time zone,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "postalCode" text,
    "userAgreementAccepted" boolean DEFAULT false NOT NULL,
    "tcKimlik" text,
    "yearsWorking" integer,
    "atamaYontemi" text,
    "hizmetSinifi" text,
    "istihdamTuru" text,
    unvan text,
    "isAriyor" boolean DEFAULT false
);


ALTER TABLE public."User" OWNER TO kamulog_panel;

--
-- Name: WhatsAppLog; Type: TABLE; Schema: public; Owner: kamulog_panel
--

CREATE TABLE public."WhatsAppLog" (
    id text NOT NULL,
    "phoneNumber" text NOT NULL,
    message text NOT NULL,
    "messageType" text DEFAULT 'VERIFICATION'::text NOT NULL,
    status text DEFAULT 'SENT'::text NOT NULL,
    "userId" text,
    "userEmail" text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WhatsAppLog" OWNER TO kamulog_panel;

--
-- Data for Name: AdminLog; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."AdminLog" (id, "adminId", action, "targetType", "targetId", details, "ipAddress", "userAgent", "createdAt") FROM stdin;
cmm3z14ls000bjx9bx913tdeo	cmm2skks10000jxlzdbf6bh7y	CREATE	JOB	\N	{"count":10,"source":"sample","message":"10 yeni ilan oluşturuldu"}	\N	\N	2026-02-26 21:24:19.216
cmm3zrx6a000njx9b0yad8391	cmm2skks10000jxlzdbf6bh7y	CREATE	JOB	\N	{"count":10,"source":"sample","message":"10 yeni ilan oluşturuldu"}	\N	\N	2026-02-26 21:45:09.298
cmm3zu9ea000zjx9b3cz6buyn	cmm2skks10000jxlzdbf6bh7y	CREATE	JOB	\N	{"count":10,"source":"sample","message":"10 yeni ilan oluşturuldu"}	\N	\N	2026-02-26 21:46:58.45
\.


--
-- Data for Name: BecayisListing; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."BecayisListing" (id, "ownerId", title, role, "institutionId", branch, "currentCity", "currentDistrict", "targetCity", "assignmentMethod", "assignmentMethodOther", description, "isPremium", "premiumUntil", status, "approvedById", "approvedAt", slug, "createdAt", "updatedAt", "adNumber", "pendingChanges", "viewCount") FROM stdin;
r5juckrkiue4eja78yp4c225	s9g0snoedqkz4b1blc5n4g23	İstanbul verilir	isci	hp092wmjsa83tlkf18pj4xt5	Kamu işçisi	İstanbul	Pendik	Tokat	iskur	\N	İstanbul verilir Tokat Amasya Çorum alınır işkur temizlik	f	\N	published	\N	2026-03-06 00:41:00.917	istanbul-verilir-2d68867c	2025-12-21 18:15:09.282	2026-03-06 12:24:35.056	BEC-P4C225	\N	0
b75ngb6nw9ma0lcngzwbjx5w	wp73wiwnejx8o7j6qfm1gxbu	Amasya ve çevre iller	isci	hp092wmjsa83tlkf18pj4xt5	İskur güvenlik görevlisi	Tekirdağ	Çorlu	Amasya	iskur	\N	Tekirdağ Çorlu ağız ve diş sağlığı merkezi verilir Amasya Samsun Tokat Çorum veya ilçeleri Ağız ve diş sağlığı merkezi veya hastaneleri tercih sebebi...	f	\N	published	\N	2026-03-06 00:41:00.917	amasya-ve-cevre-iller-a54fb220	2025-12-21 19:11:25.356	2026-03-06 00:41:00.919	BEC-WBJX5W	\N	0
dfkhy1b8jy1014wpi6qyjd6o	cxh3jpoxpup62s17g1jcwpn1	Becaiş	isci	hp092wmjsa83tlkf18pj4xt5	İşkur Temizlik Personeli	İzmir	Bornova	Adana	iskur	\N	İzmir Bornova Türkan Özilhan Devlet Hastanesi Verilir\r\nAdana Merkez Ve Merkez ilçeleri Alınır	f	\N	published	\N	2026-03-04 23:10:00.706	becais-7ce4e76a	2025-12-21 16:01:17.27	2026-03-05 23:59:07.789	BEC-QYJD6O	\N	0
u0pcxxnzeoim32v4f8ugq9dj	wqzkq4ar6n7qtbxilpspalns	İSTANBUL GÖÇ İDARESİ	isci	o55jefq8yc5f422ltbimoykq	SÜREKLİ İŞÇİ TEMİZLİK PERSONELİ İŞKUR	İstanbul	\N	Adana	iskur	\N	İSTANBUL GÖÇ İDARESİ VERİLİR AKDENİZ BÖLGESİ ALINIR.	f	\N	published	\N	2026-03-06 00:41:00.917	istanbul-goc-idaresi-184e52bb	2025-12-21 20:28:48.087	2026-03-06 00:41:00.919	BEC-UGQ9DJ	\N	0
f4egan3imxj00awq21rz1r0b	kh64rzpzwhme5u26aldh6poc	Teknik servis	isci	hp092wmjsa83tlkf18pj4xt5	Sürekli işçi	Siirt	Merkez	Yalova	khk	\N	Sürekli işçi teknik servis elemanı	f	\N	published	\N	2026-03-06 00:41:00.917	teknik-servis-677cb4e7	2025-12-29 09:59:08.893	2026-03-06 00:41:00.919	BEC-RZ1R0B	\N	0
a6uc7bs7h42oeg4k8x9becgy	paz057a8xd3yfljbt0xgprvp	Klinik destek İstanbul verilir Akdeniz bölgesi alınır	isci	hp092wmjsa83tlkf18pj4xt5	4\\D sürekli işçi klinik destek personeli	İstanbul	Kağıthane	Antalya	iskur	\N	BURDUR ANTALYA ISPARTA ALINIR \r\nSEYRNATEPE HAMŞDİYE ETFAL HASTANESİ VERİLİR	f	\N	published	cmm2skks10000jxlzdbf6bh7y	2026-03-06 00:00:14.389	klinik-destek-istanbul-verilir-akdeniz-bolgesi-alnr-4cf81155	2025-12-21 18:07:50.346	2026-03-06 00:00:14.39	BEC-9BECGY	\N	0
t9lktja2qhx2zl5kr928dlvh	zqlxv74m5qh6v1x1y2d2ibmn	Ambulans Sürücüsü	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK Ambulans Sürücüsü	İstanbul	Silivri	Karaman	khk	\N	İstanbul/Silivri Verilir,\r\nKonya,Karaman,Niğde, Aksaray,Mersin Alınır...	f	\N	published	\N	2026-03-06 00:41:00.917	ambulans-surucusu-29d3b0ce	2025-12-21 17:40:48.253	2026-03-06 00:41:00.919	BEC-28DLVH	\N	0
wopmvtctw36wrt581cd4sqo4	g7odi9x44etbse323h817mdp	AMBULANS SÜRÜCÜSÜ	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK AMBULANS SÜRÜCÜSÜ	İstanbul	Esenyurt	Balıkesir	khk	\N	İSTANBUL ESENYURT VERİLİR BALIKESİR MERKEZ TÜM İLÇELERİ SAVAŞTEPE/SOMA ALINIR.	f	\N	published	\N	2026-03-06 00:41:00.917	ambulans-surucusu-d1cd5f68	2025-12-21 18:29:15.051	2026-03-06 00:41:00.919	BEC-D4SQO4	\N	0
xqitfu9h6yi960p3mudt2nft	nrce9mwwwtovcd9nua6wkdnb	Becayiş	isci	hp092wmjsa83tlkf18pj4xt5	Îşçî	İstanbul	Şişli	İstanbul	iskur	\N	Prof Dr Cemil Taşcıoğlu Şehir Hastanesi Verilir \r\nBeylikdüzü Devlet Hastanesi Alınır \r\nİŞKUR Temizlik Personeli	f	\N	published	\N	2026-03-06 00:41:00.917	becayis-91a98773	2025-12-21 17:11:23.128	2026-03-06 00:57:45	BEC-DT2NFT	\N	0
vinbprknwyuag36fk3o823dp	lv5e8ktrhfo68whadixylu7s	Becaiş	isci	hp092wmjsa83tlkf18pj4xt5	Temizlik personeli  İşkur	İstanbul	Bakırköy	Batman	iskur	\N	İstanbul Bakırköy mazhar  osman ruh ve sinir hastahanesindeyim \r\nBatman merkez  gitmek istiyorum düşünen varsa  benimle iletişime geçmenizi rica ediyorum	f	\N	published	\N	2026-03-04 23:10:00.706	becais-b7e7a3ce	2025-12-29 16:08:34.996	2026-03-05 22:56:39.666	BEC-O823DP	\N	0
ya9npg5rtcsl3ip7dwv9e56u	pvksimzab1yg9zzvdv83dy9h	KHK İSTANBUL VERİ GİRİŞ	isci	hp092wmjsa83tlkf18pj4xt5	SÜREKLİ İŞÇİ VERİ GİRİŞ	İstanbul	Kadıköy	Ordu	khk	\N	İstanbul Göztepe Prof. Dr. Süleyman Yalçın Şehir Hastanesi verilir samsun, ordu ilçeleri kabul edilir.	f	\N	published	\N	2026-03-04 23:10:00.706	khk-istanbul-veri-giris-fb98c55c	2025-12-29 20:24:50.961	2026-03-07 00:41:52.348	BEC-V9E56U	\N	1
ju81jkctqqfhoib08gerwpo1	k3fkmoppvmkrasxnh1jb75c4	İŞKUR GÜVENLİK	isci	hp092wmjsa83tlkf18pj4xt5	İŞKUR GÜVENLİK	Ankara	Sincan	Ankara	iskur	\N	ANKARA SİNCAN İŞKUR GÜVENLİK VERİLİR DİĞER İLÇELER ALINIR…	f	\N	published	\N	2026-03-04 23:10:00.706	iskur-guvenlik-6d3595be	2025-12-29 20:43:45.106	2026-03-07 00:41:58.656	BEC-ERWPO1	\N	1
x1h7ca9exqjxa75ou67cj908	yepeiiitmvm2wxb1yhr2yi59	BECAYİŞ (Amasya -Tokat-Çorum-Samsun)	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK Veri Giriş Kontrol İşletmeni	İstanbul	\N	Amasya	khk	\N	Merhaba İstanbul Anadolu Yakasında İlçe Sağlık Müdürlüğünde görev yapmaktayım. Sağlık ve ailevi sebeplerden dolayı Amasya, Tokat, Çorum ve  Samsun illerine becayiş arıyorum.	f	\N	published	\N	2026-03-04 23:10:00.706	becayis-amasya-tokat-corum-samsun-40a4cbc0	2026-01-05 13:35:26.318	2026-03-06 22:54:10.409	BEC-7CJ908	\N	1
eoa7qth0azi8yz68qqufykqq	tgic7q5quns8gy8lr4qzcem5	Khk temizlik personeli becayiş	isci	hp092wmjsa83tlkf18pj4xt5	4D işçi khk temizlik personeli	İstanbul	Beyoğlu	İstanbul	khk	\N	4D khk Taksim eğitim araştırma hastanesinden Beylikdüzü ve çevre hastanelerine becayiş yapmak istiyorum 4D khk yitemizlik personeliyim	f	\N	published	\N	2026-03-03 00:06:05.567	khk-temizlik-personeli-becayis-7e14cafa	2025-12-29 15:43:35.918	2026-03-05 22:56:39.679	BEC-UFYKQQ	\N	0
ai6g2kyhmhsi1zga822wcbw7	tzwv5x5v6xa5ci37pcx8ayet	Temizlik personeli	isci	hp092wmjsa83tlkf18pj4xt5	Temizlik personeli	İstanbul	Şile	Zonguldak	iskur	\N	İstanbul şile devlet hastanesi verilir zonguldak ve Bartın alınır	f	\N	published	\N	2026-03-03 00:06:05.567	temizlik-personeli-ef5a2c0f	2025-12-29 08:24:58.652	2026-03-05 22:56:39.685	BEC-2WCBW7	\N	0
iypoldr8dwbwmbquafl0p87d	o6eu7tpq4e6dofi1erb8p0in	İstanbul - Edirne	isci	hp092wmjsa83tlkf18pj4xt5	Temizlik personeli	İstanbul	Zeytinburnu	Edirne	iskur	\N	Yedikule göğüs hastalıkları hastanesi verilir Edirne alınır	f	\N	published	\N	2026-03-03 00:06:05.567	istanbul-edirne-81eb3f25	2025-12-21 16:37:30.708	2026-03-07 10:29:30.867	BEC-L0P87D	\N	3
uz4t5yqepqz2d2ooa2o40493	ta9ia7djvx03b9ffo8qaqi55	Becaiş	isci	hp092wmjsa83tlkf18pj4xt5	4D sürekli işki (696) KHK	İstanbul	Şişli	Mardin	khk	\N	İstanbul verilir Mardin alınır	f	\N	published	\N	2026-03-03 00:06:05.567	becais-68893d4e	2025-12-29 17:49:17.674	2026-03-05 23:40:58.139	BEC-O40493	\N	0
g0cgcmutr7hlkr89wag3hnp4	fb0x3fjrqswozhheonm3vjlg	İstanbul verilir Sivas alınır klinik destek elemanı	isci	hp092wmjsa83tlkf18pj4xt5	Klinik destek elemanı	İstanbul	\N	Sivas	iskur	\N	İstanbul Pendik Marmara eah verilir Sivas	f	\N	published	\N	2026-03-06 00:41:00.917	istanbul-verilir-sivas-alnr-klinik-destek-eleman-22c276ff	2025-12-29 16:30:57.791	2026-03-06 00:44:49.943	BEC-G3HNP4	\N	0
daxdch0nz7zwvq7qqaw3un8h	tbubj1wpzxmqkpsac70srkfa	İstanbul VeriGiriş - Sakarya	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK sürekli işçi	İstanbul	Küçükçekmece	Sakarya	khk	\N	ADSH istanbul küçükçekemce VerişGiriş > Sakarya İzmit veya Ankara	f	\N	published	\N	2026-02-19 19:16:00	istanbul-verigiris-sakarya-b4f067d9	2026-02-14 19:46:06.228	2026-03-07 10:33:42.436	BEC-W3UN8H	\N	9
z6gbu7h9wjwko1kzj5dhfpc0	sv9g069kphsgc508vyu1w1tx	İstanbul göç idaresi	isci	o55jefq8yc5f422ltbimoykq	Sürekli işçi /Şoför	İstanbul	Eyüpsultan	Bayburt	iskur	\N	İstanbul Verilir:>Rize.Baybur.Erzurum .Artvin Alınır	f	\N	published	\N	\N	istanbul-goc-idaresi-792fcef6	2025-12-30 11:48:44.905	2026-03-06 03:43:34.951	BEC-DHFPC0	\N	0
pifc5204cnc4wrwac631ih7i	vyv7gbdcyw42omlkd56wvp06	İstanbul verilir Kayseri alinir	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK güvenlik görevlisi	İstanbul	Kadıköy	Kayseri	khk	\N	İstanbul göztepe suleyman yalcin sehir hastanesinde 15 yıldır guvenlik görevlisi olarak çalışmaktayım. Babam in Kayseri de tek yaşaması sebebi ile becayiş istiyorum. Calisma şartları ve çalışma ortamı istanbul dakika hastanelere göre çok iyi ve rahat	f	\N	published	\N	2026-03-03 00:06:05.567	istanbul-verilir-kayseri-alinir-345c510f	2025-12-29 08:42:42.769	2026-03-05 22:56:39.695	BEC-31IH7I	\N	0
olgyvde53743ogi9nbfqlr5x	qp6co0xsxrp9fsfj48v9uavc	Becaiş	isci	hp092wmjsa83tlkf18pj4xt5	Temizlik Personeli	Eskişehir	Tepebaşı	Eskişehir	iskur	\N	Eskişehir Merkez Yunus Emre Devlet Hastanesinde Çalışıyorum Eskişehir İlçelerine Becaiş Arıyorum	f	\N	published	\N	2026-03-03 00:06:05.567	becais-8234736c	2025-12-29 12:28:40.112	2026-03-05 22:56:39.697	BEC-FQLR5X	\N	0
oexdxzt1habf1zpwylwxzrrw	kicmn9wivk519cdw4uicz2e1	VERi GİRİŞ KHK	isci	hp092wmjsa83tlkf18pj4xt5	696 khk veri giriş	Diyarbakır	Bağlar	Elazığ	khk	\N	Diyarbakir kadin dogum ve cocuk hastanesi veri giris personeliyim Elazig iline becayis aramaktayim eş durumu	f	\N	published	\N	2026-03-03 00:06:05.567	veri-giris-khk-f454b35c	2025-12-29 21:35:09.307	2026-03-06 04:33:50.577	BEC-WXZRRW	\N	0
x0gmay1s5xhgjk4nw4eqf5ov	xonoind28e9fyik7ysq6mdsf	İSTANBUL --->>> ORDU	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK SÜREKLİ İŞÇİ ( GÜVENLİK GÖREVLİSİ )	İstanbul	Beylikdüzü	Ordu	khk	\N	İstanbul'dan Ordu'ya gitmek istiyorum.	f	\N	published	\N	2026-03-03 00:06:05.567	istanbul-ordu-761c07fc	2025-12-30 17:42:15.238	2026-03-06 11:57:45.249	BEC-EQF5OV	\N	0
qyio1eraslcszry14drue3qp	eqmju8qgech9a57a0wkfxuc9	4D VERİ GİRİŞ BECAYİŞ	isci	hp092wmjsa83tlkf18pj4xt5	4D VERİ GİRİŞ ELEMANI SÜREKLİ İŞÇİ	İstanbul	Pendik	Gümüşhane	khk	\N	İSTANBUL PENDİK EĞİTİM VE ARAŞTIRMA HASTANESİ VERİLİR GÜMÜŞHANE ERZİNCAN ALINIR.( Sürekli işçi 4d Veri giriş elemanı)	f	\N	published	\N	2026-03-03 00:06:05.567	4d-veri-giris-becayis-570d2ece	2025-12-29 13:43:05.733	2026-03-06 11:58:36.569	BEC-RUE3QP	\N	0
fdnqlgu5vqkt3uqlbhm82lrr	kh3cs5gv648929k4q9tvkd4t	KHK TEMİZLİK	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK	İstanbul	\N	Samsun	khk	\N	696 KHK TEMİZLİK \r\n\r\nİSTANBUL ÇEKMEKÖY DEVLET HASTANESİ VERİLİR \r\n\r\nSAMSUN SİNOP KASTAMONU ALINIR	f	\N	published	\N	2026-03-03 00:06:05.567	khk-temizlik-18b97745	2025-12-29 13:12:27.782	2026-03-06 12:47:11.876	BEC-M82LRR	\N	0
bku2p6k0e4ihbslraprodgrp	yyjmdf3tba840u7slizouds4	7422.17 BİLGİSAYAR SİSTEM KURULUM BAKIM ONARIM VE ARIZA GİDERME ELEMANI	isci	hp092wmjsa83tlkf18pj4xt5	SÜREKLİ İŞÇİ (696)	İstanbul	\N	Ankara	khk	\N	7422.17 BİLGİSAYAR SİSTEM KURULUM BAKIM ONARIM VE ARIZA GİDERME ELEMANI	f	\N	published	\N	2026-03-03 00:06:05.567	742217-bilgisayar-sistem-kurulum-bakim-onarim-ve-ariza-giderme-elemani-9ac16432	2025-12-30 07:16:36.309	2026-03-06 21:18:28.581	BEC-RODGRP	\N	1
rjxz1mfzh7d65d92va5582tr	joiuwya3oudbpm7pa9l136w4	İstanbul 112 Anadolu konuta	isci	hp092wmjsa83tlkf18pj4xt5	İşçi temizlik	İstanbul	Üsküdar	Diyarbakır	iskur	\N	Diyarbakır Mardin Batman ileri ile becayiş	f	\N	published	\N	2026-03-03 00:06:05.567	istanbul-112-anadolu-konuta-18401964	2025-12-31 03:25:59.947	2026-03-07 00:38:43.271	BEC-5582TR	\N	4
kycqc9x7jl1m9hs1zg5procv	ruxmpphltq6kbgvkkxq7af6c	İzmir il İçi Becaiş İstiyorum	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK / Sürekli İşçi Temizlik Personeli	İzmir	Çiğli	İzmir	khk	\N	Çocuğumun sağlığından dolayı çiğli bölge hastanesinde olan görev yerimi menemen devlet hastanesine becaiş istiyorum	f	\N	published	\N	2026-03-03 00:06:05.567	izmir-il-ici-becais-istiyorum-9f23b786	2025-12-29 14:22:29.962	2026-03-07 00:41:29.713	BEC-5PROCV	\N	1
c8d2d40rxg51ikq5acc5ur0t	fclhlfldxbor7gwpl86q3cwi	Biyomedikal	isci	hp092wmjsa83tlkf18pj4xt5	4D sürekli İşkur işçi	İzmir	Foça	Çorum	iskur	\N	Çorum Amasya Merzifon Samsun olur	f	\N	published	\N	2026-03-03 00:06:05.567	biyomedikal-f3db84fe	2025-12-30 17:13:56.044	2026-03-07 08:30:02.362	BEC-C5UR0T	\N	2
cmmg5zjgs0004jx8vzmsny9dx	cmmg4lkqp0001jx8v3tcdrh4a	TEST	isci	hp092wmjsa83tlkf18pj4xt5	Güvenlik Görevlisi	İstanbul	Sancaktepe	Adana	696 KHK	\N	bsbsbsbsbs	t	2026-03-14 10:29:32.477	published	cmm2skks10000jxlzdbf6bh7y	2026-03-07 10:27:08.936	test-mmg5zjfp	2026-03-07 10:12:16.586	2026-03-07 10:38:07.286	BCY-GFDTJ3	\N	4
i9wydkufr1dzkwewproncji0	v8zox4vyw1cbiec7i4fpksml	Esma Sultan Atalı	isci	hp092wmjsa83tlkf18pj4xt5	696khk temizlik	İstanbul	Sancaktepe	Antalya	khk	\N	İstanbul pendik devlet hastanesi 696khk temizlik verilir.Manavgat,Serik,Kepez ,Alanya alınır.	f	\N	published	\N	2026-03-03 00:06:05.567	esma-sultan-atal-14be1f38	2025-12-29 13:12:04.424	2026-03-05 22:56:39.7	BEC-ONCJI0	\N	0
rt7aza0bg8wk9q9xtkdytbcl	wtpkkpdql4dzqirrx345ygw0	Becayiş	isci	hp092wmjsa83tlkf18pj4xt5	Temizlik khk	İstanbul	Fatih	Elazığ	khk	\N	İstanbul eğitim ve araştırma hastanesi verilir Elazığ alınır 696 KYK temizlik	f	\N	published	\N	2026-03-03 00:06:05.567	becayis-e3a58f08	2025-12-29 13:16:24.555	2026-03-05 22:56:39.705	BEC-DYTBCL	\N	0
iazfnclsmivjprqee4ndjak9	y0tw81hrjfwi92ikt84sfkp3	Becayiş	isci	hp092wmjsa83tlkf18pj4xt5	İş kur	Kocaeli	Gebze	İzmir	iskur	\N	GEBZE Fatih devlet hastanesi verilir. “İŞ KUR GÜVENLİK,, BALIKESİR, MUĞLA,İZMİR ANTALYA,DENİZLİ EGE VE ÇEVRELERİ ALINIR.	f	\N	published	\N	2026-03-03 00:06:05.567	becayis-dbfa116a	2025-12-29 14:02:57.762	2026-03-05 22:56:39.71	BEC-NDJAK9	\N	0
uiasl8mctqdbngnatcb782uy	efl70ofthkmrdw9w12wazneg	İzmir İçi Klinik Destek Elemanı Becaiş	isci	hp092wmjsa83tlkf18pj4xt5	Sürekli İşçi / Klinik Destek Elemanı	İzmir	Çiğli	İzmir	iskur	\N	İşkur Sürekli İşçi Klinik Destek Elemanıyım İzmir Çiğli Bölge Hastanesinden Becaiş İstiyorum\r\n(seferihisar,aliağa,foça,bayraklı önceliktir)	f	\N	published	\N	2026-03-03 00:06:05.567	izmir-ici-klinik-destek-eleman-becais-41b8653e	2025-12-29 14:39:22.848	2026-03-05 22:56:39.713	BEC-B782UY	\N	0
uzigi8rbyl0h53z6o0berujg	u6v935g4fs6bo236ouw699gm	4D İŞKUR GÜVENLİK	isci	hp092wmjsa83tlkf18pj4xt5	Güvenlik	İstanbul	Bakırköy	Ordu	iskur	\N	İstanbul Bakırköy Dr. Sadi Konuk EAH güvenlik işkur verilir. Karadeniz illeri ile becayiş yapılır.	f	\N	published	\N	2026-03-03 00:06:05.567	4d-iskur-guvenlik-adfb01b5	2025-12-29 17:48:27.967	2026-03-05 22:56:39.715	BEC-BERUJG	\N	0
tlcp1batl7fe4et79vshuznv	cszotjy1n5dnb9ch5i2dii38	696 KHK BECAYİŞ	isci	hp092wmjsa83tlkf18pj4xt5	696 KHK VERİ GİRİŞ	İstanbul	Bakırköy	Muğla	khk	\N	İstanbul İl Sağlık Müdürlüğü 696 KHK veri giriş verilir Muğla il ve ilçeleri alınır	f	\N	published	\N	2026-03-03 00:06:05.567	696-khk-becayis-3b739c44	2025-12-30 06:52:29.24	2026-03-05 22:56:39.719	BEC-SHUZNV	\N	0
xm9ysl56hbmn0yzr4e4syyab	wjjhizxazzlxcawrxvm6mhah	Bitlis devlet hastanesi verilir Antalya Muğla Aydın Mersin Denizli İzmir alinir696 KHK	isci	hp092wmjsa83tlkf18pj4xt5	Daimi isci	Bitlis	Merkez	Antalya	khk	\N	Bitlis verilir Antalya Muğla Aydın Mersin Denizli İzmir alınır 696 KHK temizlik personeli	f	\N	published	\N	2026-03-03 00:06:05.567	bitlis-devlet-hastanesi-verilir-antalya-mugla-aydn-mersin-denizli-izmir-alinir696-khk-d0b28877	2025-12-29 12:54:51.267	2026-03-05 22:56:39.727	BEC-4SYYAB	\N	0
aib6g4y546a8qlzi15m49sa9	bqb8m3plv8jk7w6csxxeoodq	Becayiş	isci	rlxr2watuccx0ywb3xctkmnq	4D / Kamu İşçisi	İstanbul	Esenler	Gaziantep	khk	\N	İstanbul dan Gaziantep'e becayiş yapmak istiyorum ilgilenen arkadaşlar bana yazabilir  . Kültür ve Turizm Bakanlığı 4D sürekli işçi	f	\N	published	\N	2026-03-03 00:06:05.567	becayis-46b1805e	2025-12-30 07:36:06.029	2026-03-05 23:27:36.427	BEC-M49SA9	\N	0
hp7exc0bx1dstsbn6r2t79tx	omatip5wfgmo4essoas6ue0e	İŞKUR GÜVENLİK	isci	hp092wmjsa83tlkf18pj4xt5	4d güvenlik	İstanbul	Bakırköy	Bitlis	iskur	\N	İstanbul verilir bitlis veya siirt alınır işkur 4d güvenlik	f	\N	published	\N	2026-03-03 00:06:05.567	iskur-guvenlik-12303f2d	2025-12-29 19:53:09.586	2026-03-06 02:46:23.743	BEC-2T79TX	\N	0
\.


--
-- Data for Name: BecayisMessage; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."BecayisMessage" (id, "senderId", "receiverId", "listingId", content, "isRead", "createdAt", "isFiltered", status) FROM stdin;
\.


--
-- Data for Name: CV; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."CV" (id, "userId", title, data, template, "pdfPath", "pdfGeneratedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CVAnalysis; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."CVAnalysis" (id, "userId", "cvId", "jobId", score, feedback, "createdAt") FROM stdin;
\.


--
-- Data for Name: ChatSession; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."ChatSession" (id, "userId", messages, "cvId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Consultant; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Consultant" (id, "userId", name, title, category, bio, specializations, "experienceYears", "avatarUrl", rating, "reviewCount", "isOnline", "isFeatured", "completedConsultations", "isActive", "createdAt", "consultantCredits", "creditPrice", iban, "sessionFeeJeton", email, phone) FROM stdin;
cmm42rkkn0002jxmhnwzv4x7x	\N	Suat Hayri ŞAHİN	Uzm.	mali	biyografi haberci	{Mobbing,Test}	10	\N	0	0	t	f	0	t	2026-02-26 23:08:51.814	2	50	\N	5	\N	\N
cmm42nwma0000jxmhto5wogyl	\N	SEDAT ŞAHİN	Avukat	hukuki	deneme, deneme, deneme, 1234	{"iş Hukuku",Mobbing}	5	\N	0	0	f	f	0	t	2026-02-26 23:06:00.802	0	0	\N	5	\N	\N
cmm42py1q0001jxmh7dt7sojj	\N	Şahin SEDAT	Dr.	idari	Test, Deneme, Test, Goshtlama	{"Memur hakları"}	2	\N	0	0	t	f	0	t	2026-02-26 23:07:35.938	0	0	\N	5	\N	\N
\.


--
-- Data for Name: ConsultantApplication; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."ConsultantApplication" (id, name, email, phone, category, specialization, bio, "experienceYears", "cvUrl", "diplomaUrl", status, "rejectionReason", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ConsultantPayout; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."ConsultantPayout" (id, "consultantId", period, "earnedJetons", "jetonRate", "totalTL", "commissionRate", "commissionTL", "netPayoutTL", status, "paidAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: ConsultationRequest; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."ConsultationRequest" (id, "userId", "consultantId", "packageId", description, "aiBriefing", status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Conversation" (id, "userId", "consultantId", category, "lastMessage", "lastMessageAt", "unreadCount", "createdAt") FROM stdin;
\.


--
-- Data for Name: CookieConsent; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."CookieConsent" (id, "ipAddress", "userAgent", "userId", "consentType", "acceptedAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: Coupon; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Coupon" (id, code, name, "discountType", "discountValue", "validFrom", "validUntil", "maxUsage", "usageCount", "planRestriction", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FavoriteAd; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."FavoriteAd" (id, "userId", "listingId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Institution; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Institution" (id, name, "isActive", "order", "createdAt") FROM stdin;
a8gx62j41mnyuu38ztaxqdqe	ADALET BAKANLIĞI	t	2	2026-02-26 06:40:39.186
m9x11qn7ud86mxiq5ex4fr9j	GSB / KYK	t	3	2026-02-26 06:40:39.192
dixfup1md34r7cy7zexlmt5x	Aile, Çalışma ve Sosyal Hizmetler Bakanlığı	t	7	2026-02-26 06:40:39.195
lwf5tl82ybsyodz9z1i2913h	Çay  İşletmeleri Genel Müdürlüğü	t	17	2026-02-26 06:40:39.2
yf00sjtznk4rujwhtcff4uw1	Çevre ve Şehircilik Bakanlığı	t	18	2026-02-26 06:40:39.204
q9b1iple056y3gtsp7ts0ef5	Diyanet İşleri Başkanlığı	t	21	2026-02-26 06:40:39.207
pxl0xj05ui3m0lzh9jqbuf43	Elektrik Üretim A.Ş. Genel Müdürlüğü	t	23	2026-02-26 06:40:39.21
sdohjsxihx6ff45lskw6v8p5	Emniyet Genel Müdürlüğü	t	25	2026-02-26 06:40:39.213
g1i8v8uvirxiqf5tw93rbixs	Enerji ve Tabii Kaynaklar Bakanlığı	t	27	2026-02-26 06:40:39.216
wnw8tb695aff0aagmhgv557w	Gençlik ve Spor Bakanlığı	t	31	2026-02-26 06:40:39.223
bx30zfklzru1rfj8arzztzol	Hazine ve Maliye Bakanlığı	t	33	2026-02-26 06:40:39.23
o55jefq8yc5f422ltbimoykq	İçişleri Bakanlığı	t	35	2026-02-26 06:40:39.234
o8n082m6j8e8hrlj14qpsn9b	Karayolları Genel Müdürlüğü	t	40	2026-02-26 06:40:39.238
ysjw4htcvkn169ppo98zw3pj	Kıyı Emniyeti Genel Müdürlüğü	t	41	2026-02-26 06:40:39.241
rlxr2watuccx0ywb3xctkmnq	Kültür ve Turizm Bakanlığı	t	42	2026-02-26 06:40:39.244
rsmjd1kt3xfkkr6ggx995efm	Milli Eğitim Bakanlığı	t	47	2026-02-26 06:40:39.247
hwp9bw561prflevs1u7pa4w9	Millî Savunma Bakanlığı	t	48	2026-02-26 06:40:39.249
gwemd5bybrh5vm4vrb06hhye	Orman Genel Müdürlüğü	t	51	2026-02-26 06:40:39.252
a8i68185e9pokz698aq7wyx9	PTT Genel Müdürlüğü	t	52	2026-02-26 06:40:39.255
hp092wmjsa83tlkf18pj4xt5	Sağlık Bakanlığı	t	55	2026-02-26 06:40:39.258
etfrypw1eqt86niun930d5id	Sosyal Güvenlik Kurumu	t	58	2026-02-26 06:40:39.261
n8b0ivfr31vz6x15frs4i2n0	Tarım ve Orman Bakanlığı	t	61	2026-02-26 06:40:39.265
t62j45g6zyxqsk47s2hnvyv9	TCDD Taşımacılık A.Ş. Genel Müdürlüğü	t	62	2026-02-26 06:40:39.268
twf8t1jhce8xbdusdsf29420	T.C. Devlet Demiryolları  Genel Müdürlüğü	t	63	2026-02-26 06:40:39.272
jwdqsoex93hr6vg1u1gbej8h	Ticaret Bakanlığı	t	64	2026-02-26 06:40:39.274
m3j8wxfxy07e3j0y8e1pta69	Türkiye Elektrik İletim A.Ş. (TEİAŞ) Genel Müdürlüğü	t	68	2026-02-26 06:40:39.277
v50f2my2tkorg6ddrsnw4k3g	Türkiye İş Kurumu (İŞKUR)	t	70	2026-02-26 06:40:39.281
n9u28jfv3c4y8bulu2f8vhd9	Ulaştırma ve Altyapı Bakanlığı	t	73	2026-02-26 06:40:39.286
s2o3yi697zcxdgyqsk4yxzoa	Sağlık Bilimleri Üniversitesi	t	79	2026-02-26 06:40:39.292
ay6q6946ujk3gcusx05tpd7s	Yüksek Öğretim Kurumu	t	80	2026-02-26 06:40:39.296
qnofgv5np2w2ttfspric1ukg	PAMUKKALE ÜNİVERSİTESİ REKTÖRLÜĞÜ	t	81	2026-02-26 06:40:39.3
boj3ec51ahf5n2uifdz5lmgw	Orta Doğu Teknik Üniversitesi	t	82	2026-02-26 06:40:39.302
yu6mjr3ac0s7rddh4anbwjpo	Süleyman Demirel Üniversitesi	t	83	2026-02-26 06:40:39.305
j8ucj7a3yn9dfr7n08t3pes0	İzmir Demokrasi Üniversitesi	t	84	2026-02-26 06:40:39.308
\.


--
-- Data for Name: JobListing; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."JobListing" (id, code, title, company, location, description, requirements, type, "sourceUrl", "applicationUrl", salary, deadline, "employerPhone", "createdAt", "updatedAt") FROM stdin;
cmm3z14ll0000jx9bbdri8dtl	\N	Belediye Zabıta Memuru Alımı	İŞKUR	Mersin	İŞKUR bünyesinde Belediye Zabıta Memuru Alımı pozisyonu için personel aranmaktadır. Mersin ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	40.000 - 55.000 TL	2026-04-05 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3z14ll0002jx9bdyv45zdz	\N	İl Milli Eğitim Müdürlüğü Öğretmen Alımı	Milli Eğitim Bakanlığı	Trabzon	Milli Eğitim Bakanlığı bünyesinde İl Milli Eğitim Müdürlüğü Öğretmen Alımı pozisyonu için personel aranmaktadır. Trabzon ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	50.000 - 70.000 TL	2026-05-17 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3z14ll0003jx9bubxh0v0e	\N	Adalet Bakanlığı Katip Alımı	Karayolları Genel Müdürlüğü	Samsun	Karayolları Genel Müdürlüğü bünyesinde Adalet Bakanlığı Katip Alımı pozisyonu için personel aranmaktadır. Samsun ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	60.000 - 90.000 TL	2026-04-26 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3z14ll0004jx9brzmjjadw	\N	Belediye Zabıta Memuru Alımı	İŞKUR	Diyarbakır	İŞKUR bünyesinde Belediye Zabıta Memuru Alımı pozisyonu için personel aranmaktadır. Diyarbakır ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	30.000 - 45.000 TL	2026-04-01 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3z14ll0005jx9bokpvpt9k	\N	Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı	Karayolları Genel Müdürlüğü	Adana	Karayolları Genel Müdürlüğü bünyesinde Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı pozisyonu için personel aranmaktadır. Adana ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	35.000 - 50.000 TL	2026-05-19 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3z14ll0006jx9bmrefjmdt	\N	İl Milli Eğitim Müdürlüğü Öğretmen Alımı	İŞKUR	Konya	İŞKUR bünyesinde İl Milli Eğitim Müdürlüğü Öğretmen Alımı pozisyonu için personel aranmaktadır. Konya ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	30.000 - 45.000 TL	2026-05-25 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3z14ll0008jx9b8btqqvsm	\N	Vergi Dairesi Başkanlığı Memur Alımı	İŞKUR	Gaziantep	İŞKUR bünyesinde Vergi Dairesi Başkanlığı Memur Alımı pozisyonu için personel aranmaktadır. Gaziantep ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	40.000 - 55.000 TL	2026-04-29 21:24:19.119	\N	2026-02-26 21:24:19.209	2026-02-26 21:24:19.209
cmm3zrx64000djx9bqmr8klns	\N	İl Milli Eğitim Müdürlüğü Öğretmen Alımı	Maliye Bakanlığı	Bursa	Maliye Bakanlığı bünyesinde İl Milli Eğitim Müdürlüğü Öğretmen Alımı pozisyonu için personel aranmaktadır. Bursa ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	\N	2026-05-06 21:45:09.267	\N	2026-02-26 21:45:09.269	2026-02-26 21:45:09.269
cmm3zrx64000ejx9bowvuus81	\N	İl Milli Eğitim Müdürlüğü Öğretmen Alımı	Ankara Büyükşehir Belediyesi	Mersin	Ankara Büyükşehir Belediyesi bünyesinde İl Milli Eğitim Müdürlüğü Öğretmen Alımı pozisyonu için personel aranmaktadır. Mersin ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	35.000 - 50.000 TL	2026-04-08 21:45:09.267	\N	2026-02-26 21:45:09.269	2026-02-26 21:45:09.269
cmm3zrx64000fjx9bb24as2pi	\N	Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı	İçişleri Bakanlığı	Kayseri	İçişleri Bakanlığı bünyesinde Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı pozisyonu için personel aranmaktadır. Kayseri ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	\N	2026-04-18 21:45:09.267	\N	2026-02-26 21:45:09.269	2026-02-26 21:45:09.269
cmm3zrx64000hjx9bhinv8sub	\N	Devlet Hastanesi Hemşire Alımı	Adalet Bakanlığı	İzmir	Adalet Bakanlığı bünyesinde Devlet Hastanesi Hemşire Alımı pozisyonu için personel aranmaktadır. İzmir ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	35.000 - 50.000 TL	2026-03-30 21:45:09.267	\N	2026-02-26 21:45:09.269	2026-02-26 21:45:09.269
cmm3zu9e7000ojx9bsg4dc548	\N	Tapu Kadastro Müdürlüğü Memur Alımı	Ankara Büyükşehir Belediyesi	Ankara	Ankara Büyükşehir Belediyesi bünyesinde Tapu Kadastro Müdürlüğü Memur Alımı pozisyonu için personel aranmaktadır. Ankara ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	25.000 - 35.000 TL	2026-04-03 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000qjx9b80ll1t62	\N	Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı	İçişleri Bakanlığı	Gaziantep	İçişleri Bakanlığı bünyesinde Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı pozisyonu için personel aranmaktadır. Gaziantep ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	25.000 - 35.000 TL	2026-04-03 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000rjx9bd1gwinps	\N	İl Milli Eğitim Müdürlüğü Öğretmen Alımı	Milli Eğitim Bakanlığı	Bursa	Milli Eğitim Bakanlığı bünyesinde İl Milli Eğitim Müdürlüğü Öğretmen Alımı pozisyonu için personel aranmaktadır. Bursa ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	\N	2026-04-02 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000sjx9ba6ssj17l	\N	Adalet Bakanlığı Katip Alımı	İstanbul Valiliği	Gaziantep	İstanbul Valiliği bünyesinde Adalet Bakanlığı Katip Alımı pozisyonu için personel aranmaktadır. Gaziantep ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	50.000 - 70.000 TL	2026-04-01 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000tjx9bkqy10li2	\N	İnsan Kaynakları Müdürü	FinPro Danışmanlık	Antalya	FinPro Danışmanlık bünyesinde İnsan Kaynakları Müdürü pozisyonu için personel aranmaktadır. Antalya ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	En az 2 yıl deneyim. İlgili bölüm mezuniyeti. Takım çalışmasına yatkınlık. İyi derecede iletişim becerileri.	PRIVATE	\N	\N	\N	2026-04-09 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000ujx9bmozimyr8	\N	Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı	İçişleri Bakanlığı	Bursa	İçişleri Bakanlığı bünyesinde Çevre ve Şehircilik İl Müdürlüğü Mühendis Alımı pozisyonu için personel aranmaktadır. Bursa ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	55.000 - 80.000 TL	2026-04-13 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000vjx9bf8mmb0uz	\N	Vergi Dairesi Başkanlığı Memur Alımı	Adalet Bakanlığı	Diyarbakır	Adalet Bakanlığı bünyesinde Vergi Dairesi Başkanlığı Memur Alımı pozisyonu için personel aranmaktadır. Diyarbakır ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	40.000 - 55.000 TL	2026-05-18 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000wjx9b5hdy0mah	\N	Muhasebe ve Finans Sorumlusu	PrimeSales Tic.	Trabzon	PrimeSales Tic. bünyesinde Muhasebe ve Finans Sorumlusu pozisyonu için personel aranmaktadır. Trabzon ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	En az 2 yıl deneyim. İlgili bölüm mezuniyeti. Takım çalışmasına yatkınlık. İyi derecede iletişim becerileri.	PRIVATE	\N	\N	25.000 - 35.000 TL	2026-03-31 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
cmm3zu9e7000xjx9b0qf4vb7a	\N	Vergi Dairesi Başkanlığı Memur Alımı	Ankara Büyükşehir Belediyesi	Bursa	Ankara Büyükşehir Belediyesi bünyesinde Vergi Dairesi Başkanlığı Memur Alımı pozisyonu için personel aranmaktadır. Bursa ilinde görev yapılacaktır. Detaylı bilgi için başvuru yapınız.	KPSS puanı gereklidir. En az lisans mezuniyeti. İlgili alanda deneyim tercih sebebidir.	PUBLIC	\N	\N	45.000 - 65.000 TL	2026-04-13 21:46:58.444	\N	2026-02-26 21:46:58.446	2026-02-26 21:46:58.446
\.


--
-- Data for Name: KariyerChatMessage; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."KariyerChatMessage" (id, "roomId", "senderId", "senderType", content, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: KariyerChatRoom; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."KariyerChatRoom" (id, "userId", "consultantId", status, "closedAt", "closedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KariyerConsultant; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."KariyerConsultant" (id, name, phone, title, description, "avatarUrl", "isActive", "userId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KariyerConsultantRating; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."KariyerConsultantRating" (id, "roomId", "consultantId", "userId", rating, comment, "createdAt") FROM stdin;
\.


--
-- Data for Name: KariyerSubscription; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."KariyerSubscription" (id, "userId", plan, status, "orderCode", "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Media; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Media" (id, filename, url, "mimeType", size, "categoryId", link, "isActive", "createdAt") FROM stdin;
\.


--
-- Data for Name: MediaCategory; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."MediaCategory" (id, name, slug, "createdAt") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Message" (id, "conversationId", "senderId", text, type, "fileUrl", "fileName", status, "createdAt", "isFiltered") FROM stdin;
\.


--
-- Data for Name: News; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."News" (id, title, content, summary, category, "imageUrl", status, views, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Notification" (id, "userId", title, body, type, "isRead", data, "createdAt", "relatedAdId") FROM stdin;
cmmax6wsq0001jxt59cug3870	k3fkmoppvmkrasxnh1jb75c4	İlanınız beğenildi! ❤️	Ankara → Ankara ilanınız favorilere eklendi.	becayis_favorite	f	null	2026-03-03 18:07:13.033	ju81jkctqqfhoib08gerwpo1
cmmax6yj30003jxt5896k8slk	pvksimzab1yg9zzvdv83dy9h	İlanınız beğenildi! ❤️	İstanbul → Ordu ilanınız favorilere eklendi.	becayis_favorite	f	null	2026-03-03 18:07:15.28	ya9npg5rtcsl3ip7dwv9e56u
cmmax6zpe0005jxt51s50lbtx	lv5e8ktrhfo68whadixylu7s	İlanınız beğenildi! ❤️	İstanbul → Batman ilanınız favorilere eklendi.	becayis_favorite	f	null	2026-03-03 18:07:16.802	vinbprknwyuag36fk3o823dp
cmmax70gl0007jxt5uoenwbue	cxh3jpoxpup62s17g1jcwpn1	İlanınız beğenildi! ❤️	İzmir → Adana ilanınız favorilere eklendi.	becayis_favorite	f	null	2026-03-03 18:07:17.782	dfkhy1b8jy1014wpi6qyjd6o
cmmc7ffrs0009jxrsudcpfmgz	pvksimzab1yg9zzvdv83dy9h	İlanınız beğenildi! ❤️	İstanbul → Ordu ilanınız favorilere eklendi.	becayis_favorite	f	null	2026-03-04 15:41:33.208	ya9npg5rtcsl3ip7dwv9e56u
cmmc7fgf3000bjxrsmp7efee0	lv5e8ktrhfo68whadixylu7s	İlanınız beğenildi! ❤️	İstanbul → Batman ilanınız favorilere eklendi.	becayis_favorite	f	null	2026-03-04 15:41:34.047	vinbprknwyuag36fk3o823dp
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Order" (id, "userId", title, description, price, plan, status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Report; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Report" (id, "reporterId", "reportedAdId", reason, status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Review" (id, "consultantId", "userId", "userName", rating, comment, "createdAt") FROM stdin;
\.


--
-- Data for Name: SalesRecord; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."SalesRecord" (id, "orderNumber", "userId", "subscriptionId", plan, amount, currency, "paymentMethod", status, notes, "billingName", "billingEmail", "billingPhone", "billingAddress", "billingCity", "billingDistrict", "billingTaxNumber", "billingTaxOffice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServicePackage; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."ServicePackage" (id, "consultantId", name, price, description, "durationMins", includes, "iapProductId", "isActive") FROM stdin;
\.


--
-- Data for Name: SiteSettings; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."SiteSettings" (id, key, value, "updatedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."Subscription" (id, "userId", "planId", status, "startedAt", "endsAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: SubscriptionPlan; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."SubscriptionPlan" (id, name, "interval", price, description, "badgeText", "yearlyDiscountRate", "includedQuota", "isActive", "order", "createdAt") FROM stdin;
\.


--
-- Data for Name: SystemSetting; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."SystemSetting" (id, key, value, "updatedAt") FROM stdin;
cmme4k9ur0000jxf1lj6uol8r	becayis_listing_cost	1	2026-03-07 01:15:15.518
\.


--
-- Data for Name: TISDocument; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."TISDocument" (id, institution, role, title, description, "fileUrl", "fileName", "fileSize", "isActive", "createdAt", "updatedAt") FROM stdin;
cmm42h2890000jxtu78gyphr5	Aile, Çalışma ve Sosyal Hizmetler Bakanlığı	isci	AİLE BAKANLIĞI TİS		https://kamulog.net/media/tis/AİLE_BAKANLIĞI_SÖZLEŞME_METNİ.pdf	AİLE_BAKANLIĞI_SÖZLEŞME_METNİ.pdf	8299035	t	2026-02-26 23:00:41.481	2026-02-26 23:00:41.481
cmm42h28j0001jxtu7spyt72o	Elektrik Üretim A.Ş. Genel Müdürlüğü	isci	EÜAŞ TİS 2025-2026		https://kamulog.net/media/tis/EÜAŞ_TİS.pdf	EÜAŞ_TİS.pdf	49004307	t	2026-02-26 23:00:41.491	2026-02-26 23:00:41.491
cmm42h28n0002jxtup4z6t9r9	Karayolları Genel Müdürlüğü	isci	Karayolları Genel Müdürlüğü TİS 2025-2026		https://kamulog.net/media/tis/KGM_17_09_2025.pdf	KGM_17_09_2025.pdf	41557680	t	2026-02-26 23:00:41.495	2026-02-26 23:00:41.495
cmm42h28r0003jxtuihbl4vgo	Milli Eğitim Bakanlığı	isci	Milli Eğitim Bakanlığı TİS 2025-2026		https://kamulog.net/media/tis/Milli_Eğitim_Bakanlığı_Tis_01.01.2025-31.12.2026.pdf	Milli_Eğitim_Bakanlığı_Tis_01.01.2025-31.12.2026.pdf	5142130	t	2026-02-26 23:00:41.499	2026-02-26 23:00:41.499
cmm42h28w0004jxtu8p3gfrxi	Orta Doğu Teknik Üniversitesi	isci	ODTÜ TİS 2025-2026		https://kamulog.net/media/tis/ODTÜ_TİS_2025-2026.pdf	ODTÜ_TİS_2025-2026.pdf	11918822	t	2026-02-26 23:00:41.504	2026-02-26 23:00:41.504
cmm42h2900005jxtu0ovw97h4	PAMUKKALE ÜNİVERSİTESİ REKTÖRLÜĞÜ	isci	PAMUKKALE ÜNİVERSİTESİ REKTÖRLÜĞÜ İMZALANAN TİS- 2025-2026		https://kamulog.net/media/tis/PAMUKKALE_ÜNİVERSİTESİ_REKTÖRLÜĞÜ_İMZALANAN_TİS-_01.01.2025-31.12.2026-_İMZA_T._28.08.2025.pdf	PAMUKKALE_ÜNİVERSİTESİ_TİS.pdf	15839443	t	2026-02-26 23:00:41.509	2026-02-26 23:00:41.509
cmm42h2940006jxtuyvpe0eiv	Sağlık Bakanlığı	isci	ÖZ Sağlık-İş - TUHİS | 2025-2026		https://kamulog.net/media/tis/Sağlık_bakanlığı_2025-2026_TİS.pdf	Sağlık_bakanlığı_2025-2026_TİS.pdf	4962107	t	2026-02-26 23:00:41.512	2026-02-26 23:00:41.512
cmm42h2970007jxtu4ucoeiof	Süleyman Demirel Üniversitesi	isci	SÜLEYMAN DEMİREL ÜNİVERSİTESİ- 01.02.2025-31.12.2026-		https://kamulog.net/media/tis/SÜLEYMAN_DEMİREL_ÜNİVERSİTESİ-_01.02.2025-31.12.2026-_TİS_TÜHİS-_İMZA_T.-18.08.2025_.pdf	SDÜ_TİS.pdf	11464438	t	2026-02-26 23:00:41.515	2026-02-26 23:00:41.515
cmm42h29b0008jxtuhf4dap0k	Tarım ve Orman Bakanlığı	isci	21. Dönem Ücret Skalaları		https://kamulog.net/media/tis/21._Dönem_Ücret_Skalaları.pdf	21._Dönem_Ücret_Skalaları.pdf	402056	t	2026-02-26 23:00:41.519	2026-02-26 23:00:41.519
cmm42h29g0009jxtum0f9l1na	İzmir Demokrasi Üniversitesi	isci	2025-2026		https://kamulog.net/media/tis/İZMİR_DEMOKRASİ_ÜNİVERSİTESİ_2025.pdf	İZMİR_DEMOKRASİ_ÜNİVERSİTESİ_2025.pdf	5142130	t	2026-02-26 23:00:41.524	2026-02-26 23:00:41.524
\.


--
-- Data for Name: TISFile; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."TISFile" (id, role, title, description, "fileUrl", "fileName", "fileSize", "isActive", "createdAt", "updatedAt") FROM stdin;
cmm42h29l000ajxtuu56my937	isci	21. Dönem Ücret Skalaları		https://kamulog.net/media/tis/files/21._Dönem_Ücret_Skalaları.pdf	21._Dönem_Ücret_Skalaları.pdf	402056	t	2026-02-26 23:00:41.53	2026-02-26 23:00:41.53
cmm42h29q000bjxtumhox31r6	isci	Sağlık Bakanlığı | Dayanışma Aidati Dilekçesi Örneği		https://kamulog.net/media/tis/files/SAĞLIK_BAKANLIĞI_DAYANIŞMA_2025.pdf	SAĞLIK_BAKANLIĞI_DAYANIŞMA_2025.pdf	49570	t	2026-02-26 23:00:41.535	2026-02-26 23:00:41.535
cmm42h29v000cjxtu2vsik9sv	isci	2025 KAMU ÇERÇEVE PROTOKOLÜ	Kamu Çerçeve Anlaşması Protokolü	https://kamulog.net/media/tis/files/2025_Kamu_Çerçeve_Protokolü_işçi.pdf	2025_Kamu_Çerçeve_Protokolü_işçi.pdf	0	t	2026-02-26 23:00:41.539	2026-02-26 23:00:41.539
cmm42h29y000djxtuuuhg067x	isci	696 Kanun Hükmünde Kararname		https://kamulog.net/media/tis/files/696_KHK.pdf	696_KHK.pdf	0	t	2026-02-26 23:00:41.542	2026-02-26 23:00:41.542
cmm42h2a1000ejxtu3mwo3rq5	isci	7420 Sayılı Gelir Vergisi Kanunu		https://kamulog.net/media/tis/files/7420.pdf	7420.pdf	0	t	2026-02-26 23:00:41.545	2026-02-26 23:00:41.545
cmm42h2a4000fjxtumb6wopll	isci	5188 ÖZEL GÜVENLİK HİZMETLERİNE DAİR KANUN		https://kamulog.net/media/tis/files/5188.pdf	5188.pdf	0	t	2026-02-26 23:00:41.548	2026-02-26 23:00:41.548
cmm42h2a7000gjxtukk40smcq	isci	İŞ KOLLARI YÖNETMELİĞİ		https://kamulog.net/media/tis/files/Is_Kollari_Yonetmeligi.pdf	Is_Kollari_Yonetmeligi.pdf	0	t	2026-02-26 23:00:41.552	2026-02-26 23:00:41.552
cmm42h2ac000hjxtugxvrg996	memur	8. Dönem Toplu İş Sözleşmesi		https://kamulog.net/media/tis/files/2026-2027_8._Dönem_Toplu_İş_Sözleşmesi_Taslağı.pdf	8._Dönem_Toplu_İş_Sözleşmesi.pdf	0	t	2026-02-26 23:00:41.556	2026-02-26 23:00:41.556
cmm42h2ai000ijxtuczqj1pwl	memur	7420 Sayılı Gelir Vergisi Kanunu		https://kamulog.net/media/tis/files/7420_KeOl0oy.pdf	7420_memur.pdf	0	t	2026-02-26 23:00:41.563	2026-02-26 23:00:41.563
cmm42h2ao000jjxtu0h4ums9a	memur	5188 ÖZEL GÜVENLİK HİZMETLERİNE DAİR KANUN		https://kamulog.net/media/tis/files/5188_yjsAnRo.pdf	5188_memur.pdf	0	t	2026-02-26 23:00:41.569	2026-02-26 23:00:41.569
cmm42h2as000kjxtuox9k57eq	memur	İŞ KOLLARI YÖNETMELİĞİ		https://kamulog.net/media/tis/files/Is_Kollari_Yonetmeligi_dKenvy1.pdf	Is_Kollari_Yonetmeligi_memur.pdf	0	t	2026-02-26 23:00:41.573	2026-02-26 23:00:41.573
cmm42h2av000ljxtui3cio8z2	sozlesmeli	8. Dönem Toplu İş Sözleşmesi		https://kamulog.net/media/tis/files/2026-2027_8._Dönem_Toplu_İş_Sözleşmesi_Taslağı_DCRXOC0.pdf	8._Dönem_TİS_sozlesmeli.pdf	0	t	2026-02-26 23:00:41.576	2026-02-26 23:00:41.576
cmm42h2az000mjxtufjlf3i28	sozlesmeli	İŞ KOLLARI YÖNETMELİĞİ		https://kamulog.net/media/tis/files/Is_Kollari_Yonetmeligi_nvsc2Od.pdf	Is_Kollari_Yonetmeligi_sozlesmeli.pdf	0	t	2026-02-26 23:00:41.579	2026-02-26 23:00:41.579
cmm42h2b3000njxtuxpa75h9p	sozlesmeli	7420 Sayılı Gelir Vergisi Kanunu		https://kamulog.net/media/tis/files/7420_0ALvPq1.pdf	7420_sozlesmeli.pdf	0	t	2026-02-26 23:00:41.584	2026-02-26 23:00:41.584
cmm42h2b8000ojxtukhbx4266	sozlesmeli	5188 ÖZEL GÜVENLİK HİZMETLERİNE DAİR KANUN		https://kamulog.net/media/tis/files/5188_wd108qM.pdf	5188_sozlesmeli.pdf	0	t	2026-02-26 23:00:41.588	2026-02-26 23:00:41.588
\.


--
-- Data for Name: UsageRecord; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."UsageRecord" (id, "userId", type, count, month, "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."User" (id, email, phone, password, name, "firstName", "lastName", "avatarUrl", role, "isVerified", "isActive", "subscriptionTier", "employmentType", "ministryCode", title, credits, "isPremium", "premiumUntil", "aiTokens", "becayisListingLimit", "listingQuotaOneTime", "createdAt", "updatedAt", address, city, "cvApplicationsUsed", "cvChatTokens", district, "emailChangeCode", "newEmail", "phoneNumber", "taxNumber", "taxOffice", "verificationCode", "verificationExpires", "emailVerified", "accountDeleted", "accountDeletedAt", "accountFrozen", "institutionName", "kvkkAccepted", "lastEmailChangeDate", "lastLoginMethod", "lastPhoneChangeDate", "phoneVerified", "postalCode", "userAgreementAccepted", "tcKimlik", "yearsWorking", "atamaYontemi", "hizmetSinifi", "istihdamTuru", unvan, "isAriyor") FROM stdin;
cmm2skks10000jxlzdbf6bh7y	admin@kamulog.net	\N	pbkdf2_sha256$260000$VUPSwgoBfvK+MHiyhKwaXQ$S4sB9SsklMqv0SD62Q39oz2GchkIgHBa+Vv17P5RyUU=	Admin Kamulog	Admin	Kamulog	\N	ADMIN	t	t	basic	\N	\N	\N	30	f	\N	0	\N	0	2026-02-26 01:35:43.153	2026-03-01 15:17:05.178	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tkx0alywg8qgnh99xp6pmnve	serigvedi3453@gmail.com	905000000303	pbkdf2_sha256$720000$OOZB5zQJWTRfyKAeAUyzGO$pOrHmHJJAqyeHHe0w74m6w3Fusn8PUnnAw4UZU5vkkU=	Kamil Biber	Kamil	Biber	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-11 22:36:09.524	2026-03-01 15:17:05.174	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zlrn04waubmxz1xjuxwqapyt	aysunyazar08@gmail.com	905000000404	pbkdf2_sha256$720000$nr1tfmBMsczgw5QJ12QCEh$kjmpWbaqLmb89JxRtSPj8xeS0KuGAbSKoEB/pzW5XYc=	\N	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-11 22:57:15.359	2026-03-01 15:17:05.188	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bwmlvhukwduh075vh7x4ospg	ozancosar198937@gmail.com	905312163489	pbkdf2_sha256$720000$HafjNp44Bo6gv6KDE1FkWv$3wxcq2HU3qnqBRjalUUep/J19dbt8APVgFx0pKVIfw0=	OZAN COŞAR	OZAN	COŞAR	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 09:59:33.216	2026-03-01 15:17:05.703	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
draqtn87u7swu2tlso41xv9x	murad_kilicc@hotmail.com	905346573650	pbkdf2_sha256$720000$Oth1yLExoccr52Imc4A0Gc$LYaAupOGwsT8/ioeIRwHRfkNTNgjRcHgwC7cwyGj0uk=	murad kılıc	murad	kılıc	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:10:18.167	2026-03-01 15:17:06.663	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qp6sucqc6tut3c6qfixbvbpc	reennehary@gmail.com	905425871989	pbkdf2_sha256$720000$oEol27H0rW7GcYggq1Lndy$H1Ma6wkdo1C+JQk0oPelUWdcgCNR/7AveGWTYDEUlsI=	Eren Cicik	Eren	Cicik	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:52:12.439	2026-03-01 15:17:07.137	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sdzp0btpb2tjp8phok90g8y9	pasha_3436@hotmail.com	905302436287	pbkdf2_sha256$720000$pggXhlPnRXfmEjqNWdIl10$JRuHUhtIBQgUOyMXOxOgnGAwLV2ESR03QA7Gqz9jWqs=	Eren Eminoğlu	Eren	Eminoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:58:28.584	2026-03-01 15:17:07.141	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mozd8kopl7hyu445pcnazqyh	murathasimogluu@gmail.com	905462293430	pbkdf2_sha256$720000$q3QD81GIkLNqKwJVNIpjPh$mQ+irp9jOBp+80mla7/Az1JtohHnsaY97Ffy2wK73Ts=	Murat Haşimoğlu	Murat	Haşimoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:34:22.812	2026-03-01 15:17:07.47	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
m2y87saprum8xz7l7yd08i0o	corumlu_1907@windowslive.com	905073543419	pbkdf2_sha256$720000$TJT3oOx4mJHoRdTyVUTk4f$MLcXVszHR7FMr4R+R41YHV5Kv58w7sq0r75kNbkfD4Q=	İsmail Demir	İsmail	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:27:32.133	2026-03-01 15:17:07.559	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kicmn9wivk519cdw4uicz2e1	yunuscobanoglu4@gmail.com	905343486092	pbkdf2_sha256$720000$T2EhvDoJNFOLiCgI0X70X3$RYCQsAc2K6N2CKUTxC0iuqopDv09fbOaPkKaGKIkv6A=	Yunus Çobanoğlu	Yunus	Çobanoğlu	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:43:38.978	10	\N	0	2025-12-29 09:52:51.675	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhox000ejxycyuoxmheb	omer.aksoy@kariyer.com	905555556677	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Ömer Aksoy	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.737	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmmfgrxkr0001jxqvcgjhrpmj	sahinsedat778@gmail.com	905392647655	$2b$10$Q2uWUnb5/RFjmj1RlGhZjOGZ9M7q4xl/Qz.xhBIbyc7ANWiBwS3ri	Sedat Şahin	Sedat	Şahin	/uploads/profiles/cmmfgrxkr0001jxqvcgjhrpmj_1772836069343.jpg	USER	f	t	basic	isci	\N	GÜVENLİK	155	f	\N	0	\N	0	2026-03-06 22:26:31.227	2026-03-07 09:17:45.308	Atatürk mahallesi Çelikel sokak no 5 daire 2	İstanbul	0	20	Sancaktepe	\N	\N	905392647655	\N	\N	\N	\N	2026-03-06 22:29:29.883	f	\N	f	Sağlık Bakanlığı	t	\N	whatsapp	\N	t	34785	t	63469395926	11	KPSS Merkezi Atama	Kamu İşçisi	\N	VHKİ	f
x89czmf88b3af8kwtanpjl9s	brgnbykt@gmail.com	905525840060	pbkdf2_sha256$720000$gWeoFErKfGl0lFmKt13I3v$/dGxc38IxNzkJns/TQhzC7X+feV7ncuyMAPe73FLaXA=	Emre Baykut	Emre	Baykut	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 05:44:11.098	2026-03-01 15:17:05.195	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xelyfgwxqhs5pn8u1ihmbuui	sseherimm@gmail.com	905467837917	pbkdf2_sha256$720000$Fx0iFxWeH37EF8N2zIfAVA$YU/h/OkWTBBZLQd4dCj8oGWOKs747hK8M+ki1Nt+sw8=	Rubar Tokay	Rubar	Tokay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	10	\N	0	2025-12-29 18:46:39.978	2026-03-01 15:17:07.993	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dd7rik1v0jbef0q6hh908jmv	gokhanevrendilek843@gmail.com	905530998970	pbkdf2_sha256$720000$IouGgPf56PdbFrGVIF7BZh$3s7gg4gA+WTjR+Z22Pf+Og+Ta1yoR2omG2SwkQKxAcY=	Gökhan Evrendilek	Gökhan	Evrendilek	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-07 22:03:40.331	2026-03-01 15:17:08.537	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
yqkvfsozq0bbzsma1sg18sb5	gursoydlk@gmail.com	905051070609	pbkdf2_sha256$720000$BweHiTOrq5kDAvVv7sK2VD$2NixvvrS9NhYxXF6XqSjA6rAA4VKfrLAcbERQw1LGmg=	Dilek Yakışan	Dilek	Yakışan	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 11:43:07.427	10	\N	0	2025-12-30 11:20:14.616	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tf5k7bhxehshuzal8csvx0qu	trzbvce@gmail.com	905530108347	pbkdf2_sha256$720000$XXWktPRvC13Fp9PpRxtT94$UGBbbzzxmQ0iZ7CIVvxs3BydCdYG30jaGC0jvy7C6Zw=	Ahmet Özdemir	Ahmet	Özdemir	\N	USER	t	t	premium	memur	\N	\N	30	t	2026-01-30 09:31:33.507	10	\N	0	2025-12-31 09:26:27.783	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
s9mqsu1vglc7twk9081z7mn8	esra_kesim@msn.com	900532234556	pbkdf2_sha256$720000$Eu926uXtoZfSmjkYXhiz03$5uasB//5zvQOAZc/1oilGUo+IE92cRQGsKSUDBomMCE=	ESRA ABİŞ	ESRA	ABİŞ	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:43:07.99	10	\N	0	2025-12-29 23:33:38.504	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
omatip5wfgmo4essoas6ue0e	murat_ezel24@hotmail.com	905370302818	pbkdf2_sha256$720000$L9W2WUGCEIuBTE8cdCI8tj$0+AL7wn+oD5JoreqybE2pBArh2dRS8DLNJWJylS8iTA=	Murat Erensayın	Murat	Erensayın	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:46:11.745	10	\N	0	2025-12-29 19:42:09.435	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pvksimzab1yg9zzvdv83dy9h	hacibayramturan@hotmail.com	905435869727	pbkdf2_sha256$720000$xeg2bXc6oEECTw6P17FiiO$aN7IAOhfprFqSu6QWXTq1tGo47QkypGgFxqE1aXr0rA=	Hacı bayram Turan	Hacı bayram	Turan	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:45:04.098	10	\N	0	2025-12-29 20:12:48.214	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
plv7vx3ypdu8ihsswg5c7h3s	selimozturk3046@gmail.com	905422464254	pbkdf2_sha256$720000$WY2gUYGszD6PUV5EwfMMLE$vAtfiV0tGRc6ppNz90dy16dPQ0E9pQFhJ6swp51GTbs=	Mustafa Selim Öztürk	Mustafa Selim	Öztürk	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:44:52.723	10	\N	0	2025-12-29 20:31:59.061	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
k3fkmoppvmkrasxnh1jb75c4	blowshot1453@gmail.com	905376830517	pbkdf2_sha256$720000$u68UppmrxKyj8eBFPDyhkJ$7crOHclMpzalT3/XryMTgHoHZz+PX4QTgkPI28TxILQ=	Ömer Can YILMAZ	Ömer Can	YILMAZ	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:44:28.839	9	\N	0	2025-12-29 20:36:37.425	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmmg4lkqp0001jx8v3tcdrh4a	sdat.sahin@gmail.com	905016547534	$2b$10$uevTkhJs9iFKllOaByUt4eXKNjGyMrW4qenpeMRW7ZWn79lCo5a/e	Ömer Şahin	Ömer	Şahin	\N	USER	f	t	basic	isci	\N		19	f	\N	0	\N	0	2026-03-07 09:33:25.441	2026-03-07 10:12:16.586	Atatürk mahallesi Çelikel sokak no 5 daire	İstanbul	0	20	Sancaktepe	\N	\N	905016547534	\N	\N	\N	\N	2026-03-07 09:35:00.945	f	\N	f	Sağlık Bakanlığı	t	\N	whatsapp	\N	t	34959	t		\N	696 KHK	Kamu İşçisi	\N	Güvenlik Görevlisi	f
yepeiiitmvm2wxb1yhr2yi59	enigmatigue@hotmail.com	905067513818	pbkdf2_sha256$720000$0dslEK3BEgFXXdKfxd61ol$J5dmufG53C1Rgd7rjxWIL+z9svXBGeQcjrjz8l41fUY=	Zeynep ŞİMŞEK	Zeynep	ŞİMŞEK	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:44:16.628	10	\N	0	2025-12-29 20:38:36.568	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dxmm4041fz540aswnxwtzb27	erdemozgor@hotmail.com	905458615454	pbkdf2_sha256$720000$Of7BIou0XGKl3yfFkWNLNV$kSufVgU9fv6lwgp849+3ZOrwI5KMNqN+4Tq/7UaTSn0=	Erdem Özgör	Erdem	Özgör	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:43:27.545	10	\N	0	2025-12-29 21:52:54.754	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fc552dru7tnuc9vuhskr02yc	aderya8883@gmail.com	905437862050	pbkdf2_sha256$720000$y0JrZtmV2Ep6uGKzAezrk1$zDdgxn5Vh9gmHvJ/bVmvIvR2Wu+DZC9N0uOT0xwFX5E=	Abdurrahman Uyar	Abdurrahman	Uyar	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:42:34.657	10	\N	0	2025-12-30 06:11:30.328	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cszotjy1n5dnb9ch5i2dii38	srplyldrm@gmail.com	905424014454	pbkdf2_sha256$720000$kXULBcPvNGsGx7xWMhL5Hw$JwFONlpLgWLJtSq49BX6UbYXgkMtWHDnQsxnN3Yh8Ls=	Serpil Yıldırım	Serpil	Yıldırım	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:42:08.751	9	\N	0	2025-12-30 06:41:52.238	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jaat1kqn37his5xpvq7zk3xz	e.karakan2515@gmail.com	905051922515	pbkdf2_sha256$720000$Yr7jKVNl835plbwy8TvpJN$k9qiYzFv4Ewe2x/QWL5zVy+JoAglkQ/oi5LOoys0OoM=	Emrah Karakan	Emrah	Karakan	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:41:44.774	10	\N	0	2025-12-30 07:06:16.063	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
yyjmdf3tba840u7slizouds4	ibrahimhaciosmanoglu53@gmail.com	905324165431	pbkdf2_sha256$720000$0wga1sLAani0FnjRNaDpM7$7RJbHVEgxiTblNbBuOmGlkfl+AtvpVrrFKDHVHTvFto=	ibrahim hacıosmanoğlu	ibrahim	hacıosmanoğlu	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:41:27.076	10	\N	0	2025-12-30 07:11:01.874	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bqb8m3plv8jk7w6csxxeoodq	emrekara3402@gmail.com	905414602790	pbkdf2_sha256$720000$y6UVrOxTAzXZ8l8tEzRIeA$k2PkXm3HJvdbOPzh3eM2z2ax60zpQ5337bjw7GD9rIs=	Emre Kara	Emre	Kara	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:41:10.264	10	\N	0	2025-12-30 07:24:38.601	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xscejgqqoya1p9l1i7aqrshj	kadir8038@hotmail.com	905374039676	pbkdf2_sha256$720000$LqQGjSOGUFG6I2hHeINfep$EG9Qmyu95T7gaHAihsNhjpLz+gIicxsrsaFa0o0Y448=	Kadir Akbulut	Kadir	Akbulut	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 09:16:29.661	10	\N	0	2025-12-30 09:11:35.659	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zldm7fmbioda2gfezkoax2vs	repimvar@hotmail.com	905325876431	pbkdf2_sha256$720000$3bafaqdReateAdodZC7bwf$7h0VKnJQJwmPIdP1Yy1ElgCQDUozDM/9UHpmzqkb3eE=	Muhammer Demir	Muhammer	Demir	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 09:34:53.955	10	\N	0	2025-12-30 09:19:56.503	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hmnkbit9fugfkzqz5dl2ifqe	erdnc.mrtza@gmail.com	905458614699	pbkdf2_sha256$720000$7iPiGKp27shFqgLb1Xb8qp$etufW+ouvxvX1jKDWSy4VQ1Ai8ArSeIvN5U6/PQfDrg=	Erdinç Mürteza	Erdinç	Mürteza	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 12:14:51.297	10	\N	0	2025-12-30 11:58:23.679	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
adt3mc8nutv91skg5856wmmt	ysnkula.42@hotmail.com	905428100163	pbkdf2_sha256$720000$WIPFhOJXnfkLShTw7ZaHHI$aaL31WA5he1/GkGfJKMGV7DpB4F5cjBmd2lc1Hz2SJQ=	Yasin Kula	Yasin	Kula	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 12:51:47.145	10	\N	0	2025-12-30 12:26:24.924	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
orhfhlnrjmhavqyd1on4kusm	faca7070@gmail.com	905555545470	pbkdf2_sha256$720000$Ez8pPfqg2hBGVXyyrf3fpl$dDiI513TN0lEGPfBvmHPzKMAVbw3lNc4EqoCVNk32SI=	Fatih Işik	Fatih	Işik	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 06:39:57.607	2026-03-01 15:17:05.199	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hp9fcc2lfxviywklos6ga71y	serkanyilgunduz460@gmail.com	905388872732	pbkdf2_sha256$720000$VdqODyn7gUO5i0MAuXRs1N$mWDd1HrrAulk5OGqbTiCsX9O8HFNNXMBLkOYxJclRFg=	Serkan YILGÜNDÜZ	Serkan	YILGÜNDÜZ	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:53:30.044	2026-03-01 15:17:05.213	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lv5e8ktrhfo68whadixylu7s	reisoglumetin@gmail.com	905050863672	pbkdf2_sha256$720000$yNEgDgfIDc8twFMLxYrsP1$58Mkk02Q3bqU38H17DJ0DS+X7xOHJ4jYEcr/C9cDWeU=	Metin Bak	Metin	Bak	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:47:42.971	10	\N	0	2025-12-21 15:56:33.105	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
el3v2k0sloftq0ejaxmp0ytl	zhrkader1516@gmail.com	905518762770	pbkdf2_sha256$720000$VqX2vw9AkOxhq1WA7c9nfo$JezycPh2JdZWOjKrlu4Ym15exs5pbt4OQzxtazK67uY=	Kader Karaatay	Kader	Karaatay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 13:31:00.609	2026-03-01 15:17:05.644	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zddxjixdr2lyn4t1ioru5x6k	sorular1987@gmail.com	905435505854	pbkdf2_sha256$720000$92EeM66BIxmSFUTMa4gay9$vcS/blEdqzSR6jd9xLmC4t54QxwQrZaCLdODZ2kPBQA=	Soner Cengiz	Soner	Cengiz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 13:53:28.959	2026-03-01 15:17:05.647	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xlw0iert3dfl57owb34b6g5r	suleyman078@gmail.com	905323958678	pbkdf2_sha256$720000$TW5OofQHULqRs679oTqBrj$W8xZivJ+4VbQhbAHcXWGbKZ238QkWz7M2THg5W08JKQ=	Süleyman Yiğit	Süleyman	Yiğit	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 14:36:52.326	2026-03-01 15:17:05.65	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vc2mpkkl4xrorby3g08sc5ar	blt1212@hotmail.com	905416359425	pbkdf2_sha256$720000$1uhqBTqFnUm7FMxRjz6a5i$eXgXZ52Vhv4c8qcELlc4j07QOj1kSYNq3p2t4xsGJcc=	Umut Bulut	Umut	Bulut	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 14:59:07.024	2026-03-01 15:17:05.653	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ttqbq30a99310lvb8fulx9l6	sevdagunesi96@hotmail.com	905519620696	pbkdf2_sha256$720000$OFi42AqQtqPOHUMnwyboB8$r8wTiHN3XNv8UJKXXlpWUVjxKiQjUYcB2B8vdfagWlo=	Hanife Betül DEMİRBAŞ	Hanife Betül	DEMİRBAŞ	\N	USER	f	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-22 06:01:04.397	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
y2pylfdp14mo99mo6bhm64gs	tovbe2012-ms@hotmail.com	905412779339	pbkdf2_sha256$720000$kvPR03cfCacicgbzzyTXQk$RrNCY+47vASW5NyIBqzsrxtZZrFsxPxJP8CpvosHfIc=	Suna Semerci	Suna	Semerci	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 07:02:20.511	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
j9fa0wh7935gi7zjqv6kowdh	akaldik3434@hotmail.com	905302854312	pbkdf2_sha256$720000$PF3WUfuJtRuYCEWFXZJ6SN$UisHxe1Zqy82uX4q+TKN81BIbwIQmdQppxyQn6E/oUg=	AYŞEGÜL DEMİR	AYŞEGÜL	DEMİR	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 09:07:27.097	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zho6128doubjo52eb1uxwbdq	cizenbayan@hotmail.com	905357957971	pbkdf2_sha256$720000$ETAyzynWJXTzmfcrKi8rYB$5cD93lAMBcM6BRE50raa7nUHHwIhkZsW66uhdFLHnjA=	Nurgül şahin	Nurgül	şahin	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 11:22:47.691	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
apfxc3wl15jea5encymmtmj4	erkancansiz26@gmail.com	905355656629	pbkdf2_sha256$720000$KIV3jBuJzgpA476q2SMZ75$BM6jf4sdRhQliJrKi7oX/GihSJ16uxqG4ScpF5tMeg4=	Erkan Cansız	Erkan	Cansız	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-26 20:55:51.589	2026-03-01 15:17:05.697	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
io2q7bv009i9t5f1560210fv	lemektansik76@gmail.com	905355155157	pbkdf2_sha256$720000$d63yQrMzph6VIPTF7IXtvh$r6qD8CLKD7e0boWAqrmLxVQ8cmzcP4tOCFrjHBNwjpg=	Lemek Tansık	Lemek	Tansık	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-26 22:29:35.783	2026-03-01 15:17:05.701	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fclhlfldxbor7gwpl86q3cwi	halilldemirci19@gmail.com	905383724889	pbkdf2_sha256$720000$bQKsLSZN6qVb68C0vKLZGp$8IvlgZE1fw8RYJVX3xtky80h/cvN7ZnqEkzwD0NWshY=	Halil Demirci	Halil	Demirci	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 17:12:42.888	10	\N	0	2025-12-24 19:10:33.246	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
y5lq1gg5squexberru7yae96	dilekekinci90@gmail.com	905415920211	pbkdf2_sha256$720000$Kb99Yj3egKCzbtYXScVH2u$lWv0FC+oJyByv7cLwdmZdUXZCiQIjm/bKAGVZ1rxJJY=	Dilek Gürel	Dilek	Gürel	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:23:50.75	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jjp1del3l4ccsybdaro5l6vn	yvzmine02@gmail.com	900540022473	pbkdf2_sha256$720000$SY50Gds22kRh9v7q7sbEuG$h1nAcEcn3xfg25+se/n6ywoJMytZh8aiZiFoYYkHHzU=	Mine Yavuzoğlu	Mine	Yavuzoğlu	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:32:28.377	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
r9xtvird7094saaxfffu2l6v	kadirkilinc42@outlook.com	905434850458	pbkdf2_sha256$720000$aPvZyIrYdZYs04RinRzsw8$wIcB5jppbIXRoSd45ONei2djnJJogluZ1j/deno4Zj8=	Kadir Kılınç	Kadir	Kılınç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 10:01:11.745	2026-03-01 15:17:05.715	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
f34j24qftin2m56f52uvaw6r	ridvancidik@gmail.com	905453391948	pbkdf2_sha256$720000$prL15Yoxes88NKyT5sWdAG$uMG1U5lMo5ZilpACmofgfZy8t686MsKfPqSGVDkGS9A=	Rıdvan Çidik	Rıdvan	Çidik	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 10:16:43.113	2026-03-01 15:17:05.745	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hfr9vo7kuyhjhk3nfihx8g8r	serakbaba77@gmail.com	905464965225	pbkdf2_sha256$720000$2CyWQ0iPfLfyZxl7mgJrFk$uLh8xWRTdLS1ImkA6uLTvnQqtLz7dregPta56NuIhLM=	\N	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 10:32:14.653	2026-03-01 15:17:05.748	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
m777s3v9t6idxwivephiozj2	nzrunes@gmail.com	905388703425	pbkdf2_sha256$720000$WkFixtSL3dtxJAtyjqkOQz$uIQ1RBEttbtAwRV6KtPudooOc+Yo1IgZ+kVvpJPWNo8=	Nazir ÜnEş	Nazir	ÜnEş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 10:42:17.589	2026-03-01 15:17:05.755	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
r1rryqhr2xt8wgnqlgdez0iy	bhrkrc1985@gmail.com	905426319335	pbkdf2_sha256$720000$qLRLv1JvhxOznFBkxfdBnm$o/ADj88SmQEFnz0MXvqwkRVIs7n5aWN9Zbuk+h3xz+Y=	\N	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 11:47:51.495	2026-03-01 15:17:05.761	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
gyv8k82j1gzfslfmb1eerhjj	tacettinkurt@gmail.com	905323042500	pbkdf2_sha256$720000$6tI939A6WebiIzg5RH5tJL$Tx80SP5egO3AyeegVqcUsRfolnsJxV1FPSM66B/BeWA=	Tacettin Kurt	Tacettin	Kurt	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 12:04:58.676	2026-03-01 15:17:06.103	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
joykqe28q8d8nsn114c2uy9s	demetbudak.1987@gmail.com	905387957641	pbkdf2_sha256$720000$Lr5ouM17tXTmIMMMBD9Ck6$ZCO98apQbtwIdUKe/YjKObMA8iEoHD2NojiKSiu0ROU=	Demet Budak	Demet	Budak	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 13:03:06.634	2026-03-01 15:17:06.112	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ny8ks2amrusi1iuz3nwuhwlp	badboys0686@gmail.com	905308948653	pbkdf2_sha256$720000$zWKAM3Ncjm6FuOhrSeJOLw$SrPY1w5zocwLv5G1sptEm3SXeDYTeT4eLgrj5hTbdC8=	Ahmet Kılıç	Ahmet	Kılıç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 13:08:54.618	2026-03-01 15:17:06.12	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ykvvm66n8p3c0y8p7maabrdg	blntck3882@gmail.com	905349330574	pbkdf2_sha256$720000$leXOn1zvKPZAVbr3t8zf0z$PKfzDOl2EEGQNGsfcGVKUdT/H3ljih+q/HiKQDQco1s=	Bülent çelik	Bülent	çelik	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 16:59:45.604	2026-03-01 15:17:06.125	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kuiekpuaqxg5hb4shv2s9kqq	m.sesad@gmail.com	905428412054	pbkdf2_sha256$720000$x5r4Ep0nhK3I6tcp726U7K$mIpvADJwawHRcX0qihgJqEFCDt8vWRWJKMu3M9+tQ4U=	Mehmet Esat Çınar	Mehmet Esat	Çınar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 18:13:13.095	2026-03-01 15:17:06.133	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ckohu5wuuyc2iuxwvg58i7mu	ademirelli3008@gmail.com	905417366993	pbkdf2_sha256$720000$XQKFHhG2V0IVGGvmaDVPUL$338AyFIHLufKQuTyFCeKz3LFJYWPBrU3mNfBaYxmxbM=	Ali Demirelli	Ali	Demirelli	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 21:09:16.413	2026-03-01 15:17:06.142	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bv3xdar6oj8darsll6as5el4	mahmutince432@gmail.com	905301330694	pbkdf2_sha256$720000$q3lecYZ6LS4BUBjpQ0apjV$4igxlzErox64FVGieWu+pEIkKsu7EYn+A/4g/nZfpAw=	Seyyit İnce	Seyyit	İnce	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:29:36.706	2026-03-01 15:17:05.206	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
joiuwya3oudbpm7pa9l136w4	izzetpinari1@gmail.com	905537614741	pbkdf2_sha256$720000$VCwgX9vlsyqcleU8STtgaj$VK9IW2T8Fh3AXQeYL1Scd0zfxhDO5WS8naw5H3g4pJg=	Ahmet Turgut	Ahmet	Turgut	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-30 03:23:25.75	10	\N	0	2025-12-31 03:20:57.787	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mm2p9ugdr0toffrdzzje76xj	burukannn@gmail.com	905359833177	pbkdf2_sha256$720000$w73OuJ9EMYC5K7kMZ237g0$LAMM7srunzdp9jdQE5oSb6rDHUlHvnVUvFsKTV5Nezk=	Şükrü Belin	Şükrü	Belin	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-30 14:37:01.64	10	\N	0	2025-12-31 14:31:51.193	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
eg08f8o6091lec4knoz0h618	kadir44230@gmail.com	905389229126	pbkdf2_sha256$720000$SftHijzKmhZKQ1C2NNnu1J$lqnmoqFCQ5KuXbR1LKTtELvrJ1pVVoLPiZbgll8KcTI=	Kadir Akçay	Kadir	Akçay	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-31 18:25:49.616	10	\N	0	2026-01-01 18:24:40.362	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
octt7rwfh201ml5pfnvjlnti	yyyanar@gmail.com	905419480018	pbkdf2_sha256$720000$q1mezlCRjc7PXXLmYgRpOI$9lmu003sD5R6hZHMNK8qt+1jgJQmVUfsmjrwJTKXOrE=	Yasin Yanar	Yasin	Yanar	\N	USER	t	t	premium	isci	\N	\N	30	t	\N	0	\N	0	2025-12-13 18:28:49.203	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
gpizot51f5h2s8hkukalv8nn	gunlukislerim34@gmail.com	\N	pbkdf2_sha256$720000$TZAneZETQ8HPh9kvZRbhDK$VD4s/Aj7ewLyWsqGps8lMX9OS30poM2ZSPyTwPHE+Ao=	Ömer K.	Ömer	K.	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:49:04.431	10	\N	0	2025-12-29 06:50:59.918	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
rhwv8bc6beifqiv83wp1t4eq	alperenprogramci@gmail.com	905444031393	pbkdf2_sha256$720000$OrttYDvYuHBVhLglV7QSbx$9QvirLal9nF+MOi1y4Mp9t7ZWrXajK3+M8iNp4+WjoE=	Alperen Akbaş	Alperen	Akbaş	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-05-31 13:24:00	10	\N	0	2025-12-13 18:53:02.869	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xdi9bdp9u1k6oktobje7ekw1	thrguner@gmail.com	905384882162	pbkdf2_sha256$720000$pXpJV3XuuvyX7ZyplUUCsR$EhkibZlRc/hltbbIMhcrLcsCXJVdjYGECGscXlR0MY8=	Tahir Güner	Tahir	Güner	\N	USER	t	t	premium	isci	\N	\N	30	t	2027-02-28 14:14:00	10	\N	0	2025-12-15 19:55:38.584	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dx5qt4w2gqywugmmp50ihkqv	osmansawage@gmail.com	905400341834	pbkdf2_sha256$720000$L2WJLUT698SrqeUa9aN31a$uuiVb80Vyd4RIt0DWDY8di3xxm6GSR1fwNDNSNpyHXI=	Osman Andinç	Osman	Andinç	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:48:43.759	10	\N	0	2025-12-29 15:33:47.413	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bjznies7us0jxrtnomyc4m2c	cenkguler02@gmail.com	905435794155	pbkdf2_sha256$720000$v4nO7H3JuZ8iuUvVimaCBl$3yKQy6GwSarvUeGwW+y3IYJ4eN+IfAVxo+3Pr8sNInc=	Cenk Güler	Cenk	Güler	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-28 06:58:55.042	2026-03-01 15:17:06.153	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zfo23h7wogi15p9s9b4t76sx	hamamcilar@gmail.com	905375734441	pbkdf2_sha256$720000$qg6sNyUM8Sl2T3SuC2zx9e$GHDtL1PU7WAk+Z3TVvE4WfNTu2Xmcpmttuvshk43qWk=	Orhan Hamamcilar	Orhan	Hamamcilar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-28 17:49:30.153	2026-03-01 15:17:06.16	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
m11bhztwain7y6rucvl8nmxo	mehmetalikarabulut1907@gmail.com	905510291251	pbkdf2_sha256$720000$PquBbeylFRHIDVYVxIgKtI$npNDEGKg+54UP/5U62nchmpegeuhfY91AiuhtwBuev0=	Mehmet ali Karabulut	Mehmet ali	Karabulut	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:22:43.639	2026-03-01 15:17:06.164	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
oe6ui9g054yobi2jpf8v3uh9	demirelkenan901@gmail.com	905370279425	pbkdf2_sha256$720000$7Vpg4TAXJKxCiN5EPkHa7b$krAjdmAJra39g8BZoh4h+PVioJkbU//nucz6qGEjjZY=	Kenan Demirel	Kenan	Demirel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:27:06.118	2026-03-01 15:17:06.172	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
esqnxveu7jwni6611kq6u8ps	huriyeuzun5237@gmail.com	905010943752	pbkdf2_sha256$720000$jF7EzhKa2LhHe2HPtbcUvb$/uswhLUCEQVhpDeqzWKWDv6JwxcB1C9O5GU5KiUepKQ=	Huriye Uzun	Huriye	Uzun	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:32:29.148	2026-03-01 15:17:06.175	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
shtknjua9xh8z1kfiqyipi8u	gonul_fermani@hotmail.com	905434423330	pbkdf2_sha256$720000$tJilhxbFPcTmxEXJSgBn2Q$9JmH2iAklP1rW0JLw0gbuVN5LsQbL602ULZzFLWGs54=	Gökhan Demirci	Gökhan	Demirci	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:35:01.814	2026-03-01 15:17:06.182	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
h37ehihl3qdx122ss0oqlfoe	havvatrhn409@gmail.com	905521723367	pbkdf2_sha256$720000$rNKYpnW0xXj30zqywVoOmP$Hqg++ZMj35NG4Lk+zZ/uuV2EqnAAw0yxcmYHOad2GsI=	Havva Tarhan	Havva	Tarhan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:35:36.728	2026-03-01 15:17:06.186	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
u0ct39xg8q7ohbevas1n71lj	demirslh2911@gmail.com	905439426928	pbkdf2_sha256$720000$Tn0QHBO9zJbNfjs1yqQ8FO$A6njXt1jJiu/nsbNsUOaiL8oMEFQOOtA/RduTz/DwLg=	M.Salih Demir	M.Salih	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:36:51.046	2026-03-01 15:17:06.192	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qqsi7r83et4a7gq48cnrpe7r	bariz.aslan@gmail.com	905387720646	pbkdf2_sha256$720000$RZLFRcjWqKf7yrjLbZTX95$dqyjPD6MU4XoeyQsPFejnxkVEH+f08GPoLXOgYGaELc=	Barış Aslan	Barış	Aslan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:59:29.332	2026-03-01 15:17:06.65	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nprha0rq2crv37asv3o2n5ks	frtkaya722134@gmail.com	905524128772	pbkdf2_sha256$720000$3jsODRLrfpejnbk5rLNXOV$lkChNDkAgl1mYv5SvWp5Y/3y6jj4Wb6uum6B87COVrQ=	Ferhat Kaya	Ferhat	Kaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:08:02.03	2026-03-01 15:17:06.654	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dk9pq9f7k9pznv0uowbixock	hoyucu27@gmail.com	905421300577	pbkdf2_sha256$720000$fcdPzBK2mtCHi4VePpowqI$KEgiUS1YlDWv04Mvj/4R7JR3RSOjV32SZBhEpIxDRlU=	Mehmet Hayri Oyucu	Mehmet Hayri	Oyucu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:19:07.242	2026-03-01 15:17:06.666	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
psnlawclnpg1tu5qworljivx	Cagdasdogan808@gmail.com	905520265060	pbkdf2_sha256$720000$rOwJ1x2Bg85Kno3YzibVNH$4I9NOsggj/3hBBtCs+k5LP1vjjhEgyI8lWMoK24Du5g=	Çağdaş Doğan	Çağdaş	Doğan	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:29:46.816	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
rkf2un7cyobvjpabehuy0um6	sevgulcebeci53@gmail.com	905413341053	pbkdf2_sha256$720000$PXwbNgr2z3KQbfvVQkQ7XG$DowKb/YyAIthlG0LtqcKg1+k+Up9J37Er01uLVlSrcg=	Sevgül Cebecioğlu	Sevgül	Cebecioğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:22:36.935	2026-03-01 15:17:06.669	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nyk3pdr3juw78jnukxcbkvh7	dtavass@gmail.com	905321582342	pbkdf2_sha256$720000$sWpASmnXznQGLCg487izT0$eLmsnHgJmBTbXJI62XJFjc3v23Bb82TB+hocWOjkQTo=	Deniz Tavaş	Deniz	Tavaş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:24:54.058	2026-03-01 15:17:06.676	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sgwt7rxwfauef31tbb7w8dwh	ademsolar.as@gmail.com	905432481062	pbkdf2_sha256$720000$wxy3tYSzkNumPcRm5PEptu$UEMJDFfPL0I4cboH1mwo4x229oLpT6fpZMGOZ58ePmg=	Adem Solar	Adem	Solar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:25:01.635	2026-03-01 15:17:07.04	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sysniqfvced49esqi86wrfkq	tasdemir0613@hotmail.com	900552175677	pbkdf2_sha256$720000$vYv4N6SpASbK084huzedVG$yJEfZa9F/TLBGbPy+1dX/5OIJFB6C8a6vKBlHQnE6+Y=	Ömer Taşdemir	Ömer	Taşdemir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:26:33.39	2026-03-01 15:17:07.046	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
awyu453w2u2djihv1dliuyca	hspkdmr5897@gmail.com	905434122548	pbkdf2_sha256$720000$oRxw5Jie6k9BVZUt2YcOQb$mCO3b3XQdBp2Lt/FEZFRBzjH8Cz66ItyrWwFbsaCh4M=	Hasan sefa Pekdemir	Hasan sefa	Pekdemir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:32:35.181	2026-03-01 15:17:07.054	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
yoebfphc81bqfmxzl1dxk98y	yasin.ekemen651@gmail.com	905378672678	pbkdf2_sha256$720000$NVVH2IUN8pki4aq2w9PeVI$lgreoPw4o5RNcbHHHtNcS+6Nk8BAW2ho6CA/D3Jbve8=	Yasin Ekemen	Yasin	Ekemen	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 10:18:22.109	2026-03-01 15:17:07.087	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cusl9gxmo957wyvpz0uj6drr	vankalite65@gmail.com	905066575218	pbkdf2_sha256$720000$koiSihGWj4FGv4I5Fweaw7$b4yYXg0I1BSIwBn0K5CHqBXhUTiPajcUgbotEg9qcWQ=	Selda Yüksel	Selda	Yüksel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 10:21:14.882	2026-03-01 15:17:07.092	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q4mdi2hzq3fzt9ndjzwog19x	gulmezgokhan47@gmail.com	905366194749	pbkdf2_sha256$720000$6Rv7xZ9ljHG3MjiTwuYP8W$34dhzbV0ERA7THQsOCs4xCprDMZfTom5XbgGcOy+F8c=	Gökhan Gülmez	Gökhan	Gülmez	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:08:03.394	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
v8zox4vyw1cbiec7i4fpksml	esmasultanatali97@gmail.com	905010292731	pbkdf2_sha256$720000$LorcHSnbzba0tJaL5sHFfg$8iDvdZJnGD31ttGv8M6xPV0jRxm2GWdi5/4dbSg5B/M=	Esma Sultan Atalı	Esma Sultan	Atalı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:00:46.5	2026-03-01 15:17:07.146	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kh3cs5gv648929k4q9tvkd4t	assianwewo@gmail.com	905548722417	pbkdf2_sha256$720000$x8YLXDlrMwxCwAbA8a1zMG$7cWxtVQIx9LhKqK0dfYRnAnyF/4mt5+InA/BvvWF/3g=	EMRULLAH AYDIN	EMRULLAH	AYDIN	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:02:24.735	2026-03-01 15:17:07.149	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wtpkkpdql4dzqirrx345ygw0	gamzeceto34@gmail.com	905520033635	pbkdf2_sha256$720000$qhKtkRxs9qzgov1BNIz8fp$Di7CU6o7i8j7D2uxRuFviIFNsvdZ7JJpll3IqWex0UY=	GAMZE ÇETO	GAMZE	ÇETO	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:03:59.751	2026-03-01 15:17:07.425	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ohq3bw3wheiyt0bf1tahr8o0	enesturan3256@gmail.com	905389523225	pbkdf2_sha256$720000$Joxt64YaoLVAHLfaSkLEC5$FRvDrVeg5seGgF8uBQ3PutLBz346jWHwPTxLWqN847k=	Muhammed Enes Turan	Muhammed Enes	Turan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:16:12.359	2026-03-01 15:17:07.428	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
e225156k76boy7nt6ycpwi8k	omertepe89@gmail.com	905454362239	pbkdf2_sha256$720000$rGiFXv8qAkRLnJ1qbLFcym$wOJhG5y7BgSFC6nKaoX1u/uH3yBqcvYeNYrylZcj9ok=	Zeynel Kara	Zeynel	Kara	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:37:28.101	2026-03-01 15:17:07.43	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
a5227j1wd740s775fe1bql5a	Ragipciflikliciflikli@gmail.com	905426169531	pbkdf2_sha256$720000$wsGh37x6BMLS4cOYNSafG4$aeSyO3eoSAkd2/d6GcOyGgZcQtEhEYqmxEcjfzZsZK4=	Ragıp ÇİFLİKLİ	Ragıp	ÇİFLİKLİ	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:24:45.375	2026-03-01 15:17:07.433	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zv559uzhby0jpu4bzpm8j6wq	vatanseverahmet39@gmail.com	905366153284	pbkdf2_sha256$720000$J7ikFibxOVOYMFo1zs1Xo8$929slyJwhDcgcsWxU7LQRFzJeMG/U92xwtDzqfGc7HA=	Ahmet Vatansever	Ahmet	Vatansever	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:35:04.306	2026-03-01 15:17:07.435	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
eqmju8qgech9a57a0wkfxuc9	fundakarabicak@gmail.com	905057943230	pbkdf2_sha256$720000$fNYIkgh5sKoAE2z7TlRC2B$SyS0WoOR3yedKQd1ZFn6+frEp8GbKUnxg4Q2pdJjyQ8=	Funda Karabıçak	Funda	Karabıçak	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:35:09.8	2026-03-01 15:17:07.438	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vuyejrkee2oz8rke0225b2w3	firat__bulut@hotmail.com	905412327025	pbkdf2_sha256$720000$RITIGjaKKYAXLBHid3Syq0$kTDnRY0aTVElL6pQUigwrDeFOmNhNQdZq/BOC/nQUXc=	FIRAT Bulut	FIRAT	Bulut	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:39:26.419	2026-03-01 15:17:07.44	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
i7t4b12peomunu4f93kcp37a	eemretokgoz@gmail.com	905418202638	pbkdf2_sha256$720000$I3x1nXrXsry19B1AoKiUcQ$TdsklAuQyBneXDTFCgj29Nnsk5UIgEuaHalDQdqoKjw=	Emre Tokgöz	Emre	Tokgöz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:54:21.241	2026-03-01 15:17:07.442	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ruxmpphltq6kbgvkkxq7af6c	baharuluc51@gmail.com	905529274556	pbkdf2_sha256$720000$NUYOxXozUfCgXD30fFha1G$IfhwRL2nMQnnLimF+TFRbc4YSZ5PUpuzfXuJiW07ihY=	Bahar Zencir	Bahar	Zencir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:54:29.119	2026-03-01 15:17:07.445	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
y0tw81hrjfwi92ikt84sfkp3	husameddingulsen@gmail.com	905416986059	pbkdf2_sha256$720000$RMOQdRxd0xJVB08Ulvrp0W$1TeHov852pzrkFvpSs4g8klhG+XEQelLFr6r+HLm45s=	Hüsameddin Gülşen	Hüsameddin	Gülşen	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:54:30.237	2026-03-01 15:17:07.447	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
snvcf4lt11b7s15m48g3levo	neclazerda89@gmail.com	905075871922	pbkdf2_sha256$720000$N4IMLtAnwHMwDI6vG4p5Wq$4EcfCda+/3W+aNdXHa0zZqx+1xIlKqBy/3dddZ6ergI=	Necla Acar	Necla	Acar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 13:55:52.873	2026-03-01 15:17:07.449	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kne2zi202v5c3hiwbescgi9l	mehmettkamberoglu@gmail.com	905363710801	pbkdf2_sha256$720000$B7MMT38ETzIXXsHdKHdwL3$VjhzCbu6wQ6sGOvy1OOxtpsMpC7/x1pYf4krJaIAbbM=	Mehmet Kamberoğlu	Mehmet	Kamberoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:01:37.398	2026-03-01 15:17:07.451	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
efl70ofthkmrdw9w12wazneg	cagan200173@gmail.com	905548924915	pbkdf2_sha256$720000$2zOLnPPG3EUDvAWv0lowaA$SNF8RIjcYLnp7335E5w6kYllM6UePKMAap4lt5qLEQk=	Çağan Deniz Sağlam	Çağan Deniz	Sağlam	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:28:53.168	2026-03-01 15:17:07.454	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cnacbm2jc0mvw4mi91fakr8i	fatih-145@hotmail.com	905366753309	pbkdf2_sha256$720000$o8M8bKTvOwon7m7CTUOXuk$tDm9ULPPFCvK1HlL3wprGtcGPV4lYivLprxpIU/UWrs=	Fatih Akgün	Fatih	Akgün	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:41:27.038	2026-03-01 15:17:07.46	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fjhqfmegyutvr0ajofw072zl	rayel307@gmail.com	905413764550	pbkdf2_sha256$720000$IIEdpDCZk1YwiT33YKr6K8$5bTSkToB0x0bJfoKUeuPO8NMRzYw7DJWCAoGtlVzjHo=	Fatih Barış	Fatih	Barış	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-19 18:10:15.674	2026-03-01 15:17:07.463	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tgic7q5quns8gy8lr4qzcem5	erdi190360@gmail.com	905426386260	pbkdf2_sha256$720000$NTqSHgBHIYYbgH0a1DuwQn$TORTHjWTHa5WJyn6OpnUstPX7gth7n7ADgKKLBva6DE=	Erdi Çelik	Erdi	Çelik	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:48:11.613	10	\N	0	2025-12-29 15:33:55.767	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bro4k0zyj54ap5jgy20vhun4	ali_cam_gs@hotmail.com	905383635901	pbkdf2_sha256$720000$WvIw3CnPpCpkkr9mwHYUFI$adxPN2vNvb92bJ3+bDkn82SRSSA5vjoCsJSqXi7lJI0=	Ali Çam	Ali	Çam	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:29:48.828	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
re2vpp2u1dh162udp2ae9ljv	demiremirhan95@gmail.com	905524239316	pbkdf2_sha256$720000$9mPyn4bNke7dEOA66V3hdA$m69xxc38tEDhRgQVBN2J1D1okdTZNK4Wf5FBI4TkW/0=	Emirhan Demir	Emirhan	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:35:12.212	2026-03-01 15:17:07.472	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
c6clbfqyvaq0zhds8yqaqc66	krmdmrl1467@gmail.com	905397223467	pbkdf2_sha256$720000$EwOYdMrerf59WyKM3TMSZC$dcj3KBNL4g969yi8zc6vG9Ue8kTqcgXi7umb/H1RInw=	Kerim Demirel	Kerim	Demirel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:36:13.867	2026-03-01 15:17:07.474	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mqo2m5byjqo7fvb8bciurcj9	husnu.fetihan.vural@hotmail.com	905515955104	pbkdf2_sha256$720000$trAT8GcljSFF7NRRFMiJIi$beQcG1SFzlfeGbPYfeQc6xHgZABxZEPv5RCO4TxG2zo=	Hüsnü fetihan Vural	Hüsnü fetihan	Vural	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:37:07.804	2026-03-01 15:17:07.477	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fi7bih1jfys1a5oo4kupu110	bltsbrgmlcmkocaoglu@gmail.com	905537553429	pbkdf2_sha256$720000$Dsq0dz1rdMYDGUxVhuZtpA$53XUnJlc6tbDfFbyBHqJBr2GL+op0b8gcvv6r9GMSqw=	Sabri Kocaoğlu	Sabri	Kocaoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:39:17.927	2026-03-01 15:17:07.483	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ngo65973bag5ewdsg09k5e9n	nowenjoytheday@hotmail.com	905495235601	pbkdf2_sha256$720000$7WqR802y2nwKUIU11z6X6M$aImY3Al1f0l3XEGiI3rEvSW/gcniVCurGtriEMHUmw0=	Mustafa Kılınçoğlu	Mustafa	Kılınçoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:42:21.774	2026-03-01 15:17:07.488	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ja60fhg1i9ljt3cli4dq2au5	elifnisa19@hotmail.com	905393959763	pbkdf2_sha256$720000$jUcrOstjfb4KquIiyUNnLi$vBzGj92QbKrSL/iRUMJIo5bL2Ti7GtmGzZuSvRNQ6C4=	Gökhan Doğan	Gökhan	Doğan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:43:30.958	2026-03-01 15:17:07.498	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
d7mlyvjpxiiiuiyi3bxhdstu	culluyunus@gmail.com	905331492332	pbkdf2_sha256$720000$QsL7bQ3KAwx8DcTqJQ5hZF$pf5AxdGDpjNuxftyiJ4bnl3i24r183gQW030PZLdZz4=	Yunus Çüllü	Yunus	Çüllü	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:44:11.95	2026-03-01 15:17:07.501	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
c17glprxl1rd6iosg1goq4qa	bilalclkrn@gmail.com	905464493424	pbkdf2_sha256$720000$Dy587CZ0yoMId7ZGt3dDXA$sNiHiYO9lq/G5/J72m3BbGaTvJCj3qQ2Rf2zgYnWH4k=	Bilal Çelikkıran	Bilal	Çelikkıran	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:46:07.126	2026-03-01 15:17:07.505	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
yw3fl6o8ze00b5hf8erywh22	ozanecer@outlook.com.tr	905550389465	pbkdf2_sha256$720000$eHakvXk4UtO8o4cBh1tCHx$VtBT3s4y7jtjBuuR119+2e+ud9FT25Y5ivKabHlpEGA=	Ozan Ecer	Ozan	Ecer	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:46:14.642	2026-03-01 15:17:07.508	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tnbdtbc6bw4ekp1a2t9tzxrq	senatk05@gmail.com	905330375878	pbkdf2_sha256$720000$2xBuc5p63QYQbtT0kEN6fB$0yFyQjy4BhaV1YIslDm84clYXVE8ij8n06aHnVY3o5E=	Sena Atik	Sena	Atik	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:47:16.707	2026-03-01 15:17:07.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ny2p36f143hyvea0aqcsiaal	bilgeozacun0@gmail.com	905301017335	pbkdf2_sha256$720000$iTOh4CClamFUzwqnc7NKQ6$JJDdq3zlINrJgrGD6dAuuDNuu5scTLgzOHC/kgIFua4=	Bilge Gürcü	Bilge	Gürcü	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:49:50.397	2026-03-01 15:17:07.514	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
b4sidd2j2xeo8321u1dx7rtx	cakinfersan@gmail.com	905056706426	pbkdf2_sha256$720000$R088X2dKIDrQgCeESwtdSP$kW8SsR/S/A1EC5z70BcwP8F8pUGi8nW8jxS+Y8e+ZSs=	Fersan Çakın	Fersan	Çakın	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:50:06.316	2026-03-01 15:17:07.517	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
e68ztiex6o82ewf87mexqyxt	mt.muratcelik@gmail.com	905321675160	pbkdf2_sha256$720000$ZhihBfja6cWbVmLTLlCNGo$KZv4D+6p+rjEnd2bX16LEB3UPX2RMD5Lz5B4ipe+itU=	Murat Çelik	Murat	Çelik	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:52:55.791	2026-03-01 15:17:07.52	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pho8kny2i8ptoa2zba1hiyq4	emreozmentes84@gmail.com	905439107717	pbkdf2_sha256$720000$YG5y2RmDw1pFe7CYguE4Hy$jFkePKq1rZHkf7KGLX1FlUMC5tl1Xqo3cyLV1KgJ1uY=	Emre Özmenteş	Emre	Özmenteş	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:58:53.411	2026-03-01 15:17:07.522	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
w205g6osqr4jk3g8okg9blfj	kubraclbii21@gmail.com	905315427448	pbkdf2_sha256$720000$b79pVYqCJfPVQsm5l8IrN3$KLa3Twk76mIFWOfxT7ogqNSPiKgf5DmXqwxc/IBgovo=	Kübra Çönge	Kübra	Çönge	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:00:17.979	2026-03-01 15:17:07.525	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
eibzbecto6ev5xwnf3g4fbeg	utavligenc@hotmail.com	905468401608	pbkdf2_sha256$720000$OOL7jObkpDZYCZ8n4PlRlS$I9oAK5ZmKH8rArDEVfARuwXzpNCYbPjrofz4GIv9O5A=	Yaşar Çinar	Yaşar	Çinar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:01:16.277	2026-03-01 15:17:07.527	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tllfx31fv3pkq6pat7awitle	mustafaatar013@gmail.com	905455114300	pbkdf2_sha256$720000$upJ99OVA7uUKQabICIKbkE$8krWLOxU4iZMPKoXYETWcztr+3X0DaJ7QtoKyPhk5nE=	Mustafa Atar	Mustafa	Atar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:04:24.78	2026-03-01 15:17:07.53	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
b9urpd7tb59t1urxx8ndupp1	cetiner.cevriye@gmail.com	905424967965	pbkdf2_sha256$720000$fOUtkm31GVhnyaqFUTzFFo$6+Bktf0C9GkZ9woZ5l+CtG3T5PVYBhHSD8B+NkDHH6Y=	Cevriye Çetiner	Cevriye	Çetiner	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:04:28.549	2026-03-01 15:17:07.533	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
evuraynehmogugl3kg6kgm78	ramazanbodur289@gmail.com	905414203405	pbkdf2_sha256$720000$4jukBnXcJc1O1Ee9vwflZT$WSw+tb6gBY7w5qLR5voQQ6mlGX/z4632mk0rTwjM2jo=	Ramazan Bodur	Ramazan	Bodur	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:08:35.603	2026-03-01 15:17:07.539	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
z7fn6vjzo3u4pjhsyh2yqdrf	kupcukhamza76@gmail.com	905057962852	pbkdf2_sha256$720000$UE3HH4HrtO9VNZaVsnTfwj$smRWXJ2BKMLSSqNekSkGvNtSOtQ5mOWwd/wukhx0OQQ=	hamza küpcük	hamza	küpcük	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:48:24.817	10	\N	0	2025-12-29 15:38:52.889	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
w5hpzcp5rmm9q87bh8n0z7c7	koksalgundogdu789@gmail.com	905439239207	pbkdf2_sha256$720000$TmiZOOp9Xz71R2fjCFkvro$dNSsCVlWSb+uCUgIM796CDSI/S7N1dhR0p8pm/Cz3WU=	Köksal Gündoğdu	Köksal	Gündoğdu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:16:44.091	2026-03-01 15:17:07.548	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zkigitutoniopzcf5838684g	osgb34@gmail.com	905394232222	pbkdf2_sha256$720000$CYGgwAJrAyrwk6wkHxNYpY$HpcndlwOXtqqAfVMIl/26+WBVP/Jtdy3k7UrwQwkWg8=	Ali AKYÜZ	Ali	AKYÜZ	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-30 05:19:29.588	2026-03-01 15:17:07.551	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
goeblha4uw5e5qwcm4ek8mia	kadir.kayikci34@gmail.com	905331350557	pbkdf2_sha256$720000$l4rJKWRiEjGUVMNqoiPOVM$fkBilL/0bqUBj0UZVWB1Hu+FOTYa8lo/SvtKX1yylO8=	Kadir Kayıkçı	Kadir	Kayıkçı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:22:34.952	2026-03-01 15:17:07.553	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jysh3c3expcyb43i005htm42	aykutcivelek1988@gmail.com	905442170638	pbkdf2_sha256$720000$Mm22dRUrOJ6k7YMytaEh7x$/I+1Jge793sSnfIv8B4jgx5sF1IPy/uH1L9dAr3bADk=	Aykut Civelek	Aykut	Civelek	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:45:03.457	2026-03-01 15:17:07.59	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
r4lxo8ynt7tzkbiynxucvyy4	yildiztuncer02@gmail.com	905375646248	pbkdf2_sha256$720000$4HAqdHWmigvtVbtji2IEEK$9/SoKW8hgMtyKq89p/Dwv/hgdZLL7tbfsUgkvrAhjiw=	Rabia Yıldız	Rabia	Yıldız	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:57:23.707	2026-03-01 15:17:07.598	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ysh3fn77i11rdle8p06cwbpe	tuanamtaham@gmail.com	905443191984	pbkdf2_sha256$720000$svFeWIb9NRbEzUElLqWmiu$t0EdyfU8mB4mIjWuHur9lQwXpEwAOP/K0E+e9/KCV/E=	Murat Ç.	Murat	Ç.	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-26 11:31:05.094	10	\N	0	2025-12-21 15:45:14.54	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dewfpmnvzq3djw3yinwy7ywk	onurbayraklii@gmail.com	905012042491	pbkdf2_sha256$720000$I1g7xl2d7mtXInDmZyhBUw$8fftxZnjs8Gacqzh6YDQTOLzWUaviq+6E0kGV5vZymY=	ONUR BAYRAKLI	ONUR	BAYRAKLI	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:48:02.452	10	\N	0	2025-12-29 15:43:24.559	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fb0x3fjrqswozhheonm3vjlg	yasinsezer3450@gmail.com	905384127182	pbkdf2_sha256$720000$UXRJUKQoc9EJBBdrgcwmeq$Z43GYSiXN29Tg7Aq0kTdx4sc838UOfBC15U80mChNiw=	Yasin Güler	Yasin	Güler	\N	USER	t	t	premium	isci	\N	\N	30	t	2025-12-31 21:22:00	10	\N	0	2025-12-29 16:06:03.634	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
d49dg8q4p5fku9hbpa6w8333	mylmz1903@hotmail.com	905446343434	pbkdf2_sha256$720000$7Eo6SYGRCxK6fDbCks5fmS$X0XNeLUtT6+Fpxts+H3QmYe2kTy98F+29Yo1LJzoGic=	Mehmet Yılmaz	Mehmet	Yılmaz	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:47:01.638	10	\N	0	2025-12-29 16:36:43.916	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ta9ia7djvx03b9ffo8qaqi55	kral_4774@hotmail.com	905445705695	pbkdf2_sha256$720000$TaIz0Qu7nbfFHnMr7bbfJE$nqgnzIUVaxGSCuuGPZPriJ8cglDCIhKgN6jdYIEWW1g=	Vedat Çoşkun	Vedat	Çoşkun	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:46:36.756	10	\N	0	2025-12-29 17:42:05.007	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
u6v935g4fs6bo236ouw699gm	gudekersin@gmail.com	905313996342	pbkdf2_sha256$720000$p73TJ30TmWIYqd03wLKcfv$mcD2EYCn42Kbwnu6FiLcxUAbvv3ZLN2Pc+ILktq3194=	Ersin Güdek	Ersin	Güdek	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:46:49.708	10	\N	0	2025-12-29 17:42:32.77	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vcd4z1uve4jp2mrpajug9n0q	cuneyt.canturk227662@gmail.com	905367407510	pbkdf2_sha256$720000$LvEZM6VsJLeTeh3l3n39sp$b2WtEGx6+Euv+FPpoZfFKEFxSXM9+ndeEeygBEXW89o=	Cüneyt Cantürk	Cüneyt	Cantürk	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 17:43:00.591	10	\N	0	2025-12-30 14:35:45.303	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
z9zlca5oaszxljsqskvpqbzw	grknblc91@gmail.com	905363796295	pbkdf2_sha256$720000$wQHkgI6whr3iaxdprWd49x$D6rDwCozKtvevDUpXEtIWbomoA2EzWrVOv7qDzMKAEY=	GÜRKAN BİLİCİ	GÜRKAN	BİLİCİ	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 16:57:37.975	10	\N	0	2025-12-30 16:53:38.43	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hqvtuj4jtb1u9yfhlk33p5t4	mustafa_ugur_91@hotmail.com	905442412519	pbkdf2_sha256$720000$TEZoHVNn3jYnQ54Ur36a9V$knWByWp2SOFCBoQivIGdUPpXRHHgyoDUnonfDf5oyUk=	Uğur Yanar	Uğur	Yanar	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 16:59:05.046	10	\N	0	2025-12-30 16:54:36.184	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xonoind28e9fyik7ysq6mdsf	islam_ovecek@hotmail.com	905320122052	pbkdf2_sha256$720000$edt8u7H90h59SpFXN5HAsy$cU0rv8Xon0AP+s69LJqukiy6RFYisN0Va4h9geB8mGM=	İslam Övecek	İslam	Övecek	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 17:35:18.676	10	\N	0	2025-12-30 17:31:21.653	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fxmrerfr6njgnvgev8coea6f	meteates.ma@gmail.com	905336779828	pbkdf2_sha256$720000$V4U0FX2twh5v0ZFWIoU8p1$7g/UBGHlxDaJfoJcfmx76Ykc275ol0CysYEt/KuwWpY=	Mete ATEŞ	Mete	ATEŞ	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:05:57.789	2026-03-01 15:17:05.223	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ypbme2fjgtpsn9shjagjln42	cihantumen@gmail.com	905419501426	pbkdf2_sha256$720000$wPIS0ByZqXawRuYpNoXuKq$hW+ySZlv7cnnvlu8q81HsAH4rIWBQs+nqE86JS1/UuI=	Cihan Tümen	Cihan	Tümen	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 11:29:23.459	2026-03-01 15:17:05.759	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vlcefvxpzqk56pdml60o2l5d	yasarozgul02@hotmail.com	905322941604	pbkdf2_sha256$720000$I7AL9x6mVAHM83t9CqeVW0$gOUNCF5TDB/DeypLdruwt8zWm1CVs+RlFVonZCwtyDg=	Yaşar Özgül	Yaşar	Özgül	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:04:41.126	2026-03-01 15:17:05.226	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q9etn4o0dyuu6qzopkrhzdxh	halil403@windowslive.com	905377349767	pbkdf2_sha256$720000$tsIW7GHgeUzhd08AJPYSDO$adKyle4xyTMo1Z0a0MR00rR9kjiN4/4cMgO+QPynzq0=	Halil İbrahim Atalay	Halil İbrahim	Atalay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:35:49.677	2026-03-01 15:17:07.057	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bthp7dfgsl1b7cpvjp0j5oxp	alpanesra@gmail.com	905393199183	pbkdf2_sha256$720000$4ZiioAXqwBy320uNnHf5Pg$jdMN0IFWMuU4WKDdhvPBW0xDywQh5R8HRe15GSdyWac=	ESRA ALPAN KIRLI	ESRA	ALPAN KIRLI	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:36:19.107	2026-03-01 15:17:07.061	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wnixbqtrd6nooj72m2k0aebf	opensea02@hotmail.com	905543000506	pbkdf2_sha256$720000$2M1AnbBmbKimGRrQlafWRV$4wX1m6naGKEBjFf654XtmRfbaJpybKDzYnkYj2qK3MA=	Deniz Menteşoğlu	Deniz	Menteşoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:40:33.839	2026-03-01 15:17:07.068	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vpirhunn6fpsw5ucrojw8jzp	vkose027@gmail.com	905318501501	pbkdf2_sha256$720000$NPLDIm3WgKuWBjvNcFLs4M$v+CJHwsFNEEWX2mg0bjOkqplrkHZqy242qKMlQGpCoc=	Volkan Köse	Volkan	Köse	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 10:07:26.155	2026-03-01 15:17:07.081	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
eepedmkgxy2ge8n8ucornyeq	ery.pkr13@gmail.com	905061599115	pbkdf2_sha256$720000$Qk9LbEbyqvbNm9MTbfgh6R$8zhV3nUzSAhArgdIaob5x69qntzi0aYdjxu6aGASun0=	Eray Peker	Eray	Peker	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:32:04.777	2026-03-01 15:17:07.611	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cn64qi2k1mc8twwklbccepx4	orhanduman308@gmail.com	905466199430	pbkdf2_sha256$720000$RRwnQ6ZQK34ZO3cpgznIlQ$4GNO/dZjbUJGp4mnqBIamKlwighe/p+ufpQqUvtNs78=	Orhan Duman	Orhan	Duman	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:21:34.389	2026-03-01 15:17:05.228	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
yxw4nnp8umdqutyr6v3nmocx	ondercagrici@gmail.com	905412427358	pbkdf2_sha256$720000$DVT6kvD9MirnMoEU56IsGf$LafYOtgEskUqxAM0gUyjQxhX0ogz6okRVq/obKqoKCM=	\N	\N	\N	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:43:48.986	10	\N	0	2025-12-29 21:32:22.334	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jaje0v6eg4j0kwa549xpywpc	muhammetacet267@gmail.com	905078624819	pbkdf2_sha256$720000$KijX5K099ngKAWOkNIKHJS$e1td/mIvz3lfmK3gOQj+aVAUnZSk/bZ3v/BmAbT2axo=	Muhammet Acet	Muhammet	Acet	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 10:31:40.162	2026-03-01 15:17:07.099	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
e9evbkaoxdr7yeili3up1pc0	Umrankaratas06@gmail.com	905307249247	pbkdf2_sha256$720000$WdxwRLwgITQAtorm3WaAf8$ns2Waae2HcxV74V5YGBMVyR0cBLImtQu8Kj6OJfeRv0=	Umran Karataş	Umran	Karataş	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-29 10:35:21.107	2026-03-01 15:17:07.106	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lytat6hv7h0c6x9v7j8bevg5	ky52efe@gmail.com	905350501252	pbkdf2_sha256$720000$7kAg8QQm0AXN6nCoDfGs8i$tycacm1PoJG6tFMBmKwUEutA5T4sMvEPa8uOCFKF8LA=	Efecan Kaya	Efecan	Kaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 10:54:03.893	2026-03-01 15:17:07.109	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dscpq4ms6df5d40iko7nezr2	eiifezgi.kaynar@icloud.com	905421303714	pbkdf2_sha256$720000$rUBxTVzPQRlR27Tgcza6bm$wyboijuD57rY8I3cZmIfiuIYw8VHkAHFdTRkkdwFj8w=	Ezgi cengiz	Ezgi	cengiz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 11:04:59.772	2026-03-01 15:17:07.112	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
b7kp8ybo7kakz49nmy6tx19b	ridvanayri@hotmail.com	905401130223	pbkdf2_sha256$720000$yJTDcSvsxXDIGJd0yQ7AuJ$NC8zai1LKBVt1EiJDxdlzAHiSPMV0S2Cp7gaQBlYj5Y=	Rıdvan ayrı	Rıdvan	ayrı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:05:57.033	2026-03-01 15:17:07.115	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ea0m1f78de2aa630roknosts	zeyneptuana166@gmail.com	905065191890	pbkdf2_sha256$720000$d9pW0Z4p5R9lItqHOJhnoF$KH8/GrJF2y47DowRX1vfZcBi5sEidELBviI/VP49bcg=	Zeynep Özer	Zeynep	Özer	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:10:19.831	2026-03-01 15:17:07.117	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
rx06tpx4mlawkmfmla9b7omn	muzafferozturk156@gmail.com	900546718820	pbkdf2_sha256$720000$mqyVer5sD1FZ8yvG5AXkrF$SXeVWGY0+ARXmirUIjsQRWbhBx6bH1IK7bNmzO7Yigg=	Muzaffer Öztürk	Muzaffer	Öztürk	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:28:39.451	2026-03-01 15:17:07.12	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q5es1l8plw88hf7tzxyq7eej	murathaktan16@gmail.com	905448718158	pbkdf2_sha256$720000$bjApYactJcuLvOP5d3STj9$ocFHV4TZg9+ATHZEXHhqRGSuFjzx+R6xMYxgr12Yi/E=	Murat Haktan	Murat	Haktan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:30:07.705	2026-03-01 15:17:07.125	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wjjhizxazzlxcawrxvm6mhah	ertugrul_2580@hotmail.com	905459593859	pbkdf2_sha256$720000$DW7RS8W0oVAxNZh4ttkQkQ$3ayWsKVGcsFeypBa0Fi99r7/unD+Ds7AiQIVEJT4j+A=	Hasan B	Hasan	B	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:32:55.953	2026-03-01 15:17:07.128	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
gl73hr3r85uezqfbq6pag1pc	osman-duymac@hotmail.com	905498130392	pbkdf2_sha256$720000$LSoRA6hx0Li9PyY8kEk2Zo$FhheLnJAcJoSOm77N0RZ/SJgCoo47RHsqobrJJ4EOIo=	Osman Duymaç	Osman	Duymaç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:36:48.426	2026-03-01 15:17:07.13	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
s4zatijhxkg8lp6lfw2k9wyo	habibkorkmaz@hotmail.com	905332327626	pbkdf2_sha256$720000$KhygixEbH2Gij5iZncxcyx$k+IzTUmay60xipmnvhMwIpVWju9XXBq0rIyIJhqxCQ0=	Habib Korkmaz	Habib	Korkmaz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:44:57.242	2026-03-01 15:17:07.132	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lan7uddvq2va0xklfnnqf23j	karcibilal46@gmail.com	905413451724	pbkdf2_sha256$720000$SheX0NA9dOkVqd8qmRiYmF$+nSpPqI1pyX7ktWYhRhnr4BCqPImtd0Agv5Pb4AcSMw=	Bilal Karcıoğlu	Bilal	Karcıoğlu	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:20:19.316	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhoi000bjxyc44djqaa4	hatice.polat@kariyer.com	905552223344	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Hatice Polat	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.723	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qmffogpazf3ffotaaqgiap31	unziledgn01@gmail.com	905539036268	pbkdf2_sha256$720000$ZTDC14c7mhLlMwOYoBHeYk$xLHP9839bTAAteX7B8AXiHG8SmIwzqGX+DhkwAYu4K0=	ÜNZİLE DOĞAN	ÜNZİLE	DOĞAN	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:22:36.497	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qovgihqz9ldn9lp0u59uf1kh	nejlasahin346088@hotmail.com	905332772176	pbkdf2_sha256$720000$pDPamS0YxRrH8uYe7eXNx0$YDa3ga+ObwjHJh6KoXjOP2UFJiT/OSALG45nbF8x+pE=	Nejla Şahin	Nejla	Şahin	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:31:34.364	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hg6p32lp1tfsm83c2nwqiiz3	canerburgucu@icloud.com	905415451068	pbkdf2_sha256$720000$x4Zrh3wwZAe47pPeNIvnwk$1uzekhWx+tvFzX2EFIDXNd7aOGo4aicfurwlzZs7u8I=	Caner Burğucu	Caner	Burğucu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:59:42.103	2026-03-01 15:17:07.144	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mm6cvn8k37vbd3j8vx0difoe	yenikoy1987muhammet@gmail.com	905443842751	pbkdf2_sha256$720000$bHj3pXMPwPAlsnKLwMmcPa$UUOAPBtJ4z8h0KspHQkotsQgNmR0GFbhNfb1KpFW5KQ=	Muhammet Yıldız	Muhammet	Yıldız	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:12:57.06	2026-03-01 15:17:05.239	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tz6hwmij4h77uzzjrgl4j6tk	mustafakopruduz7@gmail.com	905418674235	pbkdf2_sha256$720000$dXoOkojTL4xAyGAsSmlzwy$RSEVSSUo7mSFEGf8jy7LwcPjbokiETs6/fW3vuN1/Ws=	Mustafa Köprüdüz	Mustafa	Köprüdüz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:28:19.229	2026-03-01 15:17:05.264	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
rqmgvmz7c9sxu5dt5vqgwvik	hasancaglar5647@hotmail.com	905317013031	pbkdf2_sha256$720000$pQ4lwYTMvJRFUrjT99d6XP$dXjq7OadxcsG8hOfGM57e0qpK+gthbZ6Ch2c9mhy3c4=	Hasan Çağlar	Hasan	Çağlar	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:29:33.904	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
paz057a8xd3yfljbt0xgprvp	furkan_15@outlook.com	905425898009	pbkdf2_sha256$720000$lgJ3k9jTmqYkwoighH9xaF$SkuBMIx6h32Ig2/HPbZgQM4bJNyM/xVqBv3QMUCQ5n4=	Furkan Çalışkan	Furkan	Çalışkan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:46:43.817	2026-03-01 15:17:05.266	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ixuc8f2s93vy8im2la1a0fpf	huseyinkanat431@gmail.com	905062842535	pbkdf2_sha256$720000$gQOaRw3XpzzjZFzhZmw40W$WN21aIYevN/wVr4ednDtGINFhfdBkqhoxLNq43r6e6c=	Hüseyin Kanat	Hüseyin	Kanat	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:05:35.107	2026-03-01 15:17:05.268	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhp2000fjxyc76w8v7yq	rabia.korkmaz@kariyer.com	905556667788	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Rabia Korkmaz	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.742	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhon000cjxyc0hrvvnfn	huseyin.erdogan@kariyer.com	905553334455	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Hüseyin Erdoğan	\N	\N	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.728	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhp8000gjxyc9rx6wlt6	burak.tan@kariyer.com	905557778899	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Burak Tan	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.748	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ifg8i3ew4va58aly1x2bomai	dlkglc@gmail.com	905414821873	pbkdf2_sha256$720000$4yKOiJAC8ZBgoOEaVpSKJd$TAlnfifNkbXX1SgiR2HEvsENqBQwC6B3HsBgt8h/8aM=	\N	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:29:14.026	2026-03-01 15:17:05.274	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhpd000hjxycaqwgiwka	seda.kurt@kariyer.com	905558889900	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Seda Kurt	\N	\N	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.753	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ah2lf9g9g31z5el71wcwnz03	brspkdmr.2855@gmail.com	905412556628	pbkdf2_sha256$720000$YzayGX4s2haX8CaCknBIP2$5m3HAkbeb6FKr2kPZueunZfw5V5zjo+Vy3kVyS2skZ4=	Barış Pekdemir	Barış	Pekdemir	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:45:32.612	10	\N	0	2025-12-29 20:19:36.835	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cxh3jpoxpup62s17g1jcwpn1	ensar_eymen2013@hotmail.com	905452656263	pbkdf2_sha256$720000$TYvgs1N4h8JG3TwrRKr8YV$jlbHzKgRGeYr8s1Seaa6DdRoXtTmrGZ9WjsXwEl02Es=	Esra Çörpan	Esra	Çörpan	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:45:21.256	10	\N	0	2025-12-21 15:27:41.632	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qd16ia03jnnmd6vulc8g6l5b	tasbaran281@gmail.com	905389294972	pbkdf2_sha256$720000$sB253ARjUOKDX91hzKUcGv$JKMwp4ygopF7T2RYR4c6lRFyKjhtpiJkMFgqfhfoWzc=	Baran Taş	Baran	Taş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:23:11.844	2026-03-01 15:17:07.556	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
k07r80dyoiqzluh1zs7f686i	murattciftci34@hotmail.com	905467375153	pbkdf2_sha256$720000$Ixf6jYz6UJnL1rfkSXBkhY$XtXMZ88U/OUrmk1E/Xvr0AHMmkKDjKZMi4VafiDrO9c=	Murat Çiftçi	Murat	Çiftçi	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:35:27.276	2026-03-01 15:17:07.565	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
i9yhul6xj7qaqrik59zm5hdf	sercan.cakicii67@gmail.com	905428092577	pbkdf2_sha256$720000$MxXOVpRL6E3cKOoiWiZ7wE$hrFxNzcLYn+QddVCeuazYCTOaCUCm7+KT7q0QzTH2WA=	Sercan Çakıcı	Sercan	Çakıcı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:41:34.08	2026-03-01 15:17:07.582	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
f3nz0w69krflr1jazw4z1z95	hazansinben@gmail.com	905531112475	pbkdf2_sha256$720000$BFMXqikOrgnmOTy7xLs83l$4sPHsfvuuE4K94pFSqDmMlUTueLMfL3ekkQHmPnY5v8=	Ilkay Demir	Ilkay	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:44:17.213	2026-03-01 15:17:07.586	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
g36x68s8xay0lahq690h938t	mevlut.baki2161@gmail.com	905325141718	pbkdf2_sha256$720000$t7zCj6RbnQyGldv2TdcODV$k8hwJM1QEGICRn1LXDrpqiE0qZuzk2u80jfvd3+9GA0=	Mevlut Baki	Mevlut	Baki	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-15 08:45:37.602	2026-03-01 15:17:05.277	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
j0l3ew6pj0mdwrtspn1rbbam	hasan_204_@hotmail.com	905312492290	pbkdf2_sha256$720000$zwJ051kX94tQVT6getYQKn$4NbIvBiNmepaZCL0xaLuyMcqDukdnRM4se8VuxC2dyc=	Hasan Yanmaz	Hasan	Yanmaz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-15 18:27:55.005	2026-03-01 15:17:05.279	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
s9g0snoedqkz4b1blc5n4g23	gokayglts60@gmail.com	905527438549	pbkdf2_sha256$720000$lGVyitSMbKVqGK4LUX120r$+fyuQpJbPk2FJBwDO7EazfXukzs1qjbCqCpBsTjGDY0=	Gokhan Gultas	Gokhan	Gultas	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:08:18.447	2026-03-01 15:17:05.282	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xpevxvxs3qq6sd5bynzq26vn	ozangursoy42@gmail.com	905336164297	pbkdf2_sha256$720000$i9yFdz4S8SjGsYsX8wyEn1$6SUyAmVDkGP4D+yAM917NTXkFYiHXuVwU2/al9YsJuI=	Hasan Ozan Gürsoy	Hasan Ozan	Gürsoy	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:13:06.78	2026-03-01 15:17:05.284	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q80enhqu0guqa3ubkzcx6tw4	ulasdemirci45@gmail.com	905466351819	pbkdf2_sha256$720000$p9WaysICTtUOjYYReDBPFf$tg39OEAGU6b3fQa6nD2Hi6XAj1B2a0yhtcSKNu6oF1E=	Ulaş Demirci	Ulaş	Demirci	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:14:49.956	2026-03-01 15:17:05.287	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wqzkq4ar6n7qtbxilpspalns	mustafa.erenay47@hotmail.com	905419543447	pbkdf2_sha256$720000$XmwwyjcDpW7RspGeHPxySl$X3H2lj1VOE3gML94HZVB+IVouAHWap6mJPpp7mqmu6k=	Mustafa Erenay	Mustafa	Erenay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 20:21:11.793	2026-03-01 15:17:05.608	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tr5j07xal8zln7od5q0clk9g	muratoren766@gmail.com	905523918730	pbkdf2_sha256$720000$FXK7bP8FS1FWlu0yMszsjo$84jTz4WC5MbyPSh75dJFDjkAR9R9btlRNpJmtNYBTTs=	murat Ören	murat	Ören	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:19:28.623	2026-03-01 15:17:07.602	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhor000djxyc7yl6vzvc	emine.ozdemir@kariyer.com	905554445566	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Emine Özdemir	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.732	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
f9e2b5gz8ssvs8bt8sv5sjyk	cilgin_balik_ugur3@hotmail.com	905344721934	pbkdf2_sha256$720000$QO0W7LNZy0lrhF1IwQzZaG$dVcK5hyP/5gG4N8rOPJXZ9cnFoa6SSpWm/dnpkAKfeE=	Deniz DELİBORAN	Deniz	DELİBORAN	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:21:16.515	2026-03-01 15:17:07.605	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ek5i53t9hk2rt7mfpx5wkxok	furkan.ataman92@gmail.com	905074146554	pbkdf2_sha256$720000$NygJwocaY52F9YYYbVaddX$ly8jMQARF19Ds46rY6TeJ930VaIGx+Tmm5dMMRkgPvQ=	Tansu Ataman	Tansu	Ataman	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:28:08.999	2026-03-01 15:17:07.608	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sf12xelew90b0ugkycasqfbg	zeynepakdogan250@gmail.com	900531523786	pbkdf2_sha256$720000$GiiadJhvhNKKYSb7eduEvn$3bb/0746vsPV1P88jMmdvKVb375Kng3v1hd42OVpSQ0=	Zeynep Akdoğan	Zeynep	Akdoğan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:43:54.399	2026-03-01 15:17:07.944	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
iebes06taav9jeinl0nzrhxu	legend190355@gmail.com	905350274638	pbkdf2_sha256$720000$i1ZkpcN0sBnPPIGBgCruEm$ksrZMHHKuNxGN7VPkHlDtkAEZfG4hJo57rU4TugTnYc=	Yunus Algün	Yunus	Algün	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:50:46.052	2026-03-01 15:17:07.985	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bp72lhv90fzc6vkmw2qup05e	minikosk5441@gmail.com	905411911541	pbkdf2_sha256$720000$Xwy8L7liQ9daKaNSj4XqpG$SuMs2C83/Okjj9YC890s2dSQp7n/xlBIpWVls8wVkaw=	İlker Karakoç	İlker	Karakoç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:44:59.773	2026-03-01 15:17:07.989	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
v1vggx0suaze67uo598jpeud	sarialanli5905@gmail.com	905057845905	pbkdf2_sha256$720000$w1g4c94oAEATByRTsUnfoF$ijujYq4KH+6vI3YMklQjK2+6IKlErD1d4aWhepvwLbk=	Engin Gün	Engin	Gün	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:47:17.42	10	\N	0	2025-12-29 16:33:39.674	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nt86jx7ieberz0w1gkqtdp8h	dilekkgozel@gmail.com	905520034999	pbkdf2_sha256$720000$uunbP27xatVfDIodoClK38$H2iirFtdJ/xSnGKF4y97DHT9EAO7nnYtovrsWh1iZA0=	Dilek Yatak	Dilek	Yatak	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 19:50:05.448	2026-03-01 15:17:08.034	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ujz466tt0w0oft8jy8694eip	humeyra.sadikoglu@gmail.com	905078324042	pbkdf2_sha256$720000$Wavdl7DsDzMExEQZWobPmr$7stUYoZXgOQV+SurLVPb/+oh6X2wbZab3Ssoq51nePM=	HÜMEYRA SADIKOĞLU ŞENER	HÜMEYRA	SADIKOĞLU ŞENER	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 19:53:19.806	2026-03-01 15:17:08.038	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
j0ylgda6zr281rnri46l6dnt	umutbezek7@gmail.com	905334518269	pbkdf2_sha256$720000$eqw8b2sH9G4N4QJrlhIfWW$8qnoHmsJIl+YSJjBA+NptD1Bo35T7ol9T1a2XrwMd14=	Umut Bezek	Umut	Bezek	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:03:39.064	2026-03-01 15:17:08.041	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mlw475xhtwmf68irffj3sgh7	fatmahiranur415888@gmail.com	905305435072	pbkdf2_sha256$720000$i42uMUvwAY18ruLUYSYCao$VCwZqdmSLtqx9XD9lapHXj8lM++ttT8jxe3E6GD93cs=	Harun Kılınçlar	Harun	Kılınçlar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 05:30:04.575	2026-03-01 15:17:05.612	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fcm6lbjw9zrs75xrnjplcbd5	alperenturk6464@gmail.com	905309670873	pbkdf2_sha256$720000$KgRjC4opZdzjUKmPdzVpR3$xKFOy1mWw8sUBTp2YEGi2xpe8tix0uj1VW7VGZJgYu4=	Mehmet Alperen TÜRK	Mehmet Alperen	TÜRK	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:43:55.913	2026-03-01 15:17:05.615	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
e3envtn3cyqwbi2cbsxtc1lx	ihakkiyilmaz87@gmail.com	905552596536	pbkdf2_sha256$720000$05bOXxZuzRkfARse078iS1$W9+oUZOKKSfzN4GaFXCqh9PteEhTbobiT52LW7DAF+c=	İsmail Hakkı Yılmaz	İsmail Hakkı	Yılmaz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 05:55:32.547	2026-03-01 15:17:05.62	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bkddiwz7mwb1h1d1ke7gu91c	sozdemir1334@gmail.com	905349238233	pbkdf2_sha256$720000$ozaznGqPYMCQOvJiWKfh0q$yogbT2Orx/gANDXgOWhDqtKkUMmwyhmKteOIIp5mNvw=	Sevda Özdemir	Sevda	Özdemir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 07:34:12.49	2026-03-01 15:17:05.627	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
da6q7zxcz6q7s080a55ejcz6	hediye.egeli@icloud.com	905540055708	pbkdf2_sha256$720000$0IcG6S5zeEnlHXgmr5t5zB$Ew8M89f/TyYWBen5dwDXmjVd6GAKXywj6SxYqDhIU5E=	Tuğçe Egeli gök	Tuğçe	Egeli gök	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 08:18:47.596	2026-03-01 15:17:05.63	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ublsci2jytywzypu4r839iay	ahmet3455aslan@gmail.com	905418695534	pbkdf2_sha256$720000$jbX3XYqNR5Wr4sYQ6rGojX$4wvpg1cOh6HE+3/5EvlpjaUwRZs5Mh4u8c8yl2fuRF0=	AHMET ASLAN	AHMET	ASLAN	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 10:07:42.698	2026-03-01 15:17:05.636	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kh64rzpzwhme5u26aldh6poc	hakanyumuk56@outlook.com	905455285500	pbkdf2_sha256$720000$KdArrMVG37bxLDvDAH3AKl$id3w89bCOkpzaf73AmCzdBDQSAMho3tMvesL+za6NCo=	HÜSEYİN HAKAN YUMUK	HÜSEYİN HAKAN	YUMUK	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 12:11:47.205	2026-03-01 15:17:05.639	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pm9ziphicb8k90u3nf2sqx1l	yucelmesut71@gmail.com	905534589950	pbkdf2_sha256$720000$jdG4CLU6dDyOrq3vN0Aswv$VbjYuO4C7bH7TapDS16kskxFAVNY2Eg7oRKrbHuHuqg=	Mesut Yücel	Mesut	Yücel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 13:17:05.378	2026-03-01 15:17:05.641	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
edvkckpohi5yqmggsunbrasa	aagbulutyunus@gmail.com	905309307402	pbkdf2_sha256$720000$BeV0TxOnyivrwUFfbQSAKb$oZKN4THkZ+wnHSj1wgd+ayurgQuC75KZesdyaMOkg0Y=	Yunus Ağbulut	Yunus	Ağbulut	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-06 19:07:28.899	2026-03-01 15:17:08.531	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
gdxirrxnrl35eum8qdz5xesw	esuphi48@gmail.com	905352530253	pbkdf2_sha256$720000$pwxqdXi5tyclX2pRSoIPcq$QHHd0X7TOTHbAY397vFUwIn7RAHgBhXl/HKigBasCeI=	Süphi Ercan	Süphi	Ercan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-07 07:33:54.688	2026-03-01 15:17:08.533	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
aku5do3ksadvwsktlakv4qsh	cotyora1982@gmail.com	905071002774	pbkdf2_sha256$720000$gYvtMK2yrdNUBrWde8F30Z$ShGpnis7aTKv0to934yaVPjKkXMk8XSSFX/IntHPkCk=	Mehmet Kılıç	Mehmet	Kılıç	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:25:45.467	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sqm44ntuucj85m6cnxlgbckl	mudur.031985@gmail.com	905447396265	pbkdf2_sha256$720000$i1uNC2DKTDJqD88F8otLur$NEFSbqkiwPPN/+GsVFxfQIVefu2JnK0K6XOAcqBdeWs=	figen pırnal	figen	pırnal	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 16:23:06.297	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ovb471833u59fgorp72m9hgo	gurkan3405@gmail.com	905496000505	pbkdf2_sha256$720000$K1sPZEbWla7bikP4eGT5dg$UVUookwf4x5dHw5rvP450QvoXyMBtIrcU2U4zS7vKbg=	Gürkan YALÇIN	Gürkan	YALÇIN	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 17:52:07.454	2026-03-01 15:17:05.657	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qg6qvfui6iurhofx58cr83hr	s.donerkaya@hotmail.com	905326179020	pbkdf2_sha256$720000$z0HbpHn0eJMFasiWXqw1y1$3IpLiz53UYLOD40dBX0B++xaXmxsh45PiUufxrm/Bco=	Selçuk Dönerkaya	Selçuk	Dönerkaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 05:48:57.851	2026-03-01 15:17:05.66	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
gacevjrb3labbvx26hk13333	metinfethiye@gmail.com	905321631049	pbkdf2_sha256$720000$XElNIZa8SWkaT1M285uGtE$fgFWyPl40AG0LgTiMnxrOYiDPd4Ux1rNNxq+k6WM2YI=	metin ekici	metin	ekici	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 06:50:57.602	2026-03-01 15:17:05.663	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wzcvc4b4grnhfvmrtqitph6x	a.fisne58@gmail.com	905372582570	pbkdf2_sha256$720000$NO4DjcYcFmOF152oEK56Jl$9G99XLN4/g6ceGvkhRmfQJ+drWezpVCKsxqsAh2SVic=	Abdurrahman FİŞNE	Abdurrahman	FİŞNE	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 07:11:21.908	2026-03-01 15:17:05.668	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
k23dmn1xq9j0okisgkbn7r4b	boncuknebahat5060@gmail.com	905444710926	pbkdf2_sha256$720000$t1PNgEsCGH6qDHcHsxViYt$sHsai++/3Ic0XKnliflFrI0MoAAHiEAz+4eDIdxvUrc=	Nebahat boncuk	Nebahat	boncuk	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 11:59:39.116	2026-03-01 15:17:05.671	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
frvzzzbedi20k6ce7fql6378	fatih_karakaya_millet@hotmail.com	905312101408	pbkdf2_sha256$720000$T40SOICIxxsndeYPMMpqEp$BKzquI5AZj1qwjp6SEb8p1YUa3lfSvh8VI2nimYVtm4=	Fatih KARAKAYA	Fatih	KARAKAYA	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 15:53:14.579	2026-03-01 15:17:05.677	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sutb1pp9tb6tiyeadraqp84f	ilkerarifkaya@gmail.com	905417734337	pbkdf2_sha256$720000$4Akt86rI8Fyzhf9PiOEYI4$oKmiDElJ/O7RvGOagPayvfVCMrb9CjaBaM2GiSBYKcc=	İlker Arif Kaya	İlker Arif	Kaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-23 16:38:38.245	2026-03-01 15:17:05.683	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bx64rpi6sg1zy6g5jqqk18xd	nazarcakar90@gmail.com	905307052503	pbkdf2_sha256$720000$muwmeTfhsmrl3N71coTHuJ$4KtH1vBs3I8tDI7vFzfZjFvLwCTe/MsYnxfBmItAEI4=	Nazar Çakar	Nazar	Çakar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-25 18:22:59.486	2026-03-01 15:17:05.689	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhn90002jxycqby1jrk8	mehmet.kaya@kariyer.com	905553456789	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Mehmet Kaya	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.677	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ba45h370z4s3astnk3bordi9	dggulum.25@gmail.com	905424656083	pbkdf2_sha256$720000$F3o49atJ0K9QqXQgfANIuj$2vjaWXdFoxiJZg2ogvncMauiRSNrZ4gm+oViW8vBQ5o=	Deniz İşçimen	Deniz	İşçimen	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-26 08:39:32.556	2026-03-01 15:17:05.692	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q2cr1k7f626419hluo1uuh31	yorgundemokrat_35@hotmail.com	905536185637	pbkdf2_sha256$720000$T1U9LLP2rL1Zy0HRdq9pUZ$JfxD/c1E/qSeEKO2Y4jcAntOGC7KJ8V7YoHbVvjJOuo=	Erkan Balakan	Erkan	Balakan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-26 20:27:08.849	2026-03-01 15:17:05.694	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nqe08p0qoa85mpt3bku46ui2	gokhanbaser_28@outlook.com	905423286728	pbkdf2_sha256$720000$42GQM0ll5rATrSCPEJa3UO$7Jsxtuc9sGM0HExYaAiqCJ+Mtbv1gYNCL56GMEzUvcs=	Gökhan Başer	Gökhan	Başer	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:39:41.8	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
g6jwrk09u0knetegim0vxfej	cihan_bicakci_3452@hotmail.com	905377372920	pbkdf2_sha256$720000$8R1HFjJ44jCtV9zfaGE7LB$hT14+6tEh1sJfBn6eaShsJomVvDipKEklxBOYLTpzGk=	Cihan Bıçakcı	Cihan	Bıçakcı	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 19:34:19.282	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
k1tscfvsqj3koe8bohwpn3jh	murat_bobo_1995@hotmail.com	905070616525	pbkdf2_sha256$720000$IvmOzYedr5TdoCm1IuG2o0$4VvyexduIz7Xm7Knprv7SmJTim8iypR07FcTv/tYAcs=	Murat Yıldırım	Murat	Yıldırım	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:24:30.26	2026-03-01 15:17:08.54	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
evlw5y16rov1vji8knym156z	altayboza@gmail.com	905448662475	pbkdf2_sha256$720000$HQtGQQIeLiekGgwzdp93kL$4Xy9+5Z8c3qs921zPHJ8w+Ilz2gq+IElmzex2FHecw8=	Altay Boza	Altay	Boza	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 06:32:24.629	2026-03-01 15:17:08.543	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mkmn0elwyxd01p8wjuquafub	Sezer334@hotmail.com	905414599466	pbkdf2_sha256$720000$lxZawZXv2CZ6kYs2oX7ByX$VDtN//fIh+L/1jxzycj+kaH6oL5ZxbQow/bwBI7VvZk=	Sezer Çetin	Sezer	Çetin	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-28 14:01:37.194	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
onqhl0auo3uda97d6pee5lil	m.ayyildiz817@gmail.com	905078466489	pbkdf2_sha256$720000$wFaQ7fhegNXWFzbdHOAqjN$CGj4FA78iidrdbKfY60wI7iTw+FebXOp0rjs8dMEn/0=	Muhammet Ayyıldız	Muhammet	Ayyıldız	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-22 09:54:59.472	2026-03-01 15:17:08.546	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ymwj5s32fj945ujqbrzinsg3	okanh7@gmail.com	905466454218	pbkdf2_sha256$720000$Es4iCGZ94KUpZztG6OaMFM$lmJTm66dFpT5n9JMjxVLEW8iUdh4H6t3eHKkM3yWbbM=	Okan Hamarat	Okan	Hamarat	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-08 13:02:21.859	2026-03-01 15:17:08.548	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bp7iop6rcj4hdlzjxe5mfk4f	yunususlu2323@gmail.com	905441180023	pbkdf2_sha256$720000$oU4m6tFGDdtbJHhQGnsNhv$UUBFrLALx1mntfYurv61FveQlE5gHLfRZ7A1Kh4f250=	yunus uslu	yunus	uslu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-09 12:21:19.466	2026-03-01 15:17:08.554	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
iruhvk7jimsr2lnfucfb5j21	vk441905@gmail.com	905077970044	pbkdf2_sha256$720000$fd2E1zlGbnbbB7SoPQXvvd$RGAtDiWCCXzsX+sqEH/C7eSMYUf0Udz0gNQunHwA9yg=	mehmet volkan keneş	mehmet volkan	keneş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-10 12:03:20.406	2026-03-01 15:17:08.557	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sy5c40v3celwvu2epl8yzo8z	suleymansenel4343@hotmail.com	905426225111	pbkdf2_sha256$720000$djxrUuhwFK0LtS07K5XL8b$nceh/OKnFGB7KhjgrNZqvINihwzaAuIYscBFxp1NMe8=	Süleyman Şenel	Süleyman	Şenel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-14 08:18:44.879	2026-03-01 15:17:08.944	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
j500d983l1rut8y4swql6u1x	yildirayfdan@gmail.com	905442615525	pbkdf2_sha256$720000$vc2kUQc2HUj1blfvwHjNH4$iuFse5/C/fzYt3HGLtDiFIWUi5D/hlEbXkGkx0qXe0M=	Yıldıray Fidan	Yıldıray	Fidan	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-01-14 21:53:11.783	2026-03-01 15:17:08.947	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ph8scqure4lfi3jq9ppzfdmc	atkut14@gmail.com	905312039181	pbkdf2_sha256$720000$E5rbSmluQoLbdLA0D3cjk1$zRTceTp37zuBdtXZ70UHbSfgmp06HrnYZjh0POUKHk0=	Aykut Dertlioğlu	Aykut	Dertlioğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-21 11:41:04.34	2026-03-01 15:17:08.95	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xwu7te54f966t8eock2vt1zx	nmntly@gmail.com	905359250376	pbkdf2_sha256$720000$6O0CVxpdVCNWVIAtk2pKVr$LxpKcfuUuzDr3bpEhEOt+F69UIj6LdoNucD/qtOjx0I=	Numan Talay	Numan	Talay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-27 19:18:44.004	2026-03-01 15:17:08.953	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fjv1rkwf6hifc9w9bqwgjutt	bekir.ayal@gmail.com	905000000606	pbkdf2_sha256$720000$RNjy5gxcJgDocX3y76t6yp$Q/BOyp9sIXvhIiKuWujOuuNr52bbgf04X2BcNdmAjz8=	ebubekir ayal	ebubekir	ayal	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-12 05:15:13.053	2026-03-01 15:17:08.955	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
eirm4uo4qk08ogom2cp7zjb5	haticerumeysabekar98@gmail.com	905386494080	pbkdf2_sha256$720000$tL7NioFVep5C3jsAReAPmh$Ug1leYvQ8MeiQU5N34+rwbp1DK5Qb45sVIQxcOkIH3g=	hatice bekar	hatice	bekar	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-13 15:03:37.638	2026-03-01 15:17:08.965	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
utxiperqczsbo8b7ofapjj73	lutfi554714@gmail.com	905547148064	pbkdf2_sha256$720000$8KHDbqUXa4qRxmxRRcFT5H$cEKstJMiT5vS8Iws/MPnC+fKLpNvsBLsew7VC2aETYw=	LÜTFİ NOHUTÇU	LÜTFİ	NOHUTÇU	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	5	\N	0	2025-12-13 15:08:01.214	2026-03-01 15:17:08.971	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
l0i7alyfhhlli5x5ej2c16av	mustta57@gmail.com	905415070257	pbkdf2_sha256$720000$EZK7oPJjaWMj6gATVj7z1f$qKeTKAfLXeK049ByE7OKQIzNoHUQ/JMqKebbGU8CgYA=	Mustafa Musluoğlu	Mustafa	Musluoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-19 09:30:02.172	2026-03-01 15:17:08.984	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
xf7541llgaxi0jbh4jucyg73	bagnevruz@gmail.com	905383897819	pbkdf2_sha256$720000$xGClRN35p2TktQupSQA01f$/Rfkx3ZOfwa6Zl80lmtUiR5xwOkTEkqyA7Lx7JGpSDs=	Nevruz Bağ	Nevruz	Bağ	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2026-02-23 17:49:14.333	2026-03-01 15:17:08.987	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
goa6c70yk471ne6uwambci9v	ilbaynizamettin25@gmail.com	905452867762	pbkdf2_sha256$720000$bRxhirtO5FTcmnXnpnf08K$m+wyXTfNrhuC2vgqLsX8kr/xtMfRGVBXpj7oMMdyJDI=	Nizamettin İlbay	Nizamettin	İlbay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:45:44.138	2026-03-01 15:17:08.99	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
airputui9s2yd2hm193atuki	guncu.selin@gmail.com	905559866479	pbkdf2_sha256$720000$7N6zj3SHGVssYrjIExZixy$olx4QdholmkfGlDx/FByUhVAPA7cy+xzBo/b+fOIFFQ=	Selin Güncü güzel	Selin	Güncü güzel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:00:37.841	2026-03-01 15:17:08.992	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vdhhwfdesi5tbj6jh884kh3h	bilalky43@gmail.com	905526279193	pbkdf2_sha256$720000$XRNk0MUNYHB6WrXTLMRxfn$HqFwjntvwr+Du7eVL/HhnozMI86rxuN9PnZtQGRQEGw=	Bilal Kıyanç	Bilal	Kıyanç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:05:31.948	2026-03-01 15:17:08.995	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sv9g069kphsgc508vyu1w1tx	hafsafeyzayavuz@gmail.com	905363575632	pbkdf2_sha256$720000$ouzRIvrCaPMLSHDZ532ex4$aAGwBwPJfNtwqiPwUa7Q5OdnMHrAiEUR0nMheOHmxLk=	Fatih ERKAN	Fatih	ERKAN	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-02-28 11:32:00	10	\N	0	2025-12-12 14:00:12.909	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jslkbi1cdqys4zb0myepb1pr	arhanata1907@gmail.com	905464070527	pbkdf2_sha256$720000$DH7NsrEOUIaN69sSOkf37D$IFveLGSrBcxRmsXHslwV0BgKHGnjPKZrsBbzNiHzzJ0=	Ferdi Korkmaz	Ferdi	Korkmaz	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-01 19:30:44.266	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
snxhz3tjs1gf0ieodzvywhdc	hikmet625@outlook.com	905528882559	pbkdf2_sha256$720000$N5oIzVAvBBcL5Du8sc9v40$WvdUlDyJGEly3BtnSUVAQ02npgp/x7wnbR2zgKQPMW8=	HİKMET SEZEK	HİKMET	SEZEK	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-08 11:01:28.887	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tnlcosaxvcurw7ge58x388jt	cagri3842@gmail.com	905531118898	pbkdf2_sha256$720000$CrQ2nkBto4svzAkCFcWJRT$iioFAD8gs+ZRdPXtOoI7CEJVc5uqFmOuKcL5Z5K77Ew=	Çağrı İbiş	Çağrı	İbiş	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 21:03:27.799	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
i9ph1d4x6uj8qmmxg8d9xwjw	mehmetalierdem560@gmail.com	905459045325	pbkdf2_sha256$720000$r4j06n8Mw7rUAnM4fL82PS$Moek645VZmz9TBrlewmc7Lx3Dgd7CHxDDLUQVcqQg7Y=	Mehmet ali Erdem	Mehmet ali	Erdem	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-30 10:45:03.438	2026-03-01 15:17:09.001	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
abcgrw1r5xnzxrbuqao4ymz7	redsee53@gmail.com	905439398253	pbkdf2_sha256$720000$FJRIMIs6YcvJYx70muwCaO$tNcNcRtYY2bD1Bm6JhPVT5B8zls+7D8r5kv0RnC7BDs=	Alperen BABAL	Alperen	BABAL	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 11:05:03.036	2026-03-01 15:17:09.005	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
b912h4xeqo9jpn32qnl5n2dx	zeynephasanciva@gmail.com	905330168991	pbkdf2_sha256$720000$9Op9CpzNrrLIgsstFsmvAR$FSYRasRc1T5bzTCG2rnBvdXUDTFY43iOkb12M18KU80=	Zeynep Tuğçe Civa	Zeynep Tuğçe	Civa	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 09:24:38.017	2026-03-01 15:17:09.012	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
s3iliokr1zr5o87qxmp97yso	keziban.aktas5534@gmail.com	905342240149	pbkdf2_sha256$720000$lxTVyrYy0S2K1FVHy9g87b$N7obFM0U4tFVEySzU+DwLNiefenB8FSy7wBQ2EZHSYc=	Keziban Aktaş	Keziban	Aktaş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-08 18:04:14.096	2026-03-01 15:17:09.016	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qp6co0xsxrp9fsfj48v9uavc	gulis26@icloud.com	905520220038	pbkdf2_sha256$720000$6dgQ8WbtlrkD0YWSXySrPl$qwDgpZ0w2nDHX5hKnpvTF/2Tg8AKgY/udcfRhq6RrrU=	Gülistan Yavuzel	Gülistan	Yavuzel	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-13 21:39:51.515	2026-03-01 15:17:09.038	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qrkwausgb4ujmhi29leeqggf	gulcankuru1985@gmail.com	905557700579	pbkdf2_sha256$720000$LaMwhUWktxOU5spK7qLyGC$QLcshT1t5wmexBBYsS+8q972ZGSu2OxUP9rdTNE6JRE=	Gulcan Kuru	Gulcan	Kuru	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	10	\N	0	2025-12-13 22:45:16.786	2026-03-01 15:17:09.041	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ckfxd3au8zyqhmg5yp3tbfnq	canerxxlrc@hotmail.com	905415205164	pbkdf2_sha256$720000$Ek5AVAkXRIMpE2rA99cSUZ$ov5piWP1hszwjassNyPH195I1ErmlLMHZ8qnmCMIc/w=	Caner Kaya	Caner	Kaya	\N	USER	f	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:17:46.027	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fq6gvruags5ddk8o7tzn4pxe	unaldd08@gmail.com	905419587608	pbkdf2_sha256$720000$J2JxUuRQpcnqJXPrtB1aJT$iFyu6b22ffPTEcy77BE9G/mM0GxyI31U8YUiKYACf5U=	Ünal DD	Ünal	DD	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:27:25.635	2026-03-01 15:17:07.078	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kc0br2bog3cwrgc411zclost	muhyettin.elci56@gmail.com	905526720556	pbkdf2_sha256$720000$CbBYQn8nOZ2I5k2xS8iqK8$99xvxHhk6WOrX83M735pWMJOd5IHloFP+kYHDSPlrno=	Muhyettin Elçi	Muhyettin	Elçi	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 20:41:09.396	2026-03-01 15:17:09.328	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ii8dpncffgg0ig1gi90fozhm	ekremavci65@gmail.com	905318853131	pbkdf2_sha256$720000$NBVEnVpx0W16S8uDdEOZbg$HpX4AR5dXXQ23ttzcIiv1EL1ncE5gFjZqMTQ7UTLq7U=	Ekrem Avcı	Ekrem	Avcı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 14:43:39.631	2026-03-01 15:17:09.337	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
t5ut0nkcwmsjgzfvewx7vhtn	ilkay_cam67@hotmail.com	905396056037	pbkdf2_sha256$720000$XJq45JWoDSHlYzv2JQJ8Ob$xXwD9Z80saWzQttQP88PkCM4v4gMGkcL5OddCmx7n1g=	İlkay Özcan	İlkay	Özcan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:31:09.94	2026-03-01 15:17:09.341	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
o6eu7tpq4e6dofi1erb8p0in	mehmetcanerkan96@gmail.com	905359219738	pbkdf2_sha256$720000$Ugxsg8HjDmcdeOlZ7XsMEA$nHS+lNmORERXuc/DY5S34RwdxWtb5nj3ytAGUGt/mmY=	Mehmet can Erkan	Mehmet can	Erkan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:31:23.237	2026-03-01 15:17:09.35	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pw1ifmkfid9n4egupd7nfqtm	onurbolukbas006@gmail.com	905331524010	pbkdf2_sha256$720000$DCyefjE7aCfNhQjViRoL1e$AqT9K9Z2yjLc8Ptj04UpdHmw9kz8u9ZEVE3YhJQWBss=	Onur Bölükbaş	Onur	Bölükbaş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:36:29.616	2026-03-01 15:17:09.365	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
i23pk77ukpm8ouqh1ljlu6q1	nacreszotka@windowslive.com	905416814558	pbkdf2_sha256$720000$kPWh23DJNPvK8xg2pHCOx6$Ha3fkc30FZu7liKZ29VFP7GOey5DurvbYrjJ19ecmlc=	Sercan Aktoz	Sercan	Aktoz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:55:32.744	2026-03-01 15:17:09.371	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jvxmhkm9q45phtzna7z4rlx9	nurullahondes7272@gmail.com	905412185889	pbkdf2_sha256$720000$6rCudYYcagLBaxpdDilFmI$pyO2p+tWa0fmlKd8wNnkX3KIQUwthMvuiAPyZD5dFuQ=	Nurullah Öndeş	Nurullah	Öndeş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:56:22.681	2026-03-01 15:17:09.377	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vwqu27lobv2qzhebf910c7q8	feerdemir5@gmail.com	905316841665	pbkdf2_sha256$720000$I8jMxVGt80FHXFqHXW8mJv$oo4Ykj8VWn8Xa8ldkMU3HT8zUJKnFvm9ra3NYXfuwQI=	Fatih Enes Erdemir	Fatih Enes	Erdemir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:00:53.231	2026-03-01 15:17:09.38	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ot3mgipz088m83pl9l43oi41	kadirkilc3@gmail.com	905325829316	pbkdf2_sha256$720000$XHsi6H0Zh3pxhSDDv0whma$jA7tFqF4tUWGqfV3nHHXGqQTHXEbiC+i71ePkwK6KoU=	Abdulkadir Kılıç	Abdulkadir	Kılıç	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 17:36:50.24	10	\N	0	2025-12-30 17:34:52.51	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q8bqbs2pbvon0rjd859dfg5j	mehmeterdem14534@gmail.com	905075606345	pbkdf2_sha256$720000$vubuizqJ5kj0qLh0HAOsVc$7ZBQuzgZAUWVFDRJZ3ZzZyW3P0drsFBp1jo620pq1sg=	Mehmet Erdem	Mehmet	Erdem	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:45:58.979	10	\N	0	2025-12-13 17:23:34.491	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lhzjixqa6yvjqb2buaoj4tkm	sigirciahmet02@gmail.com	905388571711	pbkdf2_sha256$720000$WFxoMrIZFFUXIBtXk1x7tS$NKlNo+9emMKzVzaALJh5DkB4xMn+IdSl/8ZZamwBznY=	Hacı Ahmet Sığırcı	Hacı Ahmet	Sığırcı	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:29:57.307	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
rlnc4x0h8sjwuya2be7v9ylx	zehraher@hotmail.com	905064576541	pbkdf2_sha256$720000$TyFfiH4DjGCQBiZepH3ZeH$t+03bRDxYPc41S2C2Y/l0fMn+15OWEK3mKSSJNYnpz0=	Zehra Hergenç	Zehra	Hergenç	\N	USER	f	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:46:42.389	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nrce9mwwwtovcd9nua6wkdnb	mesutakbulut3465@gmail.com	905428130799	pbkdf2_sha256$720000$7GIM0cVP3OrT2ix2U0Dv7Z$v/fwH+9Plo4nHYOKKIwWKmSv1OFyr7Z4GdhBnZlVwvk=	Mesut Akbulut	Mesut	Akbulut	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:03:32.54	2026-03-01 15:17:09.385	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cgfpopkd85ghwrkkw83rlbtm	tmzyrkberkcan@gmail.com	905459783836	pbkdf2_sha256$720000$RftstyQ7scm4bAlVGvKFwU$0JSLqTWRmCzsGryj6GtYfDz6A2TfdNaAdZhINYZc+A4=	Berk Can Temizyürk	Berk Can	Temizyürk	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:32:59.4	2026-03-01 15:17:09.388	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
m1g8umqsuppyblqixfiykiub	serkon73@gmail.com	905393902773	pbkdf2_sha256$720000$QrhiyVJ6CDhThGclQ9XLRj$Ss9jwbV9cmExotxICTy31OEJEHflhd5lY2k2IJT/mHU=	Serkan Tosun	Serkan	Tosun	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:33:09.563	2026-03-01 15:17:09.394	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zqlxv74m5qh6v1x1y2d2ibmn	muratakkaya70@hotmail.com	905424921684	pbkdf2_sha256$720000$oyMcn4RsTHSpJa73i6O5Ya$7gT9nE95hxDCIj35YpbDZrnHwDyH0Rxnsg6920CF7x8=	Murat Akkaya	Murat	Akkaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 17:38:00.173	2026-03-01 15:17:09.396	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
g7odi9x44etbse323h817mdp	ekrem.erol.80@hotmail.com	905435219806	pbkdf2_sha256$720000$WcqM5LD7XXpbGNOoTHZsYa$Knj7gPZXKI6Dkk8ulpWf0Wf998AGAURQfPmEx34dx3E=	ALİ EKREM EROL	ALİ EKREM	EROL	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:18:08.725	2026-03-01 15:17:09.399	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
w6kgpj0t9anhuaws5udlenyw	tanmustafa200@gmail.com	905061388655	pbkdf2_sha256$720000$8gXM4Rl2nyhVoRbIndP3ZQ$F9AxXehsBx1tflroM7u+ivQoxT90ZEeFqmfJYXe8CUs=	Mustafa TAN	Mustafa	TAN	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:40:09.636	2026-03-01 15:17:09.406	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mne0bktcdstuufnnm59akrjr	omakas25@gmail.com	905456899899	pbkdf2_sha256$720000$3KDwXW5lf8E2P3JyDSCQEo$DgKDuDBT8hWR9l81AMQtBTLfoxt1QKALE96nhx0u4PM=	Orçun Makas	Orçun	Makas	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:59:15.291	2026-03-01 15:17:09.409	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ecyul22273rbje9km5rxdvoh	gkhanyce2023@gmail.com	905356175361	pbkdf2_sha256$720000$nydcOyUrSLXmBQKUkZjAK0$ZF4pcG9KvelPU7n4Qe6K++24s7YITMaWzye9GXvXVr8=	Gökhan Yüce	Gökhan	Yüce	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:59:54.985	2026-03-01 15:17:09.412	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wp73wiwnejx8o7j6qfm1gxbu	starworsxxx@gmail.com	905334358705	pbkdf2_sha256$720000$cctTDdV4hWaIoyPK32c3fK$9EoTwtWbIa/Igxze6f5UJitG9gjcOTerZMmV1yoj2xE=	Hakkı Zeytinli	Hakkı	Zeytinli	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 19:08:25.857	2026-03-01 15:17:09.415	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
r96xi2x227r268s014074c67	Mehmetdemir0278@gmail.com	905443140269	pbkdf2_sha256$720000$FCJ46T10QsDI2d0NO6qroz$8z2HycewpA0OfMdM28XtDfuTolGVMKJaxwpYCJRPPDs=	Mehmet Demir	Mehmet	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 19:43:56.79	2026-03-01 15:17:09.418	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
syubo46m49uuss36we5nda8q	cakir101999@gmail.com	905417374677	pbkdf2_sha256$720000$RS8YDnlgRlCIp7DrpkVgxG$p4yp6oF1hN2E/9cnTJ0OXReCBsKLbRLi8PSPWmCo/jg=	Ahmet Çakır	Ahmet	Çakır	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 20:16:19.971	2026-03-01 15:17:09.421	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lzfumi7cv9uyeho5ug7lynk2	ebrutk1907@icloud.com	905386915992	pbkdf2_sha256$720000$iKdCt0HfXQdex5onMzCPle$qogMxhRFq3jLQWwV6iH+2ZD1JKI4LfKG1aj1gIhmvbA=	Ebru Teksöz	Ebru	Teksöz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:35:31.036	2026-03-01 15:17:09.423	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ytf5z2g66868sk12pga50sct	baranfethi20@gmail.com	905075365962	pbkdf2_sha256$720000$InBt7nLnnJ2knFWeDE0hiA$KZwCgciftxhoek/+YDH5LEC24Woh1LzB7HyHx3I2ZUM=	Feti Baran	Feti	Baran	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 12:50:25.688	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tfaettes9i66nih9w2zugn01	sametates4@outlook.com	905524650345	pbkdf2_sha256$720000$Gy0BYWCvmPkRfz2lBzcKBZ$/N5BJaCIOdw1g4fAWOEyRyYM89TqXWoM3LzhAIQHV6o=	samet ATES	samet	ATES	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-20 08:33:01.477	2026-03-01 15:17:09.456	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tzwv5x5v6xa5ci37pcx8ayet	ozlemrv34678@hotmail.com	905435300185	pbkdf2_sha256$720000$5eXtjCm5ODawUbarEWWNHu$iIv8zWbzm/kTyVF2Wbn5GueE7mtpB1Y10U2ujC0cpFA=	Özlem merve Yücedağ	Özlem merve	Yücedağ	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:25:07.202	2026-03-01 15:17:09.428	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jn65yckoizjedcfduotyqno6	sedabzl61@gmail.com	905342389412	pbkdf2_sha256$720000$swptFZLeqAxOgzDcYbxCSC$0AOvsSyDSWHf10Zqq67x/kOWhyrbIJet8m7cepl1F/Y=	Seda Bozali başkök	Seda	Bozali başkök	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:25:31.562	2026-03-01 15:17:09.43	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kw5sm7pe1fau0kvhkyusfb29	pirbudakozan97@gmail.com	905388708028	pbkdf2_sha256$720000$1LG1bNf7Tp8rU39SkJ637q$4JXAofS5SIZUR3To+jiXZEQBAJ5v6mh39xU/7IVNKXk=	Ozan Pirbudak	Ozan	Pirbudak	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 16:30:15.585	2026-03-01 15:17:09.433	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fzm1x63narr153zc5v552kyo	ayse_girgin_03@hotmail.com	905309055682	pbkdf2_sha256$720000$x39zo4lslsK4WBeeTCYySp$H/pXuVxG5HjU/hXdyEGLQGGEJKW6/EB3hIaQ3kse/bs=	Ayşe Girgin çalış	Ayşe	Girgin çalış	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 20:45:34.812	2026-03-01 15:17:09.44	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
giujfpy7zlcm1c4mbifj48o6	huseyinmuhammet.namli@gmail.com	905511798195	pbkdf2_sha256$720000$mPyGkjgUdfCuyoQBqqEyk9$RlBVrEjGSZ1nt1FAjfQOShRCclRLYJ+0W7Rqh+oPbRY=	Hüseyin Namlı	Hüseyin	Namlı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 21:19:57.463	2026-03-01 15:17:09.444	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hsv722p52acfody31xl5dk3y	Bazganramazan@gmail.com	905416315068	pbkdf2_sha256$720000$R77nXcpLILikjw8prULYQI$gcheKLxrRxsG1shlTAErjJwaAFpVgG4fRU+DygnLgp0=	Ramazan Bazğan	Ramazan	Bazğan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-22 01:27:08.816	2026-03-01 15:17:09.447	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vedbimpi8y07t3bkjeu170fg	huseyinyoldac629@gmail.com	905358331277	pbkdf2_sha256$720000$C07B8b94jQRPGJxCzHbPLN$pUDTVD+yOXdgvvJmfyRBvFz4NADw5MVrlAzG2KfsPa4=	Hüseyin Yoldaç	Hüseyin	Yoldaç	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-14 10:20:06.654	2026-03-01 15:17:09.462	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zmd30fzanhx5pcybebl6uv9j	ikayabasi23@gmail.com	905413435906	pbkdf2_sha256$720000$3R8EBEjgM2ZPr8jsvYYPDA$5RL89SF+RFhMclEptP9bFchXqegVxaxnHi7p2XsbVms=	İsmail Kayabaşı	İsmail	Kayabaşı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-14 14:14:26.703	2026-03-01 15:17:09.465	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jhobtsug043jwfr95ut1hgvf	iakkoyun350@gmail.com	905350548516	pbkdf2_sha256$720000$ZEgg28qa8ULl8HhJi0BYwM$wcJ10096zLwS/VIXTHW8Dzu1KSudN2JVCoPehzxnksM=	İsmail Akkoyun	İsmail	Akkoyun	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-14 14:23:21.638	2026-03-01 15:17:09.467	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
m7oiothls6kj772cxoo5cpfm	erolkayser38@hotmail.com	905364409406	pbkdf2_sha256$720000$ix0B5ZkQmIDIxSoIcLobrB$ihI2ylbq/oN/81ZZ0r44et9RgCSoioObzmPCadBjYe8=	Erol Sarıduman	Erol	Sarıduman	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-14 16:18:44.893	2026-03-01 15:17:09.47	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
x74r63p749smg35uofum289d	ahmettoka03@gmail.com	905079075103	pbkdf2_sha256$720000$rVQwJPFRSAn0ZIVYC9bMWZ$eeuKPsBRF9+4hS0rtEvLOUBc3VvBkA88YxlfMlL22K8=	Ahmet Toka	Ahmet	Toka	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-14 18:06:54.379	2026-03-01 15:17:09.472	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vyv7gbdcyw42omlkd56wvp06	kingdkb34@gmail.com	905357246823	pbkdf2_sha256$720000$mHg05jMu3feTsqFY617c1h$yJskHtD5fheqL2X/XDAJ9jOFxWiSY6xbNW4ZNbx3zMo=	Bekir Özgül	Bekir	Özgül	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-15 07:55:37.11	2026-03-01 15:17:09.475	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ukg5x65ffnnb2ccrawumsgxx	parsel_006@hotmail.com	905416805775	pbkdf2_sha256$720000$gHb74VXX5hvf5JCtSP8Cnq$s1ZMawqTkC09EVadIJc9qbiT5OTOOG8V2jzznO9tRT8=	Kamuran Hallaç	Kamuran	Hallaç	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:43:05.559	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mnh1xi9jxf5lhdw219qqlizh	organizasyongul@gmail.com	905434534520	pbkdf2_sha256$720000$QKw1pQQX3xfgVYehUZdZm0$vNhUMMgUskO6KQftWnuEhURyLdZEjmhrO+yUuF7qDp4=	Ekrem Kızkapan	Ekrem	Kızkapan	\N	USER	f	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:00:53.884	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
a885fa2x1qd951zt4xine21v	drdonur58@gmail.com	905333396758	pbkdf2_sha256$720000$HUZh06KW3F1zVCc2sdaPrS$zhZAmOiEsD2/sahGiu8xOLhLgtbbBuPoZ9OhdP1Rn3Y=	Onur Coban	Onur	Coban	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 15:52:56.573	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mzs8t3onwggtip5hyvntu5g6	osmangner00@gmail.com	905454379331	pbkdf2_sha256$720000$PYXVoqM3dM9b3EZk1s1a5I$TC1g0DX0Qy94TLlqczQ/8NOOnraC+0fceMFhjsr/Kqw=	Osman Güner	Osman	Güner	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:13:48.814	2026-03-01 15:17:07.542	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bmx5pe0k8vzolao7da6dzvz5	baranaysegul39@gmail.com	905010760072	pbkdf2_sha256$720000$HxHOBmxNyoeGfbOBGsJznS$A3l9zxPiC0epomfuAb6yDJKFE0SWB2xc5M6QVreua+0=	Ayşegül Baran	Ayşegül	Baran	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:11:26.99	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
k40jbh768g0wgwvsg75fi745	nurgul.durmus28@gmail.com	905353488435	pbkdf2_sha256$720000$Fahg3NJN94KWONQAOUPB7U$VbvhGl2hApm2r+ZybitQKLpsqfA5NtoONWhl3Z+ZL8g=	Nurgül Durmuş	Nurgül	Durmuş	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:23:45.735	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mvxefjuey3qppwygqf77727s	terlanermin@gmail.com	905425885865	pbkdf2_sha256$720000$gzvES1cSapaN9pZojl1GKn$Ur8ofRyzhRPORXHaFuhS7aeuUxJqdwa5LurbQqzqD/g=	Terlan Çifci	Terlan	Çifci	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:39:27.208	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mc52uu7ampq46g9kfglvg6ui	alimaral80@gmail.com	905514377604	pbkdf2_sha256$720000$DdsSsMedzVxngaaUy3ulOI$tIoyj8tfxPtq6ZNg7+ZklpvSLTNGRvVuYXtXQzfhN2o=	Ali Maral	Ali	Maral	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 16:15:10.368	2026-03-01 15:17:07.545	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
phlxn7i4gg3hgqdibqyuqeqw	haytabusra38@gmail.com	905551820932	pbkdf2_sha256$720000$4xLnGo2WG7fF71TH5hfmpO$BSvSfiCG529CL+CdpB1yQhAb9ANZNOOycz5bUmYaXoA=	Büşra Hayta	Büşra	Hayta	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:51:36.799	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cw5eymqfu7e1d5hjm88jtsb6	candostu88@hotmail.com	905414006125	pbkdf2_sha256$720000$UkLSbNMz8Ul0kRJE6YW9M1$QsaY9Rqao/GpeyAdSuatnDkPH23OGqMnCUJdcp72l0E=	Mustafa Budak	Mustafa	Budak	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:49:00.177	2026-03-01 15:17:07.997	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wy6umk1vl7aglo6rbebb430h	sezaan.1975@gmail.com	905449791975	pbkdf2_sha256$720000$SpvqMQ2abChWEtxHWgqT4r$aDDrC5KGJx/2RcFAunDZVWImj5Hg38KBysIP/iaeaY4=	Sezan Erdoğan	Sezan	Erdoğan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:51:16.811	2026-03-01 15:17:08.002	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
degm7rrnqgjidt6m04tui7y2	melik97caki@gmail.com	905377075494	pbkdf2_sha256$720000$Bsj7FdbzQ5ZHGUbb7MKg55$jo9nbsIavzRO1WuWpkaggXu2mPD5BGaCMcBvywdRuVo=	Melik Çakı	Melik	Çakı	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:24:17.416	2026-03-01 15:17:08.008	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qmuawqfwicerc7livw2dqmy3	bora.karacivi.bk@gmail.com	905424452223	pbkdf2_sha256$720000$EjWiZtznUm7n0poEH1HIVz$sBh/yAbpCGo814HErDd+jdtFy9ggO2jeVzCiuvWBKQs=	Bora Karaçivi	Bora	Karaçivi	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 19:20:34.893	2026-03-01 15:17:08.012	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
yrb9iqhbdpbr1xhlrwo6enva	fastcool51@gmail.com	905532106274	pbkdf2_sha256$720000$HhxgCfyGEsZ5QeVyJeniRa$zFUf+xtpFzPOCwDr+LHY/QD5qvIkpRbGyFgp8xhSmBQ=	Yusuf Kösem	Yusuf	Kösem	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 19:25:29.74	2026-03-01 15:17:08.022	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qmzisxl4rhj9sgj8nxrx54td	gesmanur652@gmail.com	905372424194	pbkdf2_sha256$720000$v7Ah2fjJhehtbt064vOmsJ$TVuG3vsIPu6QAwHL7UoCoZssYCJ7vBoY8fwzToW0GaA=	Esma Nur Güngör	Esma Nur	Güngör	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 19:34:25.212	2026-03-01 15:17:08.025	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
o9puyvpq51z7d9owqwdoyl11	bilisimtr@gmail.com	905324003736	pbkdf2_sha256$720000$LzDKBOZIh7TzExzhzwapKJ$yA/FKnzRBLMBU5AXjTBi7c/f3Rrngzcvb9450pQVHRk=	Mustafa Ç	Mustafa	Ç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 19:38:29.642	2026-03-01 15:17:08.028	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pgf8zz4bik1m3zleq2dkm0bl	sedattdem@hotmail.com	905512525400	pbkdf2_sha256$720000$Nqlx0WQwx51OXZz3yI4sjL$SuHLO+QSktlZ/+4KmpX4kjxIOfSpJ4Y/u8iDWvdp5dI=	Sedat Demir	Sedat	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:11:58.664	2026-03-01 15:17:08.044	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
o3ck3wyio9yq1adoykvp0l22	turanderya79@gmail.com	905318724173	pbkdf2_sha256$720000$te29JKJzSRmR7Bq7btixuz$Gk8VEHp8SIgLmpEQsRDinMTDzZsKwDBJ7vntiVAYyPo=	Derya Turan	Derya	Turan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:14:03.331	2026-03-01 15:17:08.05	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jvd528oxg09ptt72ipqwbo99	ob_1907@outlook.com	905336478719	pbkdf2_sha256$720000$LEPF5NfRrNucIWe7dxgFZg$B0HzXuGAHp53S8xvWF7Y35/n2gcS7M1bdzxoN5sCkqk=	Oğuzhan BİLEN	Oğuzhan	BİLEN	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:14:50.437	2026-03-01 15:17:08.053	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
fewp10zm81h284lvl52wbrh2	turksevenilhan7467@gmail.com	905345021847	pbkdf2_sha256$720000$LIRqSp1xN4S9MsHndb2nbp$sqjuwEfYNfbdmCiVT0lncEytm3R8rCQMkPAnBeJsais=	İlhan Türkseven	İlhan	Türkseven	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:17:00.22	2026-03-01 15:17:08.056	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ddcaox5p6oovr7ka7un8zhyz	ridvankoc34@gmail.com	905318658131	pbkdf2_sha256$720000$dz1l5EdUpUmK1LsXFBPJUI$7h/X5YfWX3FL5Xu+sZWzDkOY5IXcq+3zXwo6kBiixmo=	Rıdvan Koç	Rıdvan	Koç	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:20:27.747	2026-03-01 15:17:08.059	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
byh3sjqbqsdussrfx5xthqc5	mdidemgerger@gmail.com	905530273831	pbkdf2_sha256$720000$IMBb50jRNL0zvZgXOCGCda$Eyc/siLGASiAioW3eUAAybt7vlx/IpgBBWn6bSVrDps=	Didem Demir	Didem	Demir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:29:17.744	2026-03-01 15:17:08.062	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hzs94lh28jwssfe5cqflwtuz	osmanbabi.hotmail.tr@gmail.com	905444743179	pbkdf2_sha256$720000$a5K1GUQHUyikgL70COiuXW$ndpW+7gGZM8xl5UWmgKJmzmBxSRWmJy13z0s2qE8ppE=	Osman Babi	Osman	Babi	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 20:49:33.789	2026-03-01 15:17:08.073	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pzvutl7ceqyaly0bdlycxaqp	sahin19882014@gmail.com	905349763520	pbkdf2_sha256$720000$AumBtvVNmgUU78IDCnjV4Y$VpaePSMpdcdaU3niMsYcau1VdTp9KaF7ceyIoszcYN4=	Ahmet Ali Şahin	Ahmet Ali	Şahin	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:46:25.583	10	\N	0	2025-12-29 19:22:35.332	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lhksw0snye2zdqkvxchqm2jc	muhammed44760@gmail.com	905301370444	pbkdf2_sha256$720000$aYYgHTiY98ZbSwLtrntKNX$ag8fYe0Kj8Gg84K8pkZzo813gydwa85+2XehsGxAaeQ=	Muhammed Oflaz	Muhammed	Oflaz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 22:26:07.766	2026-03-01 15:17:08.079	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
t320w7x56dlba5y5gs6s8z5d	aykutcskn1988@gmail.com	905309132752	pbkdf2_sha256$720000$JuKXneKgsr5Nze8oz72Hfd$zj8clzvTYlDWSxoS5PhUmpbh09yxvz//eF7Fr1HFuTA=	Aykut Coşkun	Aykut	Coşkun	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 04:19:51.979	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dytguxw431bnm9y0f2bvwr4e	antikgl37@gmail.com	905445694114	pbkdf2_sha256$720000$KdLYZqSR4Jn714StpFbpdC$+yEhU8FsqWQEJ8EnG0ZCL9VZUsh2lkfOUt5otc6DG4I=	Şengül Toğral	Şengül	Toğral	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 07:27:42.62	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
b592zv91e8qpj1bu8bkr5wgz	osman_kursat@hotmail.com	905333677923	pbkdf2_sha256$720000$61G2vHslcNQHZYVUjknXBg$7kL2RPTVD4GFWczCMVKxscvyl7aOomPRyT24OplRte0=	Osman Kurşat	Osman	Kurşat	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 08:08:54.944	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
y02gzy1zg1frcsb7uftiq1s1	sedaa0986@gmail.com	905550968882	pbkdf2_sha256$720000$T2xcm5Wvq1goxzvGTBWne0$ENnWc2rYJDnshyrtDhJveIwv4PIv2wMjjA5xEylmwn8=	Seda İnanç	Seda	İnanç	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 08:56:38.769	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zpqdng9fnb4g6knszkfjpr23	ahmetgzm19@gmail.com	905529505310	pbkdf2_sha256$720000$qZcsed8IyIRKWEUgsSwL1V$AMPiVMEpLNl0amCn2Hi2AhN8JkN25yWkoZVbIBYjXyE=	Ahmet Bayram	Ahmet	Bayram	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 09:17:08.144	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tc7s0s0eq3grujuixwl9m0xb	jetosman6565@gmail.com	905539644665	pbkdf2_sha256$720000$4scu1nm5ST8XQd5fvyjcqh$WjXgQ7L8ZfdeJ9uI+v5AqpcnwsqZabIBRG8qzGt7tQQ=	Yusuf Akbaş	Yusuf	Akbaş	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 10:57:02.788	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sn7s1i923gq9qhng97xppqvc	serkanyanik06@hotmail.com.tr	905012011810	pbkdf2_sha256$720000$LTOQUy1mnPJokzsJv5DOyv$BV18JgdqUTczU6CpClXgMmGe98HL6C0yb/92KqLOnB0=	Serkan Yanık	Serkan	Yanık	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 23:03:29.185	2026-03-01 15:17:08.082	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
do7umzmxnf5pxmez7azfop9a	sbrikara84@gmail.com	905541897644	pbkdf2_sha256$720000$2vAStJXbTqncNaRZZ2yqx7$nYk9B/XXZPWxwACLkbBiYSBakkL5SaVp6ypGSpeWl/Y=	Sabri kara	Sabri	kara	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 05:07:22.191	2026-03-01 15:17:08.088	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ny97cx1ilct4f7kb3nxyxb9s	grcn.ucar@windowslive.com	905076856335	pbkdf2_sha256$720000$zcmRvmRFQoHA4v8Uwxxurj$Ux5QjR7SnQ6AVI5vnTBrPvRsJy265Zw2K/01HuK6R1Q=	Gürcan Uçar	Gürcan	Uçar	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 07:55:26.91	2026-03-01 15:17:08.109	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
mlms7zv0xvk3guu6tz9jayf9	mustafacetinkaya892@gmail.com	905318159387	pbkdf2_sha256$720000$dsf5ZSaLFh1XK8Z4CMU5Wi$hLrQTDNEOtQA1hFZgr1Cm0eOCYTAOtbYpAwqvWspIh0=	Mustafa Çetinkaya	Mustafa	Çetinkaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 08:10:46.062	2026-03-01 15:17:08.112	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
x623xer0p3dsdaralprt207k	VolkanD.60.34@gmail.com	905366858675	pbkdf2_sha256$720000$xN2WnBuJhFC4LgePDEl4uL$Rp7M39PRlWgU51CknsE+zF0rk4Dhooj0atQ1/oxGP5U=	Volkan Durmuş	Volkan	Durmuş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 08:19:03.154	2026-03-01 15:17:08.114	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
c5iqrx7oi9n8rn6gwty0c4ta	filozofiye34@gmail.com	905469549451	pbkdf2_sha256$720000$6CvDgVXGlcQSz11gTSqLUW$dutZIVWQI6ff7ygKCRe+IGRDo1U4GLTtZwYAEG6Uago=	Filiz Arsal Arıkan	Filiz	Arsal Arıkan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 09:13:51.482	2026-03-01 15:17:08.363	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nkrm8fxk0usxe29r7iyz7cil	ecgla526@gmail.com	905467883142	pbkdf2_sha256$720000$hIJptxGIinkurKNbvWLwN0$MSmPZzZ33pyiOKCdN4gVtGpR5ScN8ZfzE/s5tJWfv9M=	Ayşegül Gülten	Ayşegül	Gülten	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 09:59:39.742	2026-03-01 15:17:08.369	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
kizgatosuxsxschud3iudjbn	nhtdy14@gmail.com	905375674734	pbkdf2_sha256$720000$6pSXzqLWoW6uciqcCKY9uN$+rbVfDhdOWKqAmowqKp3iTd0FMMw296PIpQpQzpbAm0=	Nihat Dayı	Nihat	Dayı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 10:39:18.326	2026-03-01 15:17:08.374	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
itk0ud4itngqig3hxsxcqott	irfankokten@gmail.com	905368106455	pbkdf2_sha256$720000$kRy58RpeZokKOUvc2ZtR1Q$45Bwf7h1QZaPzPaAgUCKfkpEkyJGwLoTJjpyjBL0aQ0=	irfan kökten	irfan	kökten	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 10:40:00.63	2026-03-01 15:17:08.377	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ya5668b4nuciyx1ekjtt0m8a	asireco60@gmail.com	905330503884	pbkdf2_sha256$720000$m6JTjkhHVE3s6i2VEvZOxY$OU53QJnNVcyyRqCmlgBmWpUYGF9hjBdydxv9xlAsQL0=	Recep Yıldız	Recep	Yıldız	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 11:11:05.95	2026-03-01 15:17:08.38	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
oj08bc5lplsuz0k13heu9o7r	Volkan.donerr@gmail.com	905439525690	pbkdf2_sha256$720000$8HcFFX5XA22zTGodAO96P6$R8cWM3IC00WYa9W1z8+dqeeq2UhbxqVnjmE068QeDTM=	Volkan DÖNER	Volkan	DÖNER	\N	USER	t	t	premium	memur	\N	\N	30	t	2026-01-29 08:42:54.936	10	\N	0	2025-12-30 04:42:56.23	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
lierlm4hns53rw6bw0ygvpa6	mpinar34@hotmail.com	905306680845	pbkdf2_sha256$720000$HsGZIkmr84KjCg5aXXMuXz$8jI3leJaHIEy9HMUX/C1qNlchpZSuWcuxvO+xEXZIDA=	Mehmet Pınar	Mehmet	Pınar	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 07:30:55.461	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hnw623qvirrvj6f4it3l5agr	tugbat24@gmail.com	905529314439	pbkdf2_sha256$720000$quGb95ZGdtS1vIz7oBc4xP$HZL9EuAx9KNx03wzk1W7VSWlR5b+y2sPk/O0Y9NPVbA=	Harun Tatlılıoğlu	Harun	Tatlılıoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 11:39:30.174	2026-03-01 15:17:08.389	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
uk5oz1hzerkwc1a52se0k2qf	fatihhatice270217@gmail.com	905446716523	pbkdf2_sha256$720000$UvRBtG6mHD7rU9J0tlkFzE$CK2sg9JxL2VEW4yW5HwyzKU+K57tc4nhYGT49+F3yAg=	Mehmet Fatih Sınan	Mehmet Fatih	Sınan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 11:41:43.466	2026-03-01 15:17:08.393	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
htyjih8wd3re4r25jfli7axv	ardenza414105@gmail.com	905544687240	pbkdf2_sha256$720000$lnrW9AsXgwKuNMpWWkiWKR$LgF6QdXC+fnJIsGwuhj96efgM6eAU6ufFe/gqjasJl8=	Selman Bolat	Selman	Bolat	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 11:55:55.899	2026-03-01 15:17:08.396	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
uli74nwj3b1re1gu3896ptxo	halilibrahimyldrm2406@gmail.com	900538892733	pbkdf2_sha256$720000$ZkSFcBk0HEpj9ctEJTjrSd$PTJAscAJnZ2lYxmaHDrlws9IXetk+8uSXI34j+QP2Ww=	Halil İbrahim Yıldırım	Halil İbrahim	Yıldırım	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 12:48:04.664	2026-03-01 15:17:08.411	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
crp8sosx31r1dwjljx1ao54u	emrahadil@hotmail.com	905342987959	pbkdf2_sha256$720000$x2wRw6EoeEFZ9rJVztnFFJ$R73Rfig5jfxbQVZkTG/5r2RtEPvPiPUgtoQKfnN8t2U=	MERVE ÇÖREKÇİOĞLU	MERVE	ÇÖREKÇİOĞLU	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 13:17:49.432	2026-03-01 15:17:08.414	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
k69g6jzv0bprwgdlqpnr789z	feyteka@gmail.com	905513849478	pbkdf2_sha256$720000$A4t1GhydDcPtAY6syfPEpk$qJLEgFZbyhEIt2CQOTfQSyX1HKy2vYR0hhso1Qz14Og=	Ahmet Feytek	Ahmet	Feytek	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 14:35:00.489	2026-03-01 15:17:08.416	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
l324c3suwp69u4v6plla5806	alicimurat1905@gmail.com	905432590546	pbkdf2_sha256$720000$iDHVWWeem9wd61q3tGlfVc$xekUokKtaFpTEFz9peJ14HE3iUOB53N9/mGXlQSIO4c=	Murat Alıcı	Murat	Alıcı	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2025-12-30 15:38:31.34	2026-03-01 15:17:08.424	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zkbwi0llbimg2sh91akkowmt	hatice7106@gmail.com	905534559307	pbkdf2_sha256$720000$XUdm5BquHnu7OzH93xUslJ$wH1SmevSG+ael5wPLDkk56ZuRR/MIaAvDQOUkmEqb1U=	Hatice Ölmez	Hatice	Ölmez	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 15:44:28.518	2026-03-01 15:17:08.427	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tanbjppq54ytovlwx3s201xv	semra.kubat@hotmail.com	905054481963	pbkdf2_sha256$720000$huO24bEZKIEq6aUG6sOwIL$kK1V2PZcwKPUFjsgpLI5p6hbSgf0cNyaXDJqBjk4mKg=	Semra Kubat	Semra	Kubat	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 16:29:32.273	2026-03-01 15:17:08.43	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
p5zae510do1ngjefi56s2t3l	emrtulum@gmail.com	905454639552	pbkdf2_sha256$720000$7Vmtck3Oc9QlwT81BJu1Oo$lymsSs8swDVc2+R6u/l0+g7hCil4xH7BHPWng8ubuuo=	Emre Tulum	Emre	Tulum	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 18:52:50.184	2026-03-01 15:17:08.446	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qzvxmo123npzwqx9qxhd4dlt	imrenarslan49@gmail.com	905535327538	pbkdf2_sha256$720000$JhqnYZiaiHhDnDYs48Es9J$NKaG5SEad76zDj+QwciT6WSFi+YItGEZ/3eDBz4T+hA=	Imren Arslan	Imren	Arslan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 19:11:48.503	2026-03-01 15:17:08.449	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
w0nh4965rg4lgre7bk5ss83j	zekiayik008@gmail.com	905533549181	pbkdf2_sha256$720000$jfVDs5etxVk8q3WH13ESDS$QLDxDjjIl0GhM58bRdOPs4BtHD6wdYnagK2ObItZygU=	Zeki Ayık	Zeki	Ayık	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 19:36:04.553	2026-03-01 15:17:08.453	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
r165dosf7ktlqhx6gr7mde5z	zekeriyakula@gmail.com	905302476557	pbkdf2_sha256$720000$StKvoouamELtgRtvzJkH4f$gBT9EGTJtI0tK65dKHdN4LSpNDm1zz7X6jyPhg5sMpE=	Zekeriya Kula	Zekeriya	Kula	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 20:38:51.384	2026-03-01 15:17:08.458	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tl8cs18pm39z74n8y40g5td9	utkucan.cskn37@gmail.com	905375059637	pbkdf2_sha256$720000$j1CqkvHjV0vTCXfbBonM7M$ZqvxaODeIusnmfr3vA43bWZMUA9/4LRq1iQNhq+gnkM=	Utkucan Coşkun	Utkucan	Coşkun	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-30 21:10:03.597	2026-03-01 15:17:08.461	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cjspfafiomxxd5883uggxg76	omerbinkanat@gmail.com	905322865893	pbkdf2_sha256$720000$UtxG4NFDCtnYmy2Cn6g4oJ$XklHPxdDXqWbrlmkmo6eCwea/LY4SP3gLy5+cnS2tkE=	ÖMER BİNKANAT	ÖMER	BİNKANAT	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 08:31:36.236	2026-03-01 15:17:08.469	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
og4kuqw9zcrr1qc1s2nf5p9n	alidikici147@gmail.com	905448834329	pbkdf2_sha256$720000$gtAvtqmVqpVL1UQhj3LICK$bYUgET7MorxR2BffUS7JI7npT+bj9jKIkckWSKTzoHc=	Ali Dikici	Ali	Dikici	\N	USER	t	t	premium	sozlesmeli	\N	\N	30	t	2026-01-29 12:14:37.133	10	\N	0	2025-12-30 11:56:05.394	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
psqdjdjw49dk5hly4tmcu6xl	afyokhasan@hotmail.com	905325977365	pbkdf2_sha256$720000$fEf4LWKC8reaqXdHCpWjoN$QlYolXyVR5fLv9syv/CO4eM7ev98WNTi5Q3p6mKBdRc=	Hasan Dilmeç	Hasan	Dilmeç	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 10:16:13.96	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
a565oq3avb3pe2u1xuv5ccyd	aykut.atar.ksu.27@gmail.com	905077173547	pbkdf2_sha256$720000$xKMBteskTU6UuFYXB1JEXX$nmPaYy7Dys6vwd77WRbEuyGKhVTDD5lcp8bcqAPFwzg=	AYKUT ATAR	AYKUT	ATAR	\N	USER	f	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-01-03 06:22:28.305	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
aosttfzpmvhad8m603ra9zxb	remiks_2008@hotmail.com	905414066825	pbkdf2_sha256$720000$aiKzhyRkGTo98K58bizVeS$MRGJhemKIP42PAwXY0/bGNpxQRhkSR+bHO8HxtEbecU=	Serap Küllüoğlu	Serap	Küllüoğlu	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 11:57:51.794	2026-03-01 15:17:08.475	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
zharmbqokstf6gy7hb4j0r1z	halilayse1998@gmail.com	905373753225	pbkdf2_sha256$720000$EVmly0L6slTFHk0wRODZm2$MGNE59OPsGvDCqFp/KRle8TWlA2VpSCu8bH47NqLdjI=	Halil Kılıç	Halil	Kılıç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 13:35:11.066	2026-03-01 15:17:08.483	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
chp2zfht5nudqoumseckg5ph	zetemzeynel@gmail.com	905447676699	pbkdf2_sha256$720000$GwRuzltRjUPn31T5UBafK1$pC52v02+7GnpNSqjLK1VmEQxkWfNd6wYkvhKG//QNrs=	Zeynel Çay	Zeynel	Çay	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 15:46:24.597	2026-03-01 15:17:08.489	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
w4p3uo8cp2ms77ugant381hr	seydiercan02@gmail.com	905414954426	pbkdf2_sha256$720000$9qV2MMkpcqdffUw5EwNS1a$yUooj+hA2QIhxo73pqVqVPNDbI2cneg1x54j6XshmV4=	senem taş	senem	taş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 17:20:26.049	2026-03-01 15:17:08.494	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
u2hvi88hcdt0sew8b1a4uxwq	pekdagi@gmail.com	905305437633	pbkdf2_sha256$720000$bYvqVxCEiT3eTiEJJrGXoz$gIMXDct6ZzcmlR4g91bU2KGdA4IVYbb6w0rJVpfpGmI=	Mehmet İsa Pekdağ	Mehmet İsa	Pekdağ	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-31 19:42:18.238	2026-03-01 15:17:08.496	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ji2heyobifv9gxnk1gj7widv	osmandogan0134@hotmail.com	905458683873	pbkdf2_sha256$720000$OvcRAdvQ8IEIDFLqLJzFC2$c42OLZlhHN3vDE874yVgW+hB0dQ1SAW/zpT6Uw/sQHo=	Osman Doğan	Osman	Doğan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-01 13:00:11.459	2026-03-01 15:17:08.499	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
dbv7jl9rkb6ulyq09gu5jrf7	hamdullah.537@gmail.com	905432434808	pbkdf2_sha256$720000$45wV9quRXlgMmZ5GBTtiIY$F9hVu6e6HurpjrbhX3+IYP03+ukBUr/J3QfHwD7fPcU=	Hamdullah Arıs	Hamdullah	Arıs	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-01 17:33:06.72	2026-03-01 15:17:08.501	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
y4k1vmsd8ro6t4hup0s4ojjo	medyaazizegokmen@gmail.com	905421376382	pbkdf2_sha256$720000$F1NMRiPEgF6ejuxDdMkpP4$TcvdUhCZhHatQI3kMg2qIqC31BAxZWLrN3PhihOEQdA=	Azize Gökmen	Azize	Gökmen	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-01 18:38:45.13	2026-03-01 15:17:08.506	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ue8ycr0a3d3j3dzf4lwpw4nd	oguzhandonmez19@gmail.com	905316582719	pbkdf2_sha256$720000$QIxLPY09aYzcbAfnZhWfIk$gy++yM7xF/J3lhjDsXe6o/jDAANvbFOh/74LflmmgLo=	Oğuzhan Dönmez	Oğuzhan	Dönmez	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-01 19:40:37.638	2026-03-01 15:17:08.509	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
q5v8t181sum4pbcdeiuoxuso	gokhanoguz25@gmail.com	905445520308	pbkdf2_sha256$720000$p7LaU6C6DR6ObRJUstewkR$tL32JB2TkmAS8f+Bf8/ufqQvlPtqMIcvIr/pyqgxo8o=	Gökhan Oğuz	Gökhan	Oğuz	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-02 01:41:52.178	2026-03-01 15:17:08.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
uh3hwxabfg97eprzqgdq1wv5	gulper63632121@gmail.com	905428015365	pbkdf2_sha256$720000$kZWxSYsMMGoBIw2XysduhR$EXLkXe5qyme+AkGq83/2JbRU/nHC4OJIsUQbz+4mbXE=	Gülper Karakuş	Gülper	Karakuş	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-02 08:11:05.503	2026-03-01 15:17:08.514	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jy664oqn9h2gyx7jh4exl7xm	tahayigci8@gmail.com	905526100381	pbkdf2_sha256$720000$DoVVzrqvlZxUi19gWnCnG2$eszM3dx5yfzGQeaeHfyOgY2GTSvaba35ndyAWLG097A=	Taha yiğci	Taha	yiğci	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-02 15:13:05.467	2026-03-01 15:17:08.517	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
f8dw8w87hoba7nbsy4dngj60	bayram_903@hotmail.com	905347817432	pbkdf2_sha256$720000$UIG0LTJ7XNCZpolzT9fZAP$NR0kWr/Elk77E80j7ZJALj5hZYgnazo64Id+/Q3JmnY=	Bayram Yiğit	Bayram	Yiğit	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-02 19:01:12.018	2026-03-01 15:17:08.519	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
oia7x8wysyw6cabqz237s26u	tonyali_0061@hotmail.com	905443451024	pbkdf2_sha256$720000$FuwZf7ncrKndqWwaH7xTXh$eG/rMcK3LrBHncYXDPAMVmcZqNRjFPxEg44CJDqVYeQ=	İlker İnce	İlker	İnce	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-03 12:07:11.479	2026-03-01 15:17:08.522	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
eeo6vvq9803humj4scr54grr	aslankarakaya18@gmail.com	905306261781	pbkdf2_sha256$720000$fzTf0b8dsLJR25o97IrHW5$PZbG7/flC/oKHzGEStkTcTbEGunLlK419OwH9ks1bDY=	Aslan Karakaya	Aslan	Karakaya	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-03 13:21:28.467	2026-03-01 15:17:08.524	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
jvbuasx18atgdnw2a9q7cy3c	erdalgulkuwait@gmail.com	905318100254	pbkdf2_sha256$720000$Opr6niXjE5bimOJWCnj3BH$ugn7vfJJ0frDG59wFfsZXmofBVEXY7wiuWCVLXEdjNM=	Erdal Gül	Erdal	Gül	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-03 19:49:22.763	2026-03-01 15:17:08.527	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wmvb3fte14yk3908y9tgrrx2	servety509@gmail.com	905364894512	pbkdf2_sha256$720000$pShFhumjonYobF1vmemzl5$IHAi3vCei46AbOmIOGsjGkn/QfFt/H6rJpnv0UMJ0gs=	\N	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-04 14:08:37.036	2026-03-01 15:17:08.529	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhpi000ijxycctv7fjtn	emre.dogan@kariyer.com	905559990011	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Emre Doğan	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.759	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhms0000jxyc92tvu0u3	ahmet.yilmaz@kariyer.com	905551234567	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Ahmet Yılmaz	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.661	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhpn000jjxycyjbzk2tz	gul.yalcin@kariyer.com	905550001122	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Gül Yalçın	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.763	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
z7rvrbw96mkpp8kg9tkf8sc4	tekinozcan05@gmail.com	905524583387	pbkdf2_sha256$720000$q76bq4X23xMhJg3W3jJpXt$0/lXwgmHS/RslszuBMv2cLV7Lb+n8s6CSG+22tSJRj0=	Tekin Ozcan	Tekin	Ozcan	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-30 13:35:23.409	10	\N	0	2025-12-31 13:22:28.775	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
qwadhgp4v6e77kt49ddxgacq	yakupakbulut84@hotmail.com	905057905431	pbkdf2_sha256$720000$NAjW28hGI3zBoWfEc7nJol$Y7UovQwpko0ZnqbKLQRH4KhWSoZjV+iEBndpyS03fK8=	Yakup Akbulut	Yakup	Akbulut	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-01-08 08:05:21.934	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhnp0005jxycwhg935bq	zeynep.arslan@kariyer.com	905556789012	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Zeynep Arslan	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.693	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbho40008jxyc4zqqtwur	hasan.yildiz@kariyer.com	905559012345	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Hasan Yıldız	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.708	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhn30001jxycz4nisn3w	fatma.demir@kariyer.com	905552345678	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Fatma Demir	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.671	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhnf0003jxycorudnxza	ayse.celik@kariyer.com	905554567890	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Ayşe Çelik	\N	\N	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.683	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhnk0004jxycmivbgags	mustafa.ozturk@kariyer.com	905555678901	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Mustafa Öztürk	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.688	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhnz0007jxyco3lmdzrj	elif.sahin@kariyer.com	905558901234	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Elif Şahin	\N	\N	\N	USER	t	t	basic	sozlesmeli	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.703	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhnt0006jxyc286jq4w3	ali.koc@kariyer.com	905557890123	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Ali Koç	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.698	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vwbpa2eviown0hzni6qsxgpu	Janhakan99@gmail.com	905537041321	pbkdf2_sha256$720000$rqoo75psjw5yZO1Yadwsgn$73BXC96BP/fVcPVoJ4vISqIwhhGJtgkvvndtRWxSDSQ=	Hamza ege	Hamza	ege	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 18:31:57.192	2026-03-01 15:17:09.404	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cd0a3b3c2xn6m8zew0w0i4lx	omer2425k@gmail.com	905336972419	pbkdf2_sha256$720000$LvJ8IgSMVOOvK4OtZSianH$Pxvu4NFbDlaC+GkGH3lZwKGlf/Y2rXGU9GlPvPtWNv4=	Ömer Faruk kılıç	Ömer Faruk	kılıç	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-17 14:50:39.498	2026-03-01 15:17:09.477	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hqodnn2rioxayec5flx0wz7m	gizem57nalca@gmail.com	905317741257	pbkdf2_sha256$720000$xQ71eqiIS2sStJbw7OVRbl$JmUw83HChnKx4epkwT/6rYN7xdoJlxS8qwIZNP9U/nI=	Gizem Nalça	Gizem	Nalça	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-18 15:15:34.089	2026-03-01 15:17:09.483	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
obhwasus861wl6mpwyvubxg1	hassoo.hhd@gmail.com	905414531457	pbkdf2_sha256$720000$FyWH8dFE6pLdRaa6bOFBgf$MJ/buvFODrQB9Ec6pgUF+AU/sPk/PQ86rOYWxtkH2jQ=	Hasan DOĞAN	Hasan	DOĞAN	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-19 00:38:28.943	2026-03-01 15:17:09.486	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
hansbemgsv0pdlsiwbla8mcx	apoarslan34@icloud.com	905444430430	pbkdf2_sha256$720000$0qmKMmxfQo6BpQhVvfIC9P$z2pkV5srgmwI7NJUqeMFIw9Xj6IdH8oQaSm0dfBxdnI=	Abdullah Kaan Arslan	Abdullah Kaan	Arslan	\N	USER	t	t	premium	memur	\N	\N	30	t	2026-08-22 16:08:00	9	\N	0	2025-12-18 14:22:46.981	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
sxg6h99dg7pxprho17qyv402	afidankaplan@gmail.com	905072437458	pbkdf2_sha256$720000$XVdRtCKhotLy7L9QOK2Ey7$BPtbBXavVfj3iRfembQ2rKMZECEQejIstXDdxS5/jIs=	Murat Kaplan	Murat	Kaplan	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:09:11.558	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
j1179b62hzj7ztbkq21zjhw9	tugbadyr4@gmail.com	905075310602	pbkdf2_sha256$720000$thSj5GW1FRbBJwfpm8tIkr$f2ucFLaenYF/yXq53LuovkVWC+iIgESfcYToUjg6reo=	Tuğba Duyar	Tuğba	Duyar	\N	USER	f	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-21 15:16:10.192	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
nw7xlimrv8xiuzezr6xi44y2	ademturan0027@gmail.com	905330555991	pbkdf2_sha256$720000$G9KDn4RoAXXzAsX0DyEF2e$ldWvAog59Z6P45IGiZqk7zXcRfeF8GL8ngR65AmFPA0=	Adem Turan	Adem	Turan	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:23:59.199	2026-03-01 15:17:09.488	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
pmtk5os4xxv0sem7dqssxdux	lamiairmak4747@icloud.com	905510812396	pbkdf2_sha256$720000$Yzq1NYTfMF6fNtQbe5GTzi$sWqZAzWGx5O8JKsne/etpKtiTb5WF+smCDrl8vaqR74=	Lamia Irmak	Lamia	Irmak	\N	USER	f	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:33:50.658	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
bfq90kdx8pr787rp6krdfom4	emre2828.yek@gmail.com	905308782589	pbkdf2_sha256$720000$7ygQcypnvW8QbnWfm2X1lw$ZxKGcwpBWjWV35IvkelfCNQEXB7D6mXrdYmv52hYbUM=	Yunus emre Kartal	Yunus emre	Kartal	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 17:56:15.703	2026-03-01 15:17:09.495	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbhoe000ajxycmfizijxr	ibrahim.gunes@kariyer.com	905551112233	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	İbrahim Güneş	\N	\N	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.718	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
cmm3zbho90009jxyciusogtw3	meryem.aydin@kariyer.com	905550123456	$2b$12$oJfxPhd.7mvv50GDuc7J8OmKfqAsZG9Hv86vZo01B7AEjQANw4kVK	Meryem Aydın	\N	\N	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-26 21:32:22.713	2026-03-07 01:41:42.719	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
m37hzss8umo82m42ovwanyfn	ismailgn1992@gmail.com	905344946569	pbkdf2_sha256$720000$PjI2CFFfchJkSZrltc9KYm$9/eWVs958kk8QNZ4vJhsEjdZCczNBwBQeFkB+gm6CqM=	İsmail Gün	İsmail	Gün	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 18:01:51.112	2026-03-01 15:17:09.497	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
v26fmukykixltlj5sx08bdgl	yildizkazim005@gmail.com	905300374743	pbkdf2_sha256$720000$iOEulhWNaV4zDanfBzoKTV$LDt3LJwoDPL8/oCcgEEIXK95ukKzr9HiU0AkF7RBUw0=	Kazim Yıldız	Kazim	Yıldız	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2025-12-26 22:36:03.22	2026-03-01 15:17:09.5	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
h00nj639i3wdj4l7ct7tdzmh	omersare76@gmail.com	905431711910	pbkdf2_sha256$720000$u8hyqZzMPJlnJ7W6DAX9Mr$MADAUxbfhcXt9iMUxfZ69NYjgARHwFjtiA1It7K3wRw=	ömer şare	ömer	şare	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-28 17:04:45.69	2026-03-01 15:17:09.502	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
t48q18l13dt49y0kkz2qaidk	s.gokdemir@hotmail.com.tr	905061016851	pbkdf2_sha256$720000$N36JykRmkXprer2edD2HJZ$oDzWGyWPwJSMR+W2nUX1FP7w6Gqt9MUhyv8bc+KPtw0=	Semih Gökdemir	Semih	Gökdemir	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 09:18:52.338	2026-03-01 15:17:09.504	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
otkiwwa5m6sfcvqzufjkcedt	htcozdemr99@gmail.com	905419511311	pbkdf2_sha256$720000$BjqLhYvR7POz08zzJ71UB3$fp0/PxVVdppxO6m+WD6FG+bzP/vuRqYQhbnCW5BzSC0=	Htc Ozdmr	Htc	Ozdmr	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-03 20:39:20.604	2026-03-01 15:17:09.508	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ozxbvo1moy53znk65ul71x7r	even.kobi@hotmail.com	905079644315	pbkdf2_sha256$720000$3j5f0muqW53uFxfWhmn78S$kQ1Odn1SKCmrhIftJTFGWmiQ3QMFZNwAOgTs4rI5194=	Berkay Yurgül	Berkay	Yurgül	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-05 23:10:25.556	2026-03-01 15:17:09.51	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
i4jnifa03i6p24m058meo4tv	memetkarpuz@gmail.com	905453967499	pbkdf2_sha256$720000$CU0qA8VdbIGIh6gPKty7U1$QQsRToKUXZuPEPWgY5LBdWqoZYoH18DCYe9tDPvf8+I=	Mehmet Karpuz	Mehmet	Karpuz	\N	USER	t	t	basic	memur	\N	\N	30	f	\N	0	\N	0	2026-02-10 17:28:11.337	2026-03-01 15:17:09.514	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
j8i8la9dpcv73tirzuyagzu4	ilgin339@gmail.com	905436474960	pbkdf2_sha256$720000$8NAFKs5GfoX2ztMa0ROX8w$ytx88Aze01oYmqy5utGLMyAjg3M45ftmU+CZ0ARHP3I=	ılgın yeğin	ılgın	yeğin	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2026-02-11 15:57:22.611	2026-03-01 15:17:09.517	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
ygivrx7gf5hz55x7bwwqetqx	mustafaissi6868@gmail.com	905318276891	pbkdf2_sha256$720000$9J34KdZ7jYRIfOm6H1YkzH$YxTzNcXKaE/EDBK3M1TpNWi6zJJJJsRB1Tyf3rPCbLM=	Mustafa Issı	Mustafa	Issı	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-27 03:29:59.995	2026-03-01 15:17:09.523	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
h2cl3mdfkabn2oibgsodmzxw	sametaslantepe44@gmail.com	905466766580	pbkdf2_sha256$720000$frlFiQ7ffufAzXUpDHEpYM$axFX1z4ImdiU9Ao05wjBYSnUnubi8+FB3QDKDw6CTaY=	Samet Aslantepe	Samet	Aslantepe	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:26:01.92	2026-03-01 15:17:09.527	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
vwqnspsqag3wrovr4gm1i2fs	osmansaglam059@gmail.com	905547544749	pbkdf2_sha256$720000$MwXxB2JzNuuZIFTdPyfLWG$xnegJ+GSgwH/bVKh3Xxl0UsvG9cStGix3NFxHVojkAE=	OSMAN SAGLAM	OSMAN	SAGLAM	\N	USER	t	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:26:34.997	2026-03-01 15:17:09.934	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tbubj1wpzxmqkpsac70srkfa	tufantuba57@gmail.com	905533217857	pbkdf2_sha256$720000$DwKVndjx8acxniachX2IBI$Tz4KkL8sxoGiEE9Ixr6iI+GjOZxfEcdJtVaqZx3MYf0=	Tuğba Şimşek	Tuğba	Şimşek	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-03-17 19:21:00	10	\N	0	2026-02-14 17:17:19.47	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
wcwj7vvhmtr2jrdrtua9bv2j	isakirstioglu68@gmail.com	905324998737	pbkdf2_sha256$720000$OMsNwI8coW2doZq58x0Lut$sbbvuNTzgNKM1eEqMgM7wGiVIdAMpN4xQSOYBQeSq8g=	İsa KIRIŞTIOĞLU	İsa	KIRIŞTIOĞLU	\N	USER	f	t	basic	isci	\N	\N	30	f	\N	0	\N	0	2025-12-29 08:24:58.858	2026-03-01 15:14:52.511	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
tsjxe7ha3weg8ozd9sly8o6x	tabakleventirfan79@gmail.com	905435249121	pbkdf2_sha256$720000$fkU3MjzxjEBHO1Iqe8zenC$26m/7FaTC+7zhaMJU2dRi94PGt0NrPCaPutOQMgfuNo=	levent irfan tabak	levent irfan	tabak	\N	USER	t	t	premium	isci	\N	\N	30	t	2026-01-29 08:47:32.072	10	\N	0	2025-12-29 16:08:16.535	2026-03-01 15:21:25.789	\N	\N	0	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	f	\N	f	\N	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: WhatsAppLog; Type: TABLE DATA; Schema: public; Owner: kamulog_panel
--

COPY public."WhatsAppLog" (id, "phoneNumber", message, "messageType", status, "userId", "userEmail", "errorMessage", "createdAt") FROM stdin;
cmm5g2kta0000jxfkanz7qhqx	905016547534	580335	OTP	SENT	\N	\N	\N	2026-02-27 22:09:06.527
cmm5g5p0y0001jxfko957qpdw	905016547553	251111	OTP	VERIFIED	\N	\N	\N	2026-02-27 22:11:31.954
cmm5ihl2j0000jxwm0nnr6b9v	905392647655	254953	OTP	SENT	\N	\N	\N	2026-02-27 23:16:45.932
cmmc0six30000jx6wheksgc34	+905392647655	809372	OTP	VERIFIED	\N	\N	\N	2026-03-04 12:35:46.502
cmmc18j0g0000jx1o99ws85ir	+905392647655	244183	OTP	VERIFIED	\N	\N	\N	2026-03-04 12:48:13.121
cmmc2sd6j0000jx7tbb1mowia	+905392647655	828140	OTP	SENT	\N	\N	\N	2026-03-04 13:31:38.299
cmmc3a6vc0001jx7tgwnw90yz	+905392647655	763931	OTP	VERIFIED	\N	\N	\N	2026-03-04 13:45:29.891
cmmc3x8l50000jxrsojvw7v59	sahinsedat778@gmail.com	799289	EMAIL_CHANGE_OTP	SENT	\N	\N	\N	2026-03-04 14:03:25.241
cmmc3xnng0001jxrsxaj3qqyb	+905392647655	666594	OTP	VERIFIED	\N	\N	\N	2026-03-04 14:03:44.761
cmmc4jir20002jxrszt1asbga	sahinsedat778@gmail.com	677101	EMAIL_CHANGE_OTP	SENT	\N	\N	\N	2026-03-04 14:20:44.846
cmmc4k0h40003jxrsatkn1bet	sahinsedat778@gmail.com	555818	EMAIL_CHANGE_OTP	SENT	\N	\N	\N	2026-03-04 14:21:07.817
cmmc5wp1w0004jxrsi0m6813o	905557700579	759488	PHONE_CHANGE_OTP	SENT	\N	\N	\N	2026-03-04 14:58:59.157
cmmc733540005jxrsqxllq6z6	+905392647655	804717	OTP	VERIFIED	\N	\N	\N	2026-03-04 15:31:56.938
cmmc76h5p0006jxrs18yrog6c	sahinsedat778@gmail.com	170643	EMAIL_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-04 15:34:35.101
cmmc7b0fu0007jxrsir2gsdic	sahinsedat778@gmail.com	738209	EMAIL_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-04 15:38:06.715
cmmclbnua0000jxf0hlwmszzt	+905392647655	667210	OTP	SENT	\N	\N	\N	2026-03-04 22:10:31.665
cmmclbt580001jxf0u7361j76	+905392647655	699981	OTP	VERIFIED	\N	\N	\N	2026-03-04 22:10:38.541
cmmcmwgv60004jxsug5zlfxhf	+905016547534	229292	OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 22:54:42.009
cmmcmxzv10000jxt64oubrkos	+905016547534	698222	OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 22:55:53.293
cmmcmz1nv0001jxt6mfbk6xcl	+905392647655	429976	OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 22:56:42.283
cmmcnd7b40000jxydsikngfxn	+905016547534	937929	OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:07:42.783
cmmcnw7kx0000jx2zvp6emopi	sdat.sahin@gmail.com	457979	EMAIL_OTP	VERIFIED	\N	\N	\N	2026-03-04 23:22:29.6
cmmcnx9a50002jx2zavaifumu	905016547534	739358	PHONE_CHANGE_OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:23:18.462
cmmcnyuu00003jx2zpjjlyr9r	sedat.shin34@gmail.com	746481	EMAIL_CHANGE_OTP	SENT	\N	\N	\N	2026-03-04 23:24:33.049
cmmco22ko0004jx2zaz2dv8vo	Sedat.shin75@gmail.com	280062	EMAIL_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-04 23:27:03.049
cmmco6f2u0005jx2zubly9475	905016547534	403013	PHONE_CHANGE_OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:30:25.878
cmmco8t540006jx2ze6hy5gi0	905016547534	662965	PHONE_CHANGE_OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:32:17.417
cmmcoatcs0007jx2zfsrxwwwo	905016547534	452134	PHONE_CHANGE_OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:33:51.004
cmmcobfnm0008jx2zyrh9hx1j	905016547534	948523	PHONE_CHANGE_OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:34:19.907
cmmcoj85u000djx2zlzgzm6v3	905016547534	135386	PHONE_CHANGE_OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:40:23.442
cmmcomoix000ejx2z5fu4706j	905016547534	815156	PHONE_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-04 23:43:04.617
cmmcoo6tx000fjx2z06mnwdqs	+905392647655	714064	OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:44:14.997
cmmcoow04000gjx2zr7gfm1cm	sahinsedat778@gmail.com	814585	EMAIL_OTP	VERIFIED	\N	\N	\N	2026-03-04 23:44:47.62
cmmcouydr000jjx2zwpyyeoko	+905016547534	544734	OTP	FAILED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-04 23:49:30.639
cmmcoxy19000kjx2zbd16iiti	sedat.shin75@gmail.com	740010	EMAIL_OTP	VERIFIED	\N	\N	\N	2026-03-04 23:51:49.865
cmmcpj56o0004jx2bsabtfbl2	+905392647655	257633	OTP	VERIFIED	\N	\N	Bot bağlı değil — kod ekranda gösterildi.	2026-03-05 00:08:19.201
cmmd7kfz40009jx2boc6mp27i	905392647655	293252	OTP	SENT	\N	\N	\N	2026-03-05 08:33:12.898
cmmd7lytp000ajx2bp1nvxzbm	905392647655	416332	OTP	SENT	\N	\N	\N	2026-03-05 08:34:24.014
cmmd7mek3000bjx2b5xk6xl8v	905392647655	702537	OTP	SENT	\N	\N	\N	2026-03-05 08:34:44.404
cmmd8cq820000jx484dh2ksld	sahinsedat778@gmail.com	938916	EMAIL_OTP	VERIFIED	\N	\N	\N	2026-03-05 08:55:12.575
cmmd8k4g80001jx48d7hyjmlf	905392647655	166296	OTP	SENT	\N	\N	\N	2026-03-05 09:00:57.562
cmmd8lht00002jx48j3fbusls	905392647655	932511	OTP	SENT	\N	\N	\N	2026-03-05 09:02:01.568
cmmda7ro80003jx48e4zf9zgb	905392647655	863532	OTP	SENT	\N	\N	\N	2026-03-05 09:47:20.377
cmmda8npp0004jx48se1wma7x	905392647655	653856	OTP	SENT	\N	\N	\N	2026-03-05 09:48:01.934
cmmdadg3t0005jx48hxz5xjdu	905392647655	244094	OTP	SENT	\N	\N	\N	2026-03-05 09:51:45.352
cmmdagq5m0006jx48b4gkssx1	905392647655	934171	OTP	VERIFIED	\N	\N	\N	2026-03-05 09:54:18.314
cmmdaleyk0008jx48el82jxhe	905392647655	967024	OTP	VERIFIED	\N	\N	\N	2026-03-05 09:57:57.116
cmmdalzsx0009jx48n8cxbhz3	905016547534	592914	OTP	VERIFIED	\N	\N	\N	2026-03-05 09:58:24.129
cmmdarum1000ajx48sywcpv98	905392647655	984235	OTP	VERIFIED	\N	\N	\N	2026-03-05 10:02:57.337
cmmdg9nhu000bjx484ol0thjg	905392647655	593480	OTP	VERIFIED	\N	\N	\N	2026-03-05 12:36:45.879
cmmdgjuag0000jxkho2s8vp8b	905392647655	580993	OTP	SENT	\N	\N	\N	2026-03-05 12:44:41.366
cmmdgkyhx0001jxkhoq81f9u1	905392647655	820647	OTP	VERIFIED	\N	\N	\N	2026-03-05 12:45:33.476
cmmdgqsc50002jxkh7adte4ss	905392647655	326747	OTP	VERIFIED	\N	\N	\N	2026-03-05 12:50:05.385
cmmdi3vxw0000jx04ve4gtckp	905392647655	809204	OTP	VERIFIED	\N	\N	\N	2026-03-05 13:28:16.243
cmmdi7ra40001jx04egmg8qn3	905392647655	902024	OTP	SENT	\N	\N	\N	2026-03-05 13:31:16.825
cmmdi8psk0002jx04ry3rlhk0	905392647655	727027	OTP	VERIFIED	\N	\N	\N	2026-03-05 13:32:01.55
cmmdmea910003jx04gbgn7e2z	905392647655	357936	OTP	VERIFIED	\N	\N	\N	2026-03-05 15:28:19.779
cmmdw1bec0004jx04yvuvvmly	905301902074	703469	OTP	VERIFIED	\N	\N	\N	2026-03-05 19:58:10.862
cmme71pl80002jxjw7ozrysvv	905392647655	633191	OTP	VERIFIED	\N	\N	\N	2026-03-06 01:06:25.085
cmme86uvw0003jxjweb1jsc45	905392647655	412200	OTP	VERIFIED	\N	\N	\N	2026-03-06 01:38:24.824
cmmeesaxi000sjxlhzm7fv6w4	sahinsedat778@gmail.com	424874	EMAIL_OTP	VERIFIED	\N	\N	\N	2026-03-06 04:43:02.75
cmmeetme0000tjxlhwl4mjzqw	905392647655	404412	OTP	VERIFIED	\N	\N	\N	2026-03-06 04:44:04.631
cmmetwc39001ajxlhojpzhsaq	sdat.sahin@gmail.com	135243	EMAIL_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-06 11:46:05.493
cmmetxdw8001bjxlhvzq2m590	905392647655	151239	PHONE_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-06 11:46:54.489
cmmeu8ry4001cjxlhvqxaet59	905392647655	709048	OTP	VERIFIED	\N	\N	\N	2026-03-06 11:55:45.889
cmmeua88t001djxlhz78qfmc5	905392647655	190343	OTP	VERIFIED	\N	\N	\N	2026-03-06 11:56:53.692
cmmf64elq0000jxts9yye9m0x	905001234567	635644	OTP	SENT	\N	\N	\N	2026-03-06 17:28:17.39
cmmfeu6180000jxaw8qpvfq3j	905001112233	558037	OTP	SENT	\N	\N	\N	2026-03-06 21:32:16.264
cmmfgrmci0000jxqv2gucpkoo	905392647655	680936	OTP	VERIFIED	\N	\N	\N	2026-03-06 22:26:16.673
cmmfgu4pz0002jxqvaybjqs7x	sahinnsedat778@gmail.com	187543	EMAIL_CHANGE_OTP	SENT	\N	\N	\N	2026-03-06 22:28:13.799
cmmfgvi7y0003jxqvlmqrucie	sahinsedat778@gmail.com	276152	EMAIL_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-06 22:29:17.951
cmmfhqofb0002jx1oathczt0l	905392647655	662642	OTP	VERIFIED	\N	\N	\N	2026-03-06 22:53:32.323
cmmfi9si40005jx1oj93lo866	cmmfgrxkr0001jxqvcgjhrpmj	İlan kaldırıldı — "haber" (İstanbul→Adana). Gerekçe: İhtiyacım kalmadı	LISTING_REMOVAL_LOG	COMPLETED	\N	\N	\N	2026-03-06 23:08:24.077
cmmfmatyx0000jxkryvo4j71t	905392647655	377849	OTP	VERIFIED	\N	\N	\N	2026-03-07 01:01:11.097
cmmfxfml60000jxy203eyked0	cmmfgrxkr0001jxqvcgjhrpmj	İlan kaldırıldı — "Memurum ben" (İstanbul→Aksaray). Gerekçe: İhtiyacım kalmadı	LISTING_REMOVAL_LOG	COMPLETED	\N	\N	\N	2026-03-07 06:12:50.586
cmmfyed5u0002jxql0z686sua	cmmfgrxkr0001jxqvcgjhrpmj	İlan kaldırıldı — "nsnsbs" (İstanbul→Adıyaman). Gerekçe: İhtiyacım kalmadı	LISTING_REMOVAL_LOG	COMPLETED	\N	\N	\N	2026-03-07 06:39:51.33
cmmfyk7bz0005jxqlv31bv7hg	cmmfgrxkr0001jxqvcgjhrpmj	İlan kaldırıldı — "Deneme 1-2-3-4-5" (İstanbul→Ardahan). Gerekçe: Kullanıcı tarafından silindi	LISTING_REMOVAL_LOG	COMPLETED	\N	\N	\N	2026-03-07 06:44:23.712
cmmg4laq00000jx8vfxrc6le0	905016547534	516404	OTP	VERIFIED	\N	\N	\N	2026-03-07 09:33:12.455
cmmg4mjt70002jx8vhd3tjwi6	sdat.sahin@gmail.com	461363	EMAIL_CHANGE_OTP	VERIFIED	\N	\N	\N	2026-03-07 09:34:10.891
\.


--
-- Name: AdminLog AdminLog_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."AdminLog"
    ADD CONSTRAINT "AdminLog_pkey" PRIMARY KEY (id);


--
-- Name: BecayisListing BecayisListing_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisListing"
    ADD CONSTRAINT "BecayisListing_pkey" PRIMARY KEY (id);


--
-- Name: BecayisMessage BecayisMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisMessage"
    ADD CONSTRAINT "BecayisMessage_pkey" PRIMARY KEY (id);


--
-- Name: CVAnalysis CVAnalysis_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CVAnalysis"
    ADD CONSTRAINT "CVAnalysis_pkey" PRIMARY KEY (id);


--
-- Name: CV CV_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CV"
    ADD CONSTRAINT "CV_pkey" PRIMARY KEY (id);


--
-- Name: ChatSession ChatSession_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ChatSession"
    ADD CONSTRAINT "ChatSession_pkey" PRIMARY KEY (id);


--
-- Name: ConsultantApplication ConsultantApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ConsultantApplication"
    ADD CONSTRAINT "ConsultantApplication_pkey" PRIMARY KEY (id);


--
-- Name: ConsultantPayout ConsultantPayout_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ConsultantPayout"
    ADD CONSTRAINT "ConsultantPayout_pkey" PRIMARY KEY (id);


--
-- Name: Consultant Consultant_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Consultant"
    ADD CONSTRAINT "Consultant_pkey" PRIMARY KEY (id);


--
-- Name: ConsultationRequest ConsultationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ConsultationRequest"
    ADD CONSTRAINT "ConsultationRequest_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: CookieConsent CookieConsent_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CookieConsent"
    ADD CONSTRAINT "CookieConsent_pkey" PRIMARY KEY (id);


--
-- Name: Coupon Coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Coupon"
    ADD CONSTRAINT "Coupon_pkey" PRIMARY KEY (id);


--
-- Name: FavoriteAd FavoriteAd_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."FavoriteAd"
    ADD CONSTRAINT "FavoriteAd_pkey" PRIMARY KEY (id);


--
-- Name: Institution Institution_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Institution"
    ADD CONSTRAINT "Institution_pkey" PRIMARY KEY (id);


--
-- Name: JobListing JobListing_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."JobListing"
    ADD CONSTRAINT "JobListing_pkey" PRIMARY KEY (id);


--
-- Name: KariyerChatMessage KariyerChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerChatMessage"
    ADD CONSTRAINT "KariyerChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: KariyerChatRoom KariyerChatRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerChatRoom"
    ADD CONSTRAINT "KariyerChatRoom_pkey" PRIMARY KEY (id);


--
-- Name: KariyerConsultantRating KariyerConsultantRating_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerConsultantRating"
    ADD CONSTRAINT "KariyerConsultantRating_pkey" PRIMARY KEY (id);


--
-- Name: KariyerConsultant KariyerConsultant_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerConsultant"
    ADD CONSTRAINT "KariyerConsultant_pkey" PRIMARY KEY (id);


--
-- Name: KariyerSubscription KariyerSubscription_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerSubscription"
    ADD CONSTRAINT "KariyerSubscription_pkey" PRIMARY KEY (id);


--
-- Name: MediaCategory MediaCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."MediaCategory"
    ADD CONSTRAINT "MediaCategory_pkey" PRIMARY KEY (id);


--
-- Name: Media Media_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Media"
    ADD CONSTRAINT "Media_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: News News_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."News"
    ADD CONSTRAINT "News_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Report Report_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_pkey" PRIMARY KEY (id);


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY (id);


--
-- Name: SalesRecord SalesRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."SalesRecord"
    ADD CONSTRAINT "SalesRecord_pkey" PRIMARY KEY (id);


--
-- Name: ServicePackage ServicePackage_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ServicePackage"
    ADD CONSTRAINT "ServicePackage_pkey" PRIMARY KEY (id);


--
-- Name: SiteSettings SiteSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."SiteSettings"
    ADD CONSTRAINT "SiteSettings_pkey" PRIMARY KEY (id);


--
-- Name: SubscriptionPlan SubscriptionPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."SubscriptionPlan"
    ADD CONSTRAINT "SubscriptionPlan_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: SystemSetting SystemSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_pkey" PRIMARY KEY (id);


--
-- Name: TISDocument TISDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."TISDocument"
    ADD CONSTRAINT "TISDocument_pkey" PRIMARY KEY (id);


--
-- Name: TISFile TISFile_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."TISFile"
    ADD CONSTRAINT "TISFile_pkey" PRIMARY KEY (id);


--
-- Name: UsageRecord UsageRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."UsageRecord"
    ADD CONSTRAINT "UsageRecord_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WhatsAppLog WhatsAppLog_pkey; Type: CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."WhatsAppLog"
    ADD CONSTRAINT "WhatsAppLog_pkey" PRIMARY KEY (id);


--
-- Name: AdminLog_action_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "AdminLog_action_idx" ON public."AdminLog" USING btree (action);


--
-- Name: AdminLog_adminId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "AdminLog_adminId_idx" ON public."AdminLog" USING btree ("adminId");


--
-- Name: AdminLog_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "AdminLog_createdAt_idx" ON public."AdminLog" USING btree ("createdAt");


--
-- Name: AdminLog_targetType_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "AdminLog_targetType_idx" ON public."AdminLog" USING btree ("targetType");


--
-- Name: BecayisListing_adNumber_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "BecayisListing_adNumber_key" ON public."BecayisListing" USING btree ("adNumber");


--
-- Name: BecayisListing_slug_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "BecayisListing_slug_key" ON public."BecayisListing" USING btree (slug);


--
-- Name: BecayisMessage_listingId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "BecayisMessage_listingId_idx" ON public."BecayisMessage" USING btree ("listingId");


--
-- Name: BecayisMessage_receiverId_isRead_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "BecayisMessage_receiverId_isRead_idx" ON public."BecayisMessage" USING btree ("receiverId", "isRead");


--
-- Name: BecayisMessage_receiverId_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "BecayisMessage_receiverId_status_idx" ON public."BecayisMessage" USING btree ("receiverId", status);


--
-- Name: BecayisMessage_senderId_receiverId_listingId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "BecayisMessage_senderId_receiverId_listingId_idx" ON public."BecayisMessage" USING btree ("senderId", "receiverId", "listingId");


--
-- Name: ConsultantApplication_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "ConsultantApplication_createdAt_idx" ON public."ConsultantApplication" USING btree ("createdAt");


--
-- Name: ConsultantApplication_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "ConsultantApplication_status_idx" ON public."ConsultantApplication" USING btree (status);


--
-- Name: ConsultantPayout_consultantId_period_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "ConsultantPayout_consultantId_period_key" ON public."ConsultantPayout" USING btree ("consultantId", period);


--
-- Name: ConsultantPayout_period_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "ConsultantPayout_period_idx" ON public."ConsultantPayout" USING btree (period);


--
-- Name: ConsultantPayout_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "ConsultantPayout_status_idx" ON public."ConsultantPayout" USING btree (status);


--
-- Name: Consultant_userId_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "Consultant_userId_key" ON public."Consultant" USING btree ("userId");


--
-- Name: CookieConsent_acceptedAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "CookieConsent_acceptedAt_idx" ON public."CookieConsent" USING btree ("acceptedAt");


--
-- Name: CookieConsent_ipAddress_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "CookieConsent_ipAddress_idx" ON public."CookieConsent" USING btree ("ipAddress");


--
-- Name: CookieConsent_userId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "CookieConsent_userId_idx" ON public."CookieConsent" USING btree ("userId");


--
-- Name: Coupon_code_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Coupon_code_idx" ON public."Coupon" USING btree (code);


--
-- Name: Coupon_code_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "Coupon_code_key" ON public."Coupon" USING btree (code);


--
-- Name: Coupon_isActive_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Coupon_isActive_idx" ON public."Coupon" USING btree ("isActive");


--
-- Name: FavoriteAd_listingId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "FavoriteAd_listingId_idx" ON public."FavoriteAd" USING btree ("listingId");


--
-- Name: FavoriteAd_userId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "FavoriteAd_userId_idx" ON public."FavoriteAd" USING btree ("userId");


--
-- Name: FavoriteAd_userId_listingId_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "FavoriteAd_userId_listingId_key" ON public."FavoriteAd" USING btree ("userId", "listingId");


--
-- Name: Institution_name_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "Institution_name_key" ON public."Institution" USING btree (name);


--
-- Name: JobListing_code_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "JobListing_code_idx" ON public."JobListing" USING btree (code);


--
-- Name: JobListing_code_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "JobListing_code_key" ON public."JobListing" USING btree (code);


--
-- Name: KariyerChatMessage_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerChatMessage_createdAt_idx" ON public."KariyerChatMessage" USING btree ("createdAt");


--
-- Name: KariyerChatMessage_roomId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerChatMessage_roomId_idx" ON public."KariyerChatMessage" USING btree ("roomId");


--
-- Name: KariyerChatRoom_consultantId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerChatRoom_consultantId_idx" ON public."KariyerChatRoom" USING btree ("consultantId");


--
-- Name: KariyerChatRoom_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerChatRoom_status_idx" ON public."KariyerChatRoom" USING btree (status);


--
-- Name: KariyerChatRoom_userId_consultantId_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "KariyerChatRoom_userId_consultantId_key" ON public."KariyerChatRoom" USING btree ("userId", "consultantId");


--
-- Name: KariyerChatRoom_userId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerChatRoom_userId_idx" ON public."KariyerChatRoom" USING btree ("userId");


--
-- Name: KariyerConsultantRating_consultantId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerConsultantRating_consultantId_idx" ON public."KariyerConsultantRating" USING btree ("consultantId");


--
-- Name: KariyerConsultantRating_roomId_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "KariyerConsultantRating_roomId_key" ON public."KariyerConsultantRating" USING btree ("roomId");


--
-- Name: KariyerConsultantRating_userId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "KariyerConsultantRating_userId_idx" ON public."KariyerConsultantRating" USING btree ("userId");


--
-- Name: KariyerConsultant_userId_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "KariyerConsultant_userId_key" ON public."KariyerConsultant" USING btree ("userId");


--
-- Name: KariyerSubscription_orderCode_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "KariyerSubscription_orderCode_key" ON public."KariyerSubscription" USING btree ("orderCode");


--
-- Name: KariyerSubscription_userId_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "KariyerSubscription_userId_key" ON public."KariyerSubscription" USING btree ("userId");


--
-- Name: MediaCategory_slug_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "MediaCategory_slug_key" ON public."MediaCategory" USING btree (slug);


--
-- Name: Media_categoryId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Media_categoryId_idx" ON public."Media" USING btree ("categoryId");


--
-- Name: Media_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Media_createdAt_idx" ON public."Media" USING btree ("createdAt");


--
-- Name: Media_isActive_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Media_isActive_idx" ON public."Media" USING btree ("isActive");


--
-- Name: Message_conversationId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Message_conversationId_idx" ON public."Message" USING btree ("conversationId");


--
-- Name: Message_senderId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Message_senderId_idx" ON public."Message" USING btree ("senderId");


--
-- Name: Message_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Message_status_idx" ON public."Message" USING btree (status);


--
-- Name: News_category_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "News_category_idx" ON public."News" USING btree (category);


--
-- Name: News_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "News_createdAt_idx" ON public."News" USING btree ("createdAt");


--
-- Name: News_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "News_status_idx" ON public."News" USING btree (status);


--
-- Name: Notification_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Notification_userId_createdAt_idx" ON public."Notification" USING btree ("userId", "createdAt");


--
-- Name: Notification_userId_isRead_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Notification_userId_isRead_idx" ON public."Notification" USING btree ("userId", "isRead");


--
-- Name: Report_reportedAdId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Report_reportedAdId_idx" ON public."Report" USING btree ("reportedAdId");


--
-- Name: Report_reporterId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Report_reporterId_idx" ON public."Report" USING btree ("reporterId");


--
-- Name: Report_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "Report_status_idx" ON public."Report" USING btree (status);


--
-- Name: SalesRecord_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "SalesRecord_createdAt_idx" ON public."SalesRecord" USING btree ("createdAt");


--
-- Name: SalesRecord_orderNumber_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "SalesRecord_orderNumber_idx" ON public."SalesRecord" USING btree ("orderNumber");


--
-- Name: SalesRecord_orderNumber_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "SalesRecord_orderNumber_key" ON public."SalesRecord" USING btree ("orderNumber");


--
-- Name: SalesRecord_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "SalesRecord_status_idx" ON public."SalesRecord" USING btree (status);


--
-- Name: SalesRecord_userId_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "SalesRecord_userId_idx" ON public."SalesRecord" USING btree ("userId");


--
-- Name: SiteSettings_key_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "SiteSettings_key_key" ON public."SiteSettings" USING btree (key);


--
-- Name: SystemSetting_key_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "SystemSetting_key_key" ON public."SystemSetting" USING btree (key);


--
-- Name: TISDocument_institution_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "TISDocument_institution_idx" ON public."TISDocument" USING btree (institution);


--
-- Name: TISDocument_role_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "TISDocument_role_idx" ON public."TISDocument" USING btree (role);


--
-- Name: TISFile_role_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "TISFile_role_idx" ON public."TISFile" USING btree (role);


--
-- Name: UsageRecord_userId_type_month_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "UsageRecord_userId_type_month_key" ON public."UsageRecord" USING btree ("userId", type, month);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phoneNumber_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "User_phoneNumber_key" ON public."User" USING btree ("phoneNumber");


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: WhatsAppLog_createdAt_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "WhatsAppLog_createdAt_idx" ON public."WhatsAppLog" USING btree ("createdAt");


--
-- Name: WhatsAppLog_messageType_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "WhatsAppLog_messageType_idx" ON public."WhatsAppLog" USING btree ("messageType");


--
-- Name: WhatsAppLog_phoneNumber_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "WhatsAppLog_phoneNumber_idx" ON public."WhatsAppLog" USING btree ("phoneNumber");


--
-- Name: WhatsAppLog_status_idx; Type: INDEX; Schema: public; Owner: kamulog_panel
--

CREATE INDEX "WhatsAppLog_status_idx" ON public."WhatsAppLog" USING btree (status);


--
-- Name: AdminLog AdminLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."AdminLog"
    ADD CONSTRAINT "AdminLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BecayisListing BecayisListing_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisListing"
    ADD CONSTRAINT "BecayisListing_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BecayisListing BecayisListing_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisListing"
    ADD CONSTRAINT "BecayisListing_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BecayisListing BecayisListing_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisListing"
    ADD CONSTRAINT "BecayisListing_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BecayisMessage BecayisMessage_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisMessage"
    ADD CONSTRAINT "BecayisMessage_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."BecayisListing"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BecayisMessage BecayisMessage_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisMessage"
    ADD CONSTRAINT "BecayisMessage_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BecayisMessage BecayisMessage_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."BecayisMessage"
    ADD CONSTRAINT "BecayisMessage_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CVAnalysis CVAnalysis_cvId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CVAnalysis"
    ADD CONSTRAINT "CVAnalysis_cvId_fkey" FOREIGN KEY ("cvId") REFERENCES public."CV"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CVAnalysis CVAnalysis_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CVAnalysis"
    ADD CONSTRAINT "CVAnalysis_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."JobListing"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CVAnalysis CVAnalysis_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CVAnalysis"
    ADD CONSTRAINT "CVAnalysis_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CV CV_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."CV"
    ADD CONSTRAINT "CV_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatSession ChatSession_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ChatSession"
    ADD CONSTRAINT "ChatSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConsultantPayout ConsultantPayout_consultantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ConsultantPayout"
    ADD CONSTRAINT "ConsultantPayout_consultantId_fkey" FOREIGN KEY ("consultantId") REFERENCES public."Consultant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConsultationRequest ConsultationRequest_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ConsultationRequest"
    ADD CONSTRAINT "ConsultationRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Conversation Conversation_consultantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_consultantId_fkey" FOREIGN KEY ("consultantId") REFERENCES public."Consultant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Conversation Conversation_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FavoriteAd FavoriteAd_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."FavoriteAd"
    ADD CONSTRAINT "FavoriteAd_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."BecayisListing"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FavoriteAd FavoriteAd_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."FavoriteAd"
    ADD CONSTRAINT "FavoriteAd_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KariyerChatMessage KariyerChatMessage_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerChatMessage"
    ADD CONSTRAINT "KariyerChatMessage_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."KariyerChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KariyerChatRoom KariyerChatRoom_consultantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerChatRoom"
    ADD CONSTRAINT "KariyerChatRoom_consultantId_fkey" FOREIGN KEY ("consultantId") REFERENCES public."KariyerConsultant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KariyerChatRoom KariyerChatRoom_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerChatRoom"
    ADD CONSTRAINT "KariyerChatRoom_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KariyerConsultantRating KariyerConsultantRating_consultantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerConsultantRating"
    ADD CONSTRAINT "KariyerConsultantRating_consultantId_fkey" FOREIGN KEY ("consultantId") REFERENCES public."KariyerConsultant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KariyerConsultantRating KariyerConsultantRating_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerConsultantRating"
    ADD CONSTRAINT "KariyerConsultantRating_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."KariyerChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KariyerSubscription KariyerSubscription_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."KariyerSubscription"
    ADD CONSTRAINT "KariyerSubscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Media Media_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Media"
    ADD CONSTRAINT "Media_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."MediaCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Report Report_reportedAdId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_reportedAdId_fkey" FOREIGN KEY ("reportedAdId") REFERENCES public."BecayisListing"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_reporterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_reporterId_fkey" FOREIGN KEY ("reporterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_consultantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_consultantId_fkey" FOREIGN KEY ("consultantId") REFERENCES public."Consultant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SalesRecord SalesRecord_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."SalesRecord"
    ADD CONSTRAINT "SalesRecord_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePackage ServicePackage_consultantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."ServicePackage"
    ADD CONSTRAINT "ServicePackage_consultantId_fkey" FOREIGN KEY ("consultantId") REFERENCES public."Consultant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."SubscriptionPlan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UsageRecord UsageRecord_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kamulog_panel
--

ALTER TABLE ONLY public."UsageRecord"
    ADD CONSTRAINT "UsageRecord_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict tUD4uI96hghUfUTHqiIkGLnvReWOk0nKGylRZaClApx4TgT2KGZ98bXP1fm1seR

